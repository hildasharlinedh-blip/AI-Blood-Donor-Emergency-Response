import React, { useState, useEffect } from 'react';
import { 
  Sliders, 
  ShieldCheck, 
  Key, 
  Smartphone, 
  Mail, 
  Clock, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle,
  Lock
} from 'lucide-react';
import { SystemConfig } from '../types';
import { dbService } from '../services/dbService';

export const SettingsView: React.FC = () => {
  const [config, setConfig] = useState<SystemConfig>(dbService.getConfig());
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  useEffect(() => {
    setConfig(dbService.getConfig());
  }, []);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    dbService.updateConfig(config);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetDatabase = () => {
    if (window.confirm('Reset database to pristine state? This will restore sample donors and emergency cases.')) {
      dbService.resetToPristine();
      setConfig(dbService.getConfig());
      setResetSuccess(true);
      setTimeout(() => setResetSuccess(false), 3000);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      <div className="pb-2 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Sliders className="w-5 h-5 text-rose-500" />
          <span>System Settings &amp; API Integration Console</span>
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure Test Mode vs Live Production APIs, communication webhooks, and clinical safety thresholds.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Configuration saved successfully.</span>
        </div>
      )}

      {resetSuccess && (
        <div className="p-3.5 rounded-xl bg-sky-950/80 border border-sky-800 text-xs text-sky-300 flex items-center gap-2">
          <RotateCcw className="w-4 h-4 text-sky-400 shrink-0" />
          <span>Database reset to pristine verified state.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Mode Selector */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Execution Environment Mode</h3>
              <p className="text-xs text-slate-400">
                Switch between simulated local webhooks and real external communication providers.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setConfig({ ...config, mode: 'TEST' })}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-colors ${
                  config.mode === 'TEST'
                    ? 'bg-amber-950 text-amber-300 border-amber-800 shadow-xs'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                TEST SIMULATION MODE
              </button>
              <button
                type="button"
                onClick={() => setConfig({ ...config, mode: 'REAL' })}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-colors ${
                  config.mode === 'REAL'
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-800 shadow-xs'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                REAL API MODE
              </button>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-950 text-xs text-slate-400 border border-slate-800/80">
            {config.mode === 'TEST' ? (
              <span className="text-amber-200">
                <strong>Test Mode Active:</strong> SMS and Gmail dispatches are processed locally with zero carrier costs. Incoming responses can be triggered via interactive buttons on the Live Monitor.
              </span>
            ) : (
              <span className="text-emerald-300">
                <strong>Real API Mode Active:</strong> SMS will be delivered via Twilio / MSG91 credentials and emails via configured Gmail SMTP/OAuth.
              </span>
            )}
          </div>
        </div>

        {/* Twilio & SMS Settings */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-sky-400" />
            <span>Twilio &amp; MSG91 SMS Provider Configuration</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Twilio Account SID</label>
              <input
                type="text"
                value={config.twilioSid}
                onChange={(e) => setConfig({ ...config, twilioSid: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Twilio Auth Token</label>
              <input
                type="password"
                value={config.twilioAuthToken}
                onChange={(e) => setConfig({ ...config, twilioAuthToken: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Twilio Sender Phone Number</label>
              <input
                type="text"
                value={config.twilioPhoneNumber}
                onChange={(e) => setConfig({ ...config, twilioPhoneNumber: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">MSG91 Auth Key</label>
              <input
                type="password"
                value={config.msg91ApiKey}
                onChange={(e) => setConfig({ ...config, msg91ApiKey: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
              />
            </div>
          </div>
        </div>

        {/* Gmail API Settings */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Mail className="w-4 h-4 text-rose-400" />
            <span>Gmail Notification Settings</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Hospital Gmail Address</label>
              <input
                type="email"
                value={config.gmailAddress}
                onChange={(e) => setConfig({ ...config, gmailAddress: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Google App Password / OAuth Token</label>
              <input
                type="password"
                value={config.gmailAppPassword}
                onChange={(e) => setConfig({ ...config, gmailAppPassword: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
              />
            </div>
          </div>
        </div>

        {/* Timers & Clinical Thresholds */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <span>Automated Cascade Timers &amp; Clinical Thresholds</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Auto-Cascade Timeout: <strong className="text-white font-mono">{config.autoCascadeTimeoutSeconds}s</strong>
              </label>
              <input
                type="range"
                min="10"
                max="120"
                step="5"
                value={config.autoCascadeTimeoutSeconds}
                onChange={(e) => setConfig({ ...config, autoCascadeTimeoutSeconds: parseInt(e.target.value, 10) || 30 })}
                className="w-full accent-rose-500 cursor-pointer"
              />
              <span className="text-[11px] text-slate-500">
                Seconds before system marks donor TIMED OUT and auto-cascades to Candidate #2.
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Max Operational Radius: <strong className="text-white font-mono">{config.maxRadiusKm} km</strong>
              </label>
              <input
                type="range"
                min="15"
                max="100"
                step="5"
                value={config.maxRadiusKm}
                onChange={(e) => setConfig({ ...config, maxRadiusKm: parseInt(e.target.value, 10) || 50 })}
                className="w-full accent-sky-500 cursor-pointer"
              />
              <span className="text-[11px] text-slate-500">
                Maximum geographic boundary audited by Decision Tree.
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            onClick={handleResetDatabase}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-amber-300 hover:text-white bg-amber-950/60 hover:bg-amber-900/60 border border-amber-800 rounded-lg transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restore Pristine Database</span>
          </button>

          <button
            type="submit"
            className="px-6 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 rounded-lg shadow-sm transition-colors"
          >
            Save Settings
          </button>
        </div>
      </form>
    </div>
  );
};
