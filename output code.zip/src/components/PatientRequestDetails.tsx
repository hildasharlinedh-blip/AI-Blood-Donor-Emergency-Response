import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  MapPin, 
  Phone, 
  User, 
  Droplet, 
  Flame, 
  Clock, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Calendar,
  Share2
} from 'lucide-react';
import { EmergencyRequest, UrgencyLevel } from '../types';
import { dbService } from '../services/dbService';

interface PatientRequestDetailsProps {
  currentRequest: EmergencyRequest | null;
  onForwardToMatching: (request: EmergencyRequest) => void;
  onBackToForm: () => void;
}

export const PatientRequestDetails: React.FC<PatientRequestDetailsProps> = ({
  currentRequest,
  onForwardToMatching,
  onBackToForm,
}) => {
  const [request, setRequest] = useState<EmergencyRequest | null>(currentRequest);
  const [allRequests, setAllRequests] = useState<EmergencyRequest[]>([]);

  useEffect(() => {
    const list = dbService.getRequests();
    setAllRequests(list);
    if (currentRequest) {
      setRequest(currentRequest);
    } else if (list.length > 0) {
      setRequest(list[0]);
    }
  }, [currentRequest]);

  if (!request) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center max-w-3xl mx-auto space-y-4">
        <AlertCircle className="w-12 h-12 text-amber-400 mx-auto" />
        <h3 className="text-lg font-bold text-white">No Active Emergency Request Found</h3>
        <p className="text-xs text-slate-400">
          Please submit a patient blood requisition on Dashboard 1 or choose a case from the registry.
        </p>
        <button
          onClick={onBackToForm}
          className="px-6 py-2.5 rounded-xl bg-rose-600 text-white font-bold text-xs hover:bg-rose-500 transition-colors"
        >
          Go to Dashboard 1 (Request Form)
        </button>
      </div>
    );
  }

  const getUrgencyBadge = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'DANGER':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-black bg-rose-600 text-white border border-rose-400 animate-pulse flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5" />
            <span>DANGER (STAT EMERGENCY)</span>
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-black bg-orange-600 text-white border border-orange-400 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5" />
            <span>CRITICAL (30-60 MINS)</span>
          </span>
        );
      case 'URGENT':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-500 text-slate-950 border border-amber-300 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            <span>URGENT (2-4 HOURS)</span>
          </span>
        );
      default:
        return (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-300">
            NORMAL
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-800/80 text-rose-300 text-xs font-bold mb-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>DASHBOARD 2 · TRIAGE VERIFICATION &amp; WORKFLOW HANDOFF</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">
            Patient Request Details &amp; Matching Workflow
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Verified database record for clinical requisition. Forward to AI identification engine for compatibility scoring.
          </p>
        </div>

        {/* Case Switcher */}
        {allRequests.length > 1 && (
          <div className="flex items-center gap-2 shrink-0">
            <label className="text-xs text-slate-400 font-medium">Switch Case:</label>
            <select
              value={request.id}
              onChange={(e) => {
                const found = allRequests.find(r => r.id === e.target.value);
                if (found) setRequest(found);
              }}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-hidden"
            >
              {allRequests.map(r => (
                <option key={r.id} value={r.id}>
                  {r.referenceId} ({r.bloodGroup} · {r.patientName})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* HIGHLIGHTED CARD: Generated Request ID at the top */}
      <div className="bg-gradient-to-r from-rose-950/80 via-slate-900 to-slate-950 border-2 border-rose-500/80 rounded-2xl p-6 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-rose-400 uppercase tracking-widest font-mono">
              UNIQUE PATIENT REQUISITION IDENTIFIER (GENERATED IN DATABASE)
            </span>
            <div className="flex items-center gap-3">
              <h3 className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
                {request.referenceId || request.id}
              </h3>
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                ACTIVE IN TRIAGE
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Submitted on: {new Date(request.createdAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
            </p>
          </div>

          <div className="flex flex-col items-start sm:items-end gap-2">
            <span className="text-xs text-slate-400">Clinical Emergency Priority</span>
            {getUrgencyBadge(request.urgency)}
          </div>
        </div>
      </div>

      {/* Patient Details Grid (Automatically from Database) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Clinical Transfusion Requisition Record
            </h3>
            <p className="text-[11px] text-slate-400">
              Retrieved directly from database state. Ready for immediate donor matching.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-800 px-3 py-1 rounded-lg">
            ✓ Database Record Verified
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          
          {/* 1. Request ID */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Request ID</span>
            <span className="text-base font-extrabold text-rose-400 font-mono block">
              {request.referenceId}
            </span>
            <span className="text-[10px] text-slate-500 font-mono">DB PK: {request.id}</span>
          </div>

          {/* 2. Patient Name */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Patient Full Name</span>
            <span className="text-base font-bold text-white block">
              {request.patientName}
            </span>
            <span className="text-[10px] text-slate-400">Verified Hospital Patient</span>
          </div>

          {/* 3. Age & 4. Gender */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Age &amp; Gender</span>
            <span className="text-base font-bold text-white block">
              {request.patientAge} Years · {request.patientGender}
            </span>
            <span className="text-[10px] text-slate-400">Clinical Demographic</span>
          </div>

          {/* 5. Required Blood Group */}
          <div className="bg-slate-950 p-4 rounded-xl border border-rose-900/60 ring-1 ring-rose-500/30">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Required Blood Group</span>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-black text-rose-500 font-mono">
                {request.bloodGroup}
              </span>
              <span className="text-xs text-slate-300 font-medium">
                ({request.componentNeeded})
              </span>
            </div>
            <span className="text-[10px] text-rose-300/80">Matching target blood group</span>
          </div>

          {/* 6. Required Units */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Required Units</span>
            <span className="text-2xl font-black text-white font-mono block">
              {request.unitsRequired} Units
            </span>
            <span className="text-[10px] text-slate-400">0 Units fulfilled so far</span>
          </div>

          {/* 7. Contact Number */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Contact Number</span>
            <span className="text-base font-bold text-sky-400 font-mono block">
              {request.patientContactNumber || request.contactPhone}
            </span>
            <span className="text-[10px] text-slate-400">Hospital Attendant / ER Line</span>
          </div>

          {/* 8. Hospital Name */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 md:col-span-2">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Hospital Name &amp; Department</span>
            <span className="text-base font-bold text-white block">
              {request.hospitalName}
            </span>
            <span className="text-xs text-slate-300 block mt-0.5">
              Address: {request.hospitalAddress}, {request.city}
            </span>
          </div>

          {/* 9. Emergency Level */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Emergency Urgency Level</span>
            <div className="mt-1">
              {getUrgencyBadge(request.urgency)}
            </div>
          </div>
        </div>

        {/* Clinical Notes & Diagnosis */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 block">Diagnosis / Clinical Indications:</span>
          <p className="text-slate-200 font-medium">
            {request.diagnosis || 'Post-partum hemorrhage / acute hypovolemic resuscitation required.'}
          </p>
          {request.notes && (
            <p className="text-slate-400 text-[11px] italic mt-1">
              Notes: {request.notes}
            </p>
          )}
        </div>

        {/* Bottom Prominent Manual Action Button */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            onClick={onBackToForm}
            className="text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            ← Back to Patient Request Form
          </button>

          {/* 'FORWARD TO MATCHING BLOOD GROUP' - Prominent Manual Action Button */}
          <button
            onClick={() => onForwardToMatching(request)}
            className="w-full sm:w-auto px-10 py-4 rounded-xl text-sm font-black text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 shadow-xl shadow-rose-950/60 hover:shadow-rose-900/80 transition-all flex items-center justify-center gap-3 cursor-pointer group"
          >
            <Sparkles className="w-5 h-5 text-white group-hover:rotate-12 transition-transform" />
            <span className="tracking-wide">FORWARD TO MATCHING BLOOD GROUP</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};
