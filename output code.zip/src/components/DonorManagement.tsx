import React, { useState, useEffect } from 'react';
import { 
  Users, 
  UserPlus, 
  FileSpreadsheet, 
  Search, 
  Filter, 
  Download, 
  Upload, 
  Trash2, 
  Edit2, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  RefreshCw,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Check,
  X
} from 'lucide-react';
import { Donor, BloodGroup, ExcelImportSummary } from '../types';
import { dbService } from '../services/dbService';
import { 
  downloadSampleExcelTemplate, 
  parseExcelOrCsvFile, 
  exportDonorsToExcel,
  VALID_BLOOD_GROUPS 
} from '../utils/excelHandler';

interface DonorManagementProps {
  initialTab?: 'directory' | 'manual' | 'excel';
}

export const DonorManagement: React.FC<DonorManagementProps> = ({
  initialTab = 'directory',
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'directory' | 'manual' | 'excel'>(initialTab);
  const [donors, setDonors] = useState<Donor[]>([]);
  
  // Directory Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBloodGroup, setSelectedBloodGroup] = useState<string>('ALL');
  const [selectedCity, setSelectedCity] = useState<string>('ALL');
  const [availabilityFilter, setAvailabilityFilter] = useState<string>('ALL');

  // Manual Donor Registration state
  const [manualForm, setManualForm] = useState({
    fullName: '',
    phone: '',
    email: '',
    bloodGroup: 'O+' as BloodGroup,
    age: 28,
    gender: 'Male' as 'Male' | 'Female' | 'Other',
    weightKg: 68,
    city: 'Chennai',
    address: '',
    lastDonationDate: '2025-10-15',
    isAvailable: true,
    consentNotifications: true,
  });
  const [manualSuccessMsg, setManualSuccessMsg] = useState('');
  const [manualErrorMsg, setManualErrorMsg] = useState('');

  // Excel Upload state
  const [dragActive, setDragActive] = useState(false);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [importSummary, setImportSummary] = useState<ExcelImportSummary | null>(null);
  const [importSuccessMsg, setImportSuccessMsg] = useState('');

  // Edit Donor Modal state
  const [editingDonor, setEditingDonor] = useState<Donor | null>(null);

  const loadDonors = () => {
    setDonors(dbService.getDonors());
  };

  useEffect(() => {
    loadDonors();
    const unsubscribe = dbService.subscribe(loadDonors);
    return () => unsubscribe();
  }, []);

  // Filtered Donors
  const filteredDonors = donors.filter(d => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = 
      !q || 
      d.fullName.toLowerCase().includes(q) ||
      d.phone.includes(q) ||
      d.email.toLowerCase().includes(q) ||
      d.city.toLowerCase().includes(q) ||
      d.id.toLowerCase().includes(q);

    const matchesBg = selectedBloodGroup === 'ALL' || d.bloodGroup === selectedBloodGroup;
    const matchesCity = selectedCity === 'ALL' || d.city.toLowerCase() === selectedCity.toLowerCase();
    const matchesAvail = 
      availabilityFilter === 'ALL' || 
      (availabilityFilter === 'AVAILABLE' && d.isAvailable) ||
      (availabilityFilter === 'UNAVAILABLE' && !d.isAvailable);

    return matchesSearch && matchesBg && matchesCity && matchesAvail;
  });

  const availableCities = Array.from(new Set(donors.map(d => d.city))).filter(Boolean);

  // Handle Manual Submission
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setManualSuccessMsg('');
    setManualErrorMsg('');

    if (!manualForm.fullName.trim()) {
      setManualErrorMsg('Full Name is required.');
      return;
    }
    if (manualForm.age < 18 || manualForm.age > 65) {
      setManualErrorMsg('Age must be between 18 and 65 years as per NBTC safety guidelines.');
      return;
    }
    if (manualForm.weightKg < 50) {
      setManualErrorMsg('Donor weight must be at least 50 kg to ensure donation safety.');
      return;
    }
    const cleanPhone = manualForm.phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setManualErrorMsg('Valid 10-digit phone number is required.');
      return;
    }

    try {
      const added = dbService.addDonor({
        ...manualForm,
        location: {
          latitude: 13.0827,
          longitude: 80.2707,
          city: manualForm.city,
          address: manualForm.address,
        },
        totalDonations: 1,
        historicalAttendanceRate: 0.95,
        historicalResponseRate: 0.95,
        createdSource: 'manual',
      });

      setManualSuccessMsg(`Donor ${added.fullName} (${added.id}) registered successfully in clinical database.`);
      setManualForm({
        fullName: '',
        phone: '',
        email: '',
        bloodGroup: 'O+',
        age: 28,
        gender: 'Male',
        weightKg: 68,
        city: 'Chennai',
        address: '',
        lastDonationDate: '2025-10-15',
        isAvailable: true,
        consentNotifications: true,
      });
      setTimeout(() => setManualSuccessMsg(''), 4000);
    } catch (err: any) {
      setManualErrorMsg(err.message || 'Failed to register donor.');
    }
  };

  // Handle File Upload
  const handleFileUpload = async (file: File) => {
    setIsProcessingFile(true);
    setImportSuccessMsg('');
    try {
      const result = await parseExcelOrCsvFile(file);
      setImportSummary(result);
    } catch (err: any) {
      alert(`Error reading file: ${err.message}`);
    } finally {
      setIsProcessingFile(false);
    }
  };

  const handleSaveImportedRecords = () => {
    if (!importSummary || importSummary.parsedRecords.length === 0) return;
    const { addedCount, duplicates } = dbService.addDonorsBulk(importSummary.parsedRecords);
    setImportSuccessMsg(`Successfully imported ${addedCount} donors into persistent database. (${duplicates} duplicates avoided)`);
    setImportSummary(null);
  };

  const handleDeleteDonor = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete donor ${name} (${id}) from the database?`)) {
      dbService.deleteDonor(id);
    }
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDonor) return;
    dbService.updateDonor(editingDonor.id, editingDonor);
    setEditingDonor(null);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Sub Tabs: Directory | Manual Registration | Excel Upload */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Donor Management System</h2>
          <p className="text-xs text-slate-400">
            Clinical donor repository with manual entry, Excel dataset validation, and NBTC compliance.
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg">
          <button
            onClick={() => setActiveSubTab('directory')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeSubTab === 'directory'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Donor Directory ({donors.length})
          </button>
          <button
            onClick={() => setActiveSubTab('manual')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeSubTab === 'manual'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            + Manual Registration
          </button>
          <button
            onClick={() => setActiveSubTab('excel')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeSubTab === 'excel'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5 inline mr-1" />
            Excel Dataset Upload
          </button>
        </div>
      </div>

      {/* ============================================================== */}
      {/* TAB 1: DONOR DIRECTORY */}
      {/* ============================================================== */}
      {activeSubTab === 'directory' && (
        <div className="space-y-4">
          {/* Search & Filter Toolbar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
              {/* Search input */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search by name, phone, email, city, or ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-rose-500"
                />
              </div>

              {/* Blood Group Filter */}
              <select
                value={selectedBloodGroup}
                onChange={(e) => setSelectedBloodGroup(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-hidden focus:border-rose-500 font-mono"
              >
                <option value="ALL">All Blood Groups</option>
                {VALID_BLOOD_GROUPS.map(bg => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>

              {/* City Filter */}
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-hidden focus:border-rose-500"
              >
                <option value="ALL">All Cities</option>
                {availableCities.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>

              {/* Availability Filter */}
              <select
                value={availabilityFilter}
                onChange={(e) => setAvailabilityFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-hidden focus:border-rose-500"
              >
                <option value="ALL">All Availability</option>
                <option value="AVAILABLE">Available Now</option>
                <option value="UNAVAILABLE">Unavailable / Resting</option>
              </select>
            </div>

            {/* Actions: Export Excel */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => exportDonorsToExcel(filteredDonors)}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold border border-slate-700 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export to Excel</span>
              </button>
            </div>
          </div>

          {/* Donors Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-950 border-b border-slate-800 text-slate-400">
                    <th className="py-3 px-3.5 font-semibold">Donor ID</th>
                    <th className="py-3 px-3.5 font-semibold">Full Name</th>
                    <th className="py-3 px-3.5 font-semibold">Blood Group</th>
                    <th className="py-3 px-3.5 font-semibold">Age / Gender</th>
                    <th className="py-3 px-3.5 font-semibold">Contact Details</th>
                    <th className="py-3 px-3.5 font-semibold">City / Location</th>
                    <th className="py-3 px-3.5 font-semibold">Last Donated</th>
                    <th className="py-3 px-3.5 font-semibold text-center">Status</th>
                    <th className="py-3 px-3.5 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {filteredDonors.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-500">
                        No donors found matching the current search query or filters.
                      </td>
                    </tr>
                  ) : (
                    filteredDonors.map((donor) => (
                      <tr key={donor.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-3.5 font-mono text-slate-400 font-medium">
                          {donor.id}
                        </td>
                        <td className="py-3 px-3.5 font-medium text-white">
                          <div>{donor.fullName}</div>
                          {donor.createdSource === 'excel_upload' && (
                            <span className="text-[10px] text-sky-400 font-mono">Imported from Excel</span>
                          )}
                        </td>
                        <td className="py-3 px-3.5 font-mono">
                          <span className={`inline-block px-2 py-0.5 rounded font-bold ${
                            donor.bloodGroup.includes('-') 
                              ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                              : 'bg-slate-800 text-slate-200 border border-slate-700'
                          }`}>
                            {donor.bloodGroup}
                          </span>
                        </td>
                        <td className="py-3 px-3.5 text-slate-300">
                          {donor.age} yrs · {donor.gender}
                        </td>
                        <td className="py-3 px-3.5 text-slate-300">
                          <div className="font-mono text-slate-200">{donor.phone}</div>
                          <div className="text-[11px] text-slate-400">{donor.email}</div>
                        </td>
                        <td className="py-3 px-3.5 text-slate-300">
                          <span className="font-medium text-white">{donor.city}</span>
                          <span className="block text-[11px] text-slate-400 truncate max-w-[140px]">{donor.address}</span>
                        </td>
                        <td className="py-3 px-3.5 text-slate-400 font-mono tabular-nums">
                          {donor.lastDonationDate}
                        </td>
                        <td className="py-3 px-3.5 text-center">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                            donor.isAvailable 
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}>
                            {donor.isAvailable ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                            <span>{donor.isAvailable ? 'Available' : 'Resting'}</span>
                          </span>
                        </td>
                        <td className="py-3 px-3.5 text-right whitespace-nowrap">
                          <button
                            onClick={() => setEditingDonor(donor)}
                            title="Edit donor details"
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors mr-1"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteDonor(donor.id, donor.fullName)}
                            title="Delete donor"
                            className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/60 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
              <span>Showing {filteredDonors.length} of {donors.length} registered donors</span>
              <span className="font-mono text-slate-500">Database Engine: Relational Local Store</span>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 2: MANUAL REGISTRATION FORM */}
      {/* ============================================================== */}
      {activeSubTab === 'manual' && (
        <div className="max-w-3xl mx-auto bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
          <div className="mb-6 pb-4 border-b border-slate-800">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-rose-500" />
              <span>Manual Donor Clinical Registration</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Enter donor vitals and contact information in compliance with the National Blood Transfusion Council.
            </p>
          </div>

          {manualSuccessMsg && (
            <div className="mb-4 p-3 rounded-lg bg-emerald-950/70 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{manualSuccessMsg}</span>
            </div>
          )}

          {manualErrorMsg && (
            <div className="mb-4 p-3 rounded-lg bg-rose-950/70 border border-rose-800 text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{manualErrorMsg}</span>
            </div>
          )}

          <form onSubmit={handleManualSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dr. Rajesh Sundaram"
                  value={manualForm.fullName}
                  onChange={(e) => setManualForm({ ...manualForm, fullName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Blood Group *</label>
                <select
                  value={manualForm.bloodGroup}
                  onChange={(e) => setManualForm({ ...manualForm, bloodGroup: e.target.value as BloodGroup })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                >
                  {VALID_BLOOD_GROUPS.map(bg => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number (10 Digits) *</label>
                <input
                  type="text"
                  required
                  placeholder="+91 98401 23456"
                  value={manualForm.phone}
                  onChange={(e) => setManualForm({ ...manualForm, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="rajesh.s@example.com"
                  value={manualForm.email}
                  onChange={(e) => setManualForm({ ...manualForm, email: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Age (18 - 65 yrs) *</label>
                <input
                  type="number"
                  min="18"
                  max="65"
                  required
                  value={manualForm.age}
                  onChange={(e) => setManualForm({ ...manualForm, age: parseInt(e.target.value, 10) || 18 })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Weight (Min 50 kg) *</label>
                <input
                  type="number"
                  min="50"
                  max="140"
                  required
                  value={manualForm.weightKg}
                  onChange={(e) => setManualForm({ ...manualForm, weightKg: parseInt(e.target.value, 10) || 50 })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Gender</label>
                <select
                  value={manualForm.gender}
                  onChange={(e) => setManualForm({ ...manualForm, gender: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">City *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chennai"
                  value={manualForm.city}
                  onChange={(e) => setManualForm({ ...manualForm, city: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Street Address</label>
              <input
                type="text"
                placeholder="e.g. 14, Cathedral Road, Gopalapuram"
                value={manualForm.address}
                onChange={(e) => setManualForm({ ...manualForm, address: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Last Donation Date *</label>
              <input
                type="date"
                required
                value={manualForm.lastDonationDate}
                onChange={(e) => setManualForm({ ...manualForm, lastDonationDate: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
              />
              <span className="block text-[11px] text-slate-500 mt-0.5">
                90-day mandatory interval will be audited by the clinical decision tree before dispatch.
              </span>
            </div>

            <div className="pt-2 space-y-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={manualForm.isAvailable}
                  onChange={(e) => setManualForm({ ...manualForm, isAvailable: e.target.checked })}
                  className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 border-slate-700 bg-slate-950"
                />
                <span className="text-xs text-slate-300 font-medium">Currently Available for Emergency Callout</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={manualForm.consentNotifications}
                  onChange={(e) => setManualForm({ ...manualForm, consentNotifications: e.target.checked })}
                  className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 border-slate-700 bg-slate-950"
                />
                <span className="text-xs text-slate-300 font-medium">
                  Consent granted to receive automated emergency SMS and Gmail notifications
                </span>
              </label>
            </div>

            <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setActiveSubTab('directory')}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-lg shadow-sm transition-colors"
              >
                Register Donor
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 3: EXCEL DATASET UPLOAD */}
      {/* ============================================================== */}
      {activeSubTab === 'excel' && (
        <div className="space-y-6 max-w-4xl mx-auto">
          {/* Header & Download Template Button */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-sky-400" />
                <span>Bulk Excel &amp; CSV Dataset Ingestion</span>
              </h3>
              <p className="text-xs text-slate-400">
                Upload donor datasets in <code className="text-sky-300">.xlsx</code>, <code className="text-sky-300">.xls</code>, or <code className="text-sky-300">.csv</code> format with automatic schema validation.
              </p>
            </div>

            <button
              onClick={downloadSampleExcelTemplate}
              className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-colors shrink-0"
            >
              <Download className="w-4 h-4 text-sky-400" />
              <span>Download Sample Template (.xlsx)</span>
            </button>
          </div>

          {importSuccessMsg && (
            <div className="p-4 rounded-xl bg-emerald-950/70 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{importSuccessMsg}</span>
            </div>
          )}

          {/* Drag & Drop Upload Zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
            onDragLeave={() => setDragActive(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragActive(false);
              if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleFileUpload(e.dataTransfer.files[0]);
              }
            }}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
              dragActive 
                ? 'border-rose-500 bg-rose-950/20' 
                : 'border-slate-700 bg-slate-900/60 hover:border-slate-600'
            }`}
          >
            <Upload className="w-8 h-8 mx-auto text-slate-400 mb-3" />
            <p className="text-sm font-semibold text-white mb-1">
              Drag and drop your Excel or CSV file here
            </p>
            <p className="text-xs text-slate-400 mb-4">
              Supports .xlsx, .xls, and .csv with columns: Name, Phone, Email, BloodGroup, City, LastDonationDate, Availability, Consent
            </p>

            <label className="inline-flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors">
              <span>Browse File</span>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
            </label>

            {isProcessingFile && (
              <p className="text-xs text-rose-400 mt-3 font-medium animate-pulse">
                Auditing spreadsheet schema &amp; validating phone/email records...
              </p>
            )}
          </div>

          {/* Validation Summary Cards & Preview */}
          {importSummary && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h4 className="text-sm font-bold text-white">Spreadsheet Validation Summary</h4>
                  <p className="text-xs text-slate-400">File: {importSummary.fileName}</p>
                </div>

                <button
                  onClick={handleSaveImportedRecords}
                  disabled={importSummary.validCount === 0}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:pointer-events-none rounded-lg shadow-sm transition-colors"
                >
                  Confirm &amp; Ingest {importSummary.validCount} Valid Records
                </button>
              </div>

              {/* 4 Stat Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Total Rows In File</span>
                  <span className="text-xl font-bold text-white font-mono">{importSummary.totalRows}</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Successfully Validated</span>
                  <span className="text-xl font-bold text-emerald-400 font-mono">{importSummary.validCount}</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Duplicate Skipped</span>
                  <span className="text-xl font-bold text-amber-400 font-mono">{importSummary.duplicateCount}</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Invalid Records</span>
                  <span className="text-xl font-bold text-rose-400 font-mono">{importSummary.invalidCount}</span>
                </div>
              </div>

              {/* Error Callouts */}
              {importSummary.errors.length > 0 && (
                <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-900/60 max-h-36 overflow-y-auto space-y-1">
                  <div className="text-[11px] font-bold text-rose-300">Verification Issues Detected:</div>
                  {importSummary.errors.map((err, i) => (
                    <div key={i} className="text-[11px] text-rose-200">
                      • Row {err.row} ({err.name}): {err.reason}
                    </div>
                  ))}
                </div>
              )}

              {/* Preview Table */}
              <div>
                <h5 className="text-xs font-semibold text-slate-300 mb-2">Dataset Preview (Ready for Import):</h5>
                <div className="max-h-56 overflow-y-auto border border-slate-800 rounded-lg">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-950 sticky top-0 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2">Name</th>
                        <th className="p-2">Blood</th>
                        <th className="p-2">Phone</th>
                        <th className="p-2">City</th>
                        <th className="p-2">Last Donated</th>
                        <th className="p-2">Available</th>
                        <th className="p-2">Consent</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 font-mono">
                      {importSummary.parsedRecords.slice(0, 10).map((r, i) => (
                        <tr key={i} className="hover:bg-slate-800/40">
                          <td className="p-2 font-sans text-white">{r.fullName}</td>
                          <td className="p-2 text-rose-400 font-bold">{r.bloodGroup}</td>
                          <td className="p-2 text-slate-300">{r.phone}</td>
                          <td className="p-2 font-sans text-slate-300">{r.city}</td>
                          <td className="p-2 text-slate-400">{r.lastDonationDate}</td>
                          <td className="p-2 text-emerald-400">{r.isAvailable ? 'YES' : 'NO'}</td>
                          <td className="p-2 text-emerald-400">{r.consentNotifications ? 'YES' : 'NO'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Edit Donor Modal */}
      {editingDonor && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full shadow-2xl">
            <h3 className="text-base font-bold text-white mb-1">Edit Donor Details</h3>
            <p className="text-xs text-slate-400 mb-4 font-mono">{editingDonor.id} · {editingDonor.fullName}</p>

            <form onSubmit={handleSaveEdit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  value={editingDonor.fullName}
                  onChange={(e) => setEditingDonor({ ...editingDonor, fullName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Blood Group</label>
                  <select
                    value={editingDonor.bloodGroup}
                    onChange={(e) => setEditingDonor({ ...editingDonor, bloodGroup: e.target.value as BloodGroup })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  >
                    {VALID_BLOOD_GROUPS.map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">City</label>
                  <input
                    type="text"
                    value={editingDonor.city}
                    onChange={(e) => setEditingDonor({ ...editingDonor, city: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Phone</label>
                  <input
                    type="text"
                    value={editingDonor.phone}
                    onChange={(e) => setEditingDonor({ ...editingDonor, phone: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Email</label>
                  <input
                    type="email"
                    value={editingDonor.email}
                    onChange={(e) => setEditingDonor({ ...editingDonor, email: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Last Donation Date</label>
                <input
                  type="date"
                  value={editingDonor.lastDonationDate}
                  onChange={(e) => setEditingDonor({ ...editingDonor, lastDonationDate: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div className="flex items-center gap-4 pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingDonor.isAvailable}
                    onChange={(e) => setEditingDonor({ ...editingDonor, isAvailable: e.target.checked })}
                    className="w-4 h-4 rounded text-rose-600 bg-slate-950"
                  />
                  <span className="text-xs text-slate-300 font-medium">Available</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingDonor.consentNotifications}
                    onChange={(e) => setEditingDonor({ ...editingDonor, consentNotifications: e.target.checked })}
                    className="w-4 h-4 rounded text-rose-600 bg-slate-950"
                  />
                  <span className="text-xs text-slate-300 font-medium">Consent Active</span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingDonor(null)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-lg"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
