import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Award, 
  Heart, 
  Calendar, 
  Clock, 
  Printer, 
  Download,
  Share2, 
  RotateCcw, 
  ShieldCheck, 
  Building2, 
  User, 
  Droplet,
  ExternalLink,
  MessageCircle,
  Mail,
  ArrowRight
} from 'lucide-react';
import { dbService } from '../services/dbService';
import { Donor, EmergencyRequest } from '../types';
import { calculateNextEligibleDate } from '../utils/bloodCompatibility';

interface DonationRecordUpdatedProps {
  onStartNewRequest: () => void;
  onViewLiveGps: () => void;
}

export const DonationRecordUpdated: React.FC<DonationRecordUpdatedProps> = ({
  onStartNewRequest,
  onViewLiveGps,
}) => {
  const [completedRecord, setCompletedRecord] = useState<any>(null);
  const [donor, setDonor] = useState<Donor | null>(null);
  const [request, setRequest] = useState<EmergencyRequest | null>(null);

  useEffect(() => {
    const latest = dbService.getLatestCompletedDonation();
    const donors = dbService.getDonors();
    const requests = dbService.getRequests();

    if (latest) {
      setCompletedRecord(latest);
      const d = donors.find(x => x.id === latest.donorId || x.fullName === latest.donorName);
      setDonor(d || donors.find(x => x.fullName === 'Hilda Sharline') || donors[0]);
      const r = requests.find(x => x.id === latest.requestId);
      setRequest(r || requests[0]);
    } else {
      // Fallback demo record if user navigated directly
      const hilda = donors.find(x => x.fullName === 'Hilda Sharline') || donors[0];
      setDonor(hilda);
      const activeReq = requests[0];
      setRequest(activeReq);
      setCompletedRecord({
        id: 'REC-2026-98421',
        donorId: hilda?.id || 'DNR-1000',
        donorName: hilda?.fullName || 'Hilda Sharline',
        bloodGroup: hilda?.bloodGroup || 'O-',
        unitsDonated: 1,
        bagBarcode: 'BAG-SMC-2026-88912-O-NEG',
        attendingDoctor: 'Dr. K. Meenakshi, MD (Transfusion Medicine)',
        hospitalName: activeReq?.hospitalName || 'Srinivasan Medical College & Hospital, Samayapuram',
        phlebotomyStation: 'Donor Station #03, Blood Bank Division',
        patientName: activeReq?.patientName || 'Anita Ramesh',
        timestamp: new Date().toISOString(),
        dateCompleted: new Date().toISOString().split('T')[0],
        nextEligibleDate: new Date(Date.now() + 90 * 86400000).toISOString().split('T')[0],
      });
    }
  }, []);

  const [emailStatusMessage, setEmailStatusMessage] = useState<string>('');
  const [printStatusMessage, setPrintStatusMessage] = useState<string>('');

  const todayStr = new Date().toISOString().split('T')[0];
  const nextEligibleStr = calculateNextEligibleDate(todayStr, 90);

  const generatePrintableCertificateHtml = () => {
    const donorName = donor?.fullName || 'Hilda Sharline';
    const bagBarcode = completedRecord?.bagBarcode || 'BAG-SMC-2026-88912-O-NEG';
    const today = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Blood Donation Certificate - ${donorName}</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 10mm;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background: #0f172a;
      color: #0f172a;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 24px;
    }
    .action-bar {
      margin-bottom: 20px;
      display: flex;
      gap: 12px;
    }
    .print-btn {
      background: #e11d48;
      color: #ffffff;
      border: none;
      padding: 12px 28px;
      font-size: 15px;
      font-weight: 800;
      border-radius: 10px;
      cursor: pointer;
      box-shadow: 0 4px 15px rgba(225,29,72,0.4);
    }
    .print-btn:hover { background: #be123c; }
    .cert-frame {
      width: 100%;
      max-width: 980px;
      background: #ffffff;
      border: 8px double #d97706;
      border-radius: 18px;
      padding: 44px 50px;
      position: relative;
      box-shadow: 0 25px 60px rgba(0,0,0,0.5);
      text-align: center;
    }
    .cert-badge {
      display: inline-block;
      width: 68px;
      height: 68px;
      border-radius: 50%;
      background: #fee2e2;
      border: 2px solid #ef4444;
      line-height: 64px;
      font-size: 32px;
      margin-bottom: 12px;
    }
    .hospital-title {
      font-size: 14px;
      font-weight: 800;
      letter-spacing: 2px;
      color: #b45309;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .cert-heading {
      font-size: 32px;
      font-weight: 900;
      color: #0f172a;
      letter-spacing: 1px;
      margin-bottom: 4px;
    }
    .hospital-addr {
      font-size: 11px;
      color: #64748b;
      margin-bottom: 20px;
      line-height: 1.4;
    }
    .subtext {
      font-size: 13px;
      color: #475569;
      font-style: italic;
      margin-bottom: 10px;
    }
    .donor-name {
      font-size: 40px;
      font-weight: 900;
      color: #be123c;
      font-family: Georgia, serif;
      margin-bottom: 14px;
      text-decoration: underline;
      text-decoration-color: #fbcfe8;
      text-underline-offset: 8px;
    }
    .citation {
      font-size: 16px;
      font-weight: 700;
      color: #1e293b;
      max-width: 740px;
      margin: 0 auto 26px;
      line-height: 1.6;
    }
    .grid-details {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 14px;
      margin-bottom: 28px;
      font-size: 12px;
      text-align: left;
    }
    .grid-item label {
      display: block;
      color: #64748b;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
    }
    .grid-item span {
      display: block;
      color: #0f172a;
      font-weight: 800;
      font-size: 13px;
      margin-top: 2px;
    }
    .footer-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      padding-top: 18px;
      border-top: 1px solid #e2e8f0;
      margin-top: 10px;
    }
    .seal-box {
      width: 72px;
      height: 72px;
      border: 2px dashed #e11d48;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: 900;
      color: #e11d48;
      margin: 0 auto;
      text-transform: uppercase;
    }
    .signature-line {
      font-family: Georgia, serif;
      font-style: italic;
      font-size: 16px;
      color: #0f172a;
      font-weight: bold;
    }
    .sig-role {
      font-size: 11px;
      color: #64748b;
      border-top: 1px solid #cbd5e1;
      padding-top: 3px;
      margin-top: 3px;
    }
    @media print {
      body {
        background: transparent !important;
        padding: 0 !important;
      }
      .cert-frame {
        box-shadow: none !important;
        border-color: #d97706 !important;
      }
      .action-bar {
        display: none !important;
      }
    }
  </style>
</head>
<body>
  <div class="action-bar">
    <button class="print-btn" onclick="window.print()">🖨️ Click to Print or Save as PDF to Laptop</button>
  </div>
  <div class="cert-frame">
    <div class="cert-badge">🩸</div>
    <div class="hospital-title">Srinivasan Medical College &amp; Hospital Transfusion Division</div>
    <h1 class="cert-heading">CERTIFICATE OF APPRECIATION</h1>
    <p class="hospital-addr">NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112 · Phone: 0431-2677777</p>
    
    <p class="subtext">This certificate is gratefully presented to</p>
    <div class="donor-name">${donorName}</div>
    <p class="citation">Has blood donated 1 unit of o- blood at Srinivasan Medical College &amp; Hospital, saving the life of emergency</p>

    <div class="grid-details">
      <div class="grid-item">
        <label>Blood Group</label>
        <span style="color: #e11d48;">O- (Universal PRBC)</span>
      </div>
      <div class="grid-item">
        <label>Donation Date</label>
        <span>${today}</span>
      </div>
      <div class="grid-item">
        <label>Verified Barcode</label>
        <span style="font-family: monospace;">${bagBarcode}</span>
      </div>
      <div class="grid-item">
        <label>Next Eligible Date</label>
        <span style="color: #059669;">${nextEligibleStr}</span>
      </div>
    </div>

    <div class="footer-row">
      <div style="text-align: left;">
        <div style="font-size: 11px; color: #64748b;">National Registry ID</div>
        <div style="font-family: monospace; font-weight: bold; color: #0f172a;">${completedRecord?.id || 'REC-2026-98421'}</div>
        <div style="font-size: 10px; color: #94a3b8;">ISBT-128 Verified</div>
      </div>

      <div>
        <div class="seal-box">OFFICIAL<br>SEAL</div>
        <div style="font-size: 10px; color: #64748b; margin-top: 4px;">Blood Transfusion Council</div>
      </div>

      <div style="text-align: right;">
        <div class="signature-line">Dr. K. Meenakshi</div>
        <div class="sig-role">Chief Transfusion Officer, SMC&amp;H</div>
      </div>
    </div>
  </div>
  <script>
    // Prompt print automatically
    window.addEventListener('load', function() {
      setTimeout(function() {
        window.print();
      }, 500);
    });
  </script>
</body>
</html>`;
  };

  // Direct download to laptop + open standalone print preview
  const handlePrintAndSave = () => {
    const htmlContent = generatePrintableCertificateHtml();

    // 1. Direct file download to laptop
    try {
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Blood_Donation_Certificate_Hilda_Sharline.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch (err) {
      console.error('Download file error:', err);
    }

    // 2. Open printable new tab (triggers laptop print dialog: Save as PDF / Print)
    try {
      const printWin = window.open('', '_blank');
      if (printWin) {
        printWin.document.write(htmlContent);
        printWin.document.close();
      }
    } catch (err) {
      console.error('Print window popup error:', err);
    }

    // 3. Audit log
    dbService.addAuditLog(
      'Medical Registry',
      'CERTIFICATE_SAVED',
      `Certificate of appreciation saved to laptop for Hilda Sharline (Blood_Donation_Certificate_Hilda_Sharline.html).`,
      'SUCCESS'
    );

    // 4. Feedback message
    setPrintStatusMessage('✓ Certificate downloaded & saved to your laptop (Blood_Donation_Certificate_Hilda_Sharline.html)! You can now print or Save as PDF.');
    setTimeout(() => {
      setPrintStatusMessage('');
    }, 8000);
  };

  const certificateWhatsAppUrl = `https://api.whatsapp.com/send?phone=918778434228&text=${encodeURIComponent(
    `🎖️ *OFFICIAL BLOOD DONATION CERTIFICATE OF APPRECIATION*\n\nDear Hilda Sharline,\nHas blood donated 1 unit of o- blood at Srinivasan Medical College & Hospital, saving the life of emergency.\n\nYour record is updated in the National Transfusion Registry.\nNext Eligible Date for whole blood donation: ${nextEligibleStr}.\n\nYou are a true lifesaver! ❤️\nPhone: 0431-2677777`
  )}`;

  const certSubject = `[OFFICIAL CERTIFICATE] Blood Donation Honor Certificate - Hilda Sharline (Srinivasan Medical College & Hospital)`;
  
  const certBody = `SRINIVASAN MEDICAL COLLEGE & HOSPITAL
TRANSFUSION MEDICINE DIVISION
NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112
Hospital Phone: 0431-2677777

CERTIFICATE OF APPRECIATION

This certificate is gratefully presented to:
HILDA SHARLINE

Has blood donated 1 unit of o- blood at Srinivasan Medical College & Hospital, saving the life of emergency

VERIFIED DONATION DETAILS:
- Donor Name: Hilda Sharline
- Blood Group: O- Negative (Universal PRBC)
- Units Donated: 1 Unit
- Patient: ${request?.patientName || 'Anita Ramesh'} (Requisition Ref: ${request?.referenceId || 'REF-ER-2026-0881'})
- Verified Blood Bag Barcode: ${completedRecord?.bagBarcode || 'BAG-SMC-2026-88912-O-NEG'}
- Date Completed: ${new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
- Attending Doctor: Dr. K. Meenakshi, MD (Transfusion Medicine)
- Next Eligible Donation Date: ${nextEligibleStr} (Mandatory 90-Day Clinical Recovery Interval)

📍 HOSPITAL GOOGLE MAPS LOCATION & DIRECTIONS:
https://maps.google.com/?q=Srinivasan+Medical+College+%26+Hospital,+NH-45,+Trichy+Chennai+Trunk+Road,+near+the+Samayapuram+Toll+Plaza+in+Samayapuram,+Tiruchirappalli,+Tamil+Nadu+621112

In recognition of your selfless service to society and saving an emergency patient's life.

Thank you,
hilda
Chief Coordinator, Emergency Blood Response Network`;

  const gmailCertificateUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=hilda.sharline.dh@gmail.com&cc=hildasharline.it23@krct.ac.in&su=${encodeURIComponent(certSubject)}&body=${encodeURIComponent(certBody)}`;

  const handleEmailCertificate = (e: React.MouseEvent) => {
    // Audit log
    dbService.addAuditLog(
      'Medical Registry',
      'CERTIFICATE_SENT',
      `Certificate of appreciation dispatched to Hilda Sharline (hilda.sharline.dh@gmail.com).`,
      'SUCCESS'
    );

    setEmailStatusMessage('✓ Official Blood Donation Certificate opened in Gmail & dispatched to hilda.sharline.dh@gmail.com!');
    setTimeout(() => {
      setEmailStatusMessage('');
    }, 7000);
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-700/80 text-emerald-300 text-xs font-bold mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>DASHBOARD 6 · DONATION RECORD UPDATED</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Award className="w-6 h-6 text-emerald-400" />
            <span>Donation Record Updated &amp; Registry Confirmation</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Official blood donation record has been successfully logged in the central healthcare registry. Next eligible donation timer reset to 90 days.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onStartNewRequest}
            className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Create New Request</span>
          </button>
        </div>
      </div>

      {/* Main Success Card: Registry Updated Confirmation */}
      <div className="bg-gradient-to-r from-emerald-950/80 via-slate-900 to-slate-950 border-2 border-emerald-500 rounded-2xl p-6 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-emerald-900/60">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  Donation Record Successfully Updated
                </h3>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-700">
                  REGISTRY VERIFIED
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Hospital blood bag <strong className="text-white font-mono">{completedRecord?.bagBarcode}</strong> has been sealed and registered for patient <strong className="text-emerald-300">{completedRecord?.patientName || 'Anita Ramesh'}</strong>.
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right shrink-0">
            <span className="text-[11px] font-semibold text-slate-400 block">Registry Transaction Ref</span>
            <span className="text-sm font-mono font-bold text-emerald-400 block">
              {completedRecord?.id || 'REC-2026-98421'}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Recorded: {new Date().toLocaleDateString([], { dateStyle: 'medium' })}
            </span>
          </div>
        </div>
      </div>

      {/* Donor Profile & New Eligibility Clock Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Card 1: Completed Donation Today */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              DONATION COMPLETED
            </span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">
            {donor?.fullName || 'Hilda Sharline'}
          </div>
          <div className="text-xs text-emerald-400 font-semibold leading-relaxed">
            Has blood donated 1 unit of o- blood at Srinivasan Medical College &amp; Hospital, saving the life of emergency
          </div>
          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
            <div>Previous Donation: <strong className="text-amber-300">170 Days Ago</strong></div>
            <div>New Donation: <strong className="text-emerald-300">Today (Completed)</strong></div>
            <div>Total Lifetime Donations: <strong className="text-white">{(donor?.totalDonations || 6) + 1} Donations</strong></div>
          </div>
        </div>

        {/* Card 2: Next Eligible Date (90 Days Reset) */}
        <div className="bg-slate-900 border border-emerald-800/80 rounded-2xl p-5 shadow-xl space-y-2 ring-1 ring-emerald-500/30">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
              NEXT ELIGIBLE DONATION DATE
            </span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            {nextEligibleStr}
          </div>
          <div className="text-xs text-slate-300 font-medium">
            Mandatory 90-Day Whole Blood Recovery Interval
          </div>
          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
            <div>Recovery Interval: <strong className="text-white">90 Days</strong></div>
            <div>Eligibility Status: <strong className="text-amber-400">Resting &amp; Replenishing Iron Stores</strong></div>
            <div>Countdown: <strong className="text-emerald-400 font-mono">90 Days Remaining</strong></div>
          </div>
        </div>

        {/* Card 3: Hospital Blood Bank Inventory Stock */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              HOSPITAL BLOOD BANK STOCK
            </span>
            <Building2 className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-sky-400 font-mono">
            +1 Unit Added
          </div>
          <div className="text-xs text-slate-300 font-medium">
            Srinivasan Medical College &amp; Hospital Blood Bank Division
          </div>
          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
            <div>Requisition Status: <strong className="text-emerald-400">FULFILLED &amp; CLOSED</strong></div>
            <div>Patient: <strong className="text-white">{request?.patientName || 'Anita Ramesh'}</strong></div>
            <div>Attending Doctor: <strong className="text-slate-300">{completedRecord?.attendingDoctor || 'Dr. K. Meenakshi'}</strong></div>
          </div>
        </div>
      </div>

      {/* Official Certificate of Appreciation (Printable & Shareable) */}
      <div className="bg-slate-900 border-2 border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span>Digital Certificate of Blood Donation Honor</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Awarded to the donor in recognition of selfless emergency voluntary blood donation
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handlePrintAndSave}
              className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 active:bg-amber-700 text-white font-black text-xs transition-all flex items-center gap-2 cursor-pointer shadow-md border border-amber-400/50"
              title="Click to print and directly save Certificate to your laptop (.html / PDF)"
            >
              <Printer className="w-4 h-4 text-amber-100" />
              <span>Print / Save to Laptop</span>
              <Download className="w-3.5 h-3.5 text-amber-200" />
            </button>

            <a
              href={certificateWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Share via WhatsApp</span>
              <ExternalLink className="w-3 h-3 text-emerald-200" />
            </a>

            <a
              href={gmailCertificateUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleEmailCertificate}
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-bold text-xs transition-all flex items-center gap-2 cursor-pointer shadow-md border border-rose-400/50"
              title="Click to open pre-filled Gmail and send Certificate of Appreciation to hilda.sharline.dh@gmail.com"
            >
              <Mail className="w-4 h-4 text-white" />
              <span>Email Certificate</span>
              <ExternalLink className="w-3.5 h-3.5 text-rose-200" />
            </a>
          </div>
        </div>

        {/* Real-time Save & Print Toast Banner */}
        {printStatusMessage && (
          <div className="p-3.5 rounded-xl bg-amber-950 border border-amber-500 text-amber-200 text-xs font-bold flex items-center gap-2.5 shadow-lg">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{printStatusMessage}</span>
          </div>
        )}

        {/* Real-time Email Dispatch Toast Banner */}
        {emailStatusMessage && (
          <div className="p-3.5 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-bold flex items-center gap-2.5 shadow-lg">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{emailStatusMessage}</span>
          </div>
        )}

        {/* Certificate Canvas / Card */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border-4 border-double border-amber-600/60 rounded-2xl p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl">
          <div className="absolute top-4 left-4 w-12 h-12 border-t-2 border-l-2 border-amber-500/60 pointer-events-none" />
          <div className="absolute top-4 right-4 w-12 h-12 border-t-2 border-r-2 border-amber-500/60 pointer-events-none" />
          <div className="absolute bottom-4 left-4 w-12 h-12 border-b-2 border-l-2 border-amber-500/60 pointer-events-none" />
          <div className="absolute bottom-4 right-4 w-12 h-12 border-b-2 border-r-2 border-amber-500/60 pointer-events-none" />

          <div className="space-y-4 max-w-2xl mx-auto">
            <div className="w-16 h-16 rounded-full bg-amber-500/10 border-2 border-amber-500/40 mx-auto flex items-center justify-center text-amber-400 shadow-md">
              <Heart className="w-8 h-8 fill-rose-600 text-rose-500" />
            </div>

            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-widest text-amber-400 font-mono">
                SRINIVASAN MEDICAL COLLEGE &amp; HOSPITAL TRANSFUSION MEDICINE DIVISION
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                CERTIFICATE OF APPRECIATION
              </h2>
              <p className="text-xs text-slate-400">
                NH-45, TRICHY CHENNAI TRUNK ROAD, NEAR THE SAMAYAPURAM TOLL PLAZA IN SAMAYAPURAM, TIRUCHIRAPPALLI, TAMIL NADU 621112 · PHONE: 0431-2677777
              </p>
            </div>

            <p className="text-xs text-slate-300 italic pt-2">
              This certificate is gratefully presented to
            </p>

            <div className="text-3xl sm:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-rose-300 to-amber-200 py-1 font-serif">
              {donor?.fullName || 'Hilda Sharline'}
            </div>

            {/* Exactly as requested by user */}
            <p className="text-sm sm:text-base text-slate-100 max-w-xl mx-auto leading-relaxed font-semibold">
              Has blood donated 1 unit of o- blood at Srinivasan Medical College &amp; Hospital, saving the life of emergency
            </p>

            {/* Signature & Seal Row */}
            <div className="pt-8 grid grid-cols-2 sm:grid-cols-3 gap-4 border-t border-slate-800/80 items-end text-xs">
              <div className="text-left space-y-1">
                <span className="text-[10px] text-slate-500 font-mono block">VERIFIED LOT ID</span>
                <span className="font-mono text-emerald-400 font-bold block">{completedRecord?.bagBarcode || 'BAG-SMC-2026-88912-O-NEG'}</span>
                <span className="text-[10px] text-slate-400">ISBT-128 Compliant</span>
              </div>

              <div className="space-y-1">
                <div className="w-14 h-14 rounded-full border-2 border-dashed border-rose-500/60 mx-auto flex items-center justify-center text-[10px] text-rose-400 font-bold font-mono">
                  OFFICIAL<br/>SEAL
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Blood Transfusion Council</span>
              </div>

              <div className="text-right space-y-1">
                <div className="font-serif italic text-sm text-amber-200">Dr. K. Meenakshi</div>
                <div className="border-t border-slate-700 pt-0.5">
                  <span className="text-[10px] text-slate-400 block font-semibold">Chief Transfusion Officer</span>
                  <span className="text-[9px] text-slate-500 font-mono">Srinivasan Medical College</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Flow Buttons */}
        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            onClick={onViewLiveGps}
            className="text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            ← View Live Donor GPS &amp; Hospital Route
          </button>

          <button
            onClick={onStartNewRequest}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl text-sm font-black text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 shadow-xl shadow-rose-950/60 transition-all flex items-center justify-center gap-2 cursor-pointer group"
          >
            <span>SUBMIT ANOTHER EMERGENCY BLOOD REQUEST</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};
