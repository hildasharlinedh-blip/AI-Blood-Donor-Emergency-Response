import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  User, 
  Droplet, 
  ShieldCheck, 
  Clock, 
  Sparkles, 
  FileText, 
  ArrowRight,
  AlertCircle,
  Barcode
} from 'lucide-react';
import { EmergencyRequest, Donor } from '../types';
import { dbService } from '../services/dbService';

interface HospitalDonationCompletedProps {
  currentRequest: EmergencyRequest | null;
  onDonationRecorded: () => void;
  onBackToGps: () => void;
}

export const HospitalDonationCompleted: React.FC<HospitalDonationCompletedProps> = ({
  currentRequest,
  onDonationRecorded,
  onBackToGps,
}) => {
  const [requests, setRequests] = useState<EmergencyRequest[]>([]);
  const [selectedReq, setSelectedReq] = useState<EmergencyRequest | null>(currentRequest);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [selectedDonorId, setSelectedDonorId] = useState<string>('DNR-1000'); // Hilda Sharline by default

  // Form fields
  const [donorName, setDonorName] = useState('Hilda Sharline');
  const [bloodGroup, setBloodGroup] = useState('O-');
  const [unitsDonated, setUnitsDonated] = useState<number>(1);
  const [bagBarcode, setBagBarcode] = useState(`BAG-SMC-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}-O-NEG`);
  const [attendingDoctor, setAttendingDoctor] = useState('Dr. K. Meenakshi, MD (Transfusion Medicine)');
  const [hospitalName, setHospitalName] = useState('Srinivasan Medical College & Hospital, Samayapuram');
  const [phlebotomyStation, setPhlebotomyStation] = useState('Donor Recliner #03, Blood Bank Division');
  const [preDonationHb, setPreDonationHb] = useState('14.2 g/dL');
  const [preDonationBp, setPreDonationBp] = useState('118/76 mmHg');
  const [screeningStatus, setScreeningStatus] = useState('All 5 Serology Markers Non-Reactive (Passed)');
  const [notes, setNotes] = useState('Patient transfusion handover completed with zero adverse reactions.');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completionSuccess, setCompletionSuccess] = useState(false);

  useEffect(() => {
    const rList = dbService.getRequests();
    const dList = dbService.getDonors();
    setRequests(rList);
    setDonors(dList);

    if (currentRequest) {
      setSelectedReq(currentRequest);
      setHospitalName(currentRequest.hospitalName || 'Srinivasan Medical College & Hospital');
      setBloodGroup(currentRequest.bloodGroup || 'O-');
    } else if (rList.length > 0) {
      setSelectedReq(rList[0]);
      setHospitalName(rList[0].hospitalName || 'Srinivasan Medical College & Hospital');
      setBloodGroup(rList[0].bloodGroup || 'O-');
    }

    // Default to Hilda Sharline if present
    const hilda = dList.find(d => d.fullName === 'Hilda Sharline') || dList[0];
    if (hilda) {
      setSelectedDonorId(hilda.id);
      setDonorName(hilda.fullName);
      setBloodGroup(hilda.bloodGroup);
    }
  }, [currentRequest]);

  const handleSelectDonor = (donorId: string) => {
    setSelectedDonorId(donorId);
    const d = donors.find(x => x.id === donorId);
    if (d) {
      setDonorName(d.fullName);
      setBloodGroup(d.bloodGroup);
      setBagBarcode(`BAG-APO-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}-${d.bloodGroup.replace('+', 'POS').replace('-', 'NEG')}`);
    }
  };

  const handleConfirmCompletion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReq) return;

    setIsSubmitting(true);

    try {
      dbService.completeDonationAtHospital({
        requestId: selectedReq.id,
        donorId: selectedDonorId,
        donorName,
        bloodGroup: bloodGroup as any,
        unitsDonated,
        bagBarcode,
        attendingDoctor,
        hospitalName,
        phlebotomyStation,
        patientName: selectedReq.patientName,
        notes,
      });

      setCompletionSuccess(true);
      setTimeout(() => {
        onDonationRecorded();
      }, 700);
    } catch (err: any) {
      alert(err.message || 'Error recording hospital donation completion.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-700/80 text-emerald-300 text-xs font-bold mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>DASHBOARD 5 · BLOOD DONATION COMPLETED AT HOSPITAL</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Building2 className="w-6 h-6 text-emerald-400" />
            <span>Blood Donation Completed At Hospital</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Official hospital blood bank phlebotomy completion log. Authorizes collection, verifies blood bag barcode, passes clinical safety vitals, and confirms patient transfusion handover.
          </p>
        </div>

        {/* Case Switcher */}
        {requests.length > 1 && (
          <div className="flex items-center gap-2 shrink-0">
            <label className="text-xs text-slate-400 font-medium">Emergency Requisition:</label>
            <select
              value={selectedReq?.id || ''}
              onChange={(e) => {
                const found = requests.find(r => r.id === e.target.value);
                if (found) {
                  setSelectedReq(found);
                  setHospitalName(found.hospitalName);
                }
              }}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-hidden"
            >
              {requests.map(r => (
                <option key={r.id} value={r.id}>
                  {r.referenceId} ({r.patientName} · {r.bloodGroup})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {completionSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 text-sm flex items-center justify-between shadow-xl animate-in fade-in duration-300">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold text-white">Donation Completed and Verified by Hospital Staff!</p>
              <p className="text-xs text-emerald-300 font-mono">
                Bag ID: <strong className="text-white underline">{bagBarcode}</strong> · Updating Registry in Dashboard 6...
              </p>
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-emerald-400 animate-pulse" />
        </div>
      )}

      {/* Main Clinical Completion Form */}
      <form onSubmit={handleConfirmCompletion} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        
        {/* Section 1: Donor & Recipient Verification */}
        <div className="space-y-4">
          <div className="border-b border-slate-800 pb-2 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-emerald-400" />
              <span>1. Donor &amp; Recipient Verification</span>
            </h3>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2.5 py-0.5 rounded">
              Verified at Apollo Blood Bank
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Donor Select */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Attending Blood Donor <span className="text-rose-500">*</span>
              </label>
              <select
                value={selectedDonorId}
                onChange={(e) => handleSelectDonor(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs text-white font-semibold focus:outline-hidden transition-colors"
              >
                {donors.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.fullName} ({d.bloodGroup} · {d.phone})
                  </option>
                ))}
              </select>
            </div>

            {/* Blood Group */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Collected Blood Group <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                readOnly
                value={bloodGroup}
                className="w-full bg-slate-950 border border-emerald-500/80 rounded-xl px-4 py-2.5 text-sm text-emerald-400 font-mono font-black focus:outline-hidden"
              />
            </div>

            {/* Recipient Patient */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Recipient Emergency Patient
              </label>
              <input
                type="text"
                readOnly
                value={`${selectedReq?.patientName || 'Anita Ramesh'} (${selectedReq?.referenceId || 'REF-ER-2026-0881'})`}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-200 font-mono focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Blood Bag Barcode & Medical Specification */}
        <div className="space-y-4 pt-2">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Barcode className="w-4 h-4 text-sky-400" />
              <span>2. Blood Unit Barcode &amp; Phlebotomy Details</span>
            </h3>
            <p className="text-[11px] text-slate-400">ISBT-128 standard medical barcode and volume identification</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Blood Bag Barcode */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Blood Bag Barcode / Lot ID <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={bagBarcode}
                  onChange={(e) => setBagBarcode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs text-emerald-400 font-mono font-bold focus:outline-hidden"
                />
              </div>
            </div>

            {/* Units Donated */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Volume Drawn <span className="text-rose-500">*</span>
              </label>
              <select
                value={unitsDonated}
                onChange={(e) => setUnitsDonated(parseInt(e.target.value, 10))}
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:outline-hidden"
              >
                <option value={1}>1 Unit (450 mL Whole Blood / PRBC)</option>
                <option value={2}>2 Units (900 mL Double Unit)</option>
              </select>
            </div>

            {/* Phlebotomy Station */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Hospital Donation Station
              </label>
              <input
                type="text"
                value={phlebotomyStation}
                onChange={(e) => setPhlebotomyStation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Hospital Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Receiving Hospital
              </label>
              <input
                type="text"
                value={hospitalName}
                onChange={(e) => setHospitalName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112
              </p>
            </div>

            {/* Attending Doctor */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Attending Transfusion Officer / Phlebotomist <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={attendingDoctor}
                onChange={(e) => setAttendingDoctor(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Clinical Vitals & Screening Checklist */}
        <div className="space-y-4 pt-2">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>3. Donor Safety Vitals &amp; Infection Serology Screening</span>
            </h3>
            <p className="text-[11px] text-slate-400">Pre-donation clinical vitals passed in accordance with transfusion guidelines</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Hemoglobin Level</span>
              <strong className="text-emerald-400 font-mono text-base block mt-0.5">{preDonationHb}</strong>
              <span className="text-[10px] text-slate-500">Normal Range (12.5 - 16.5 g/dL)</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Blood Pressure &amp; Pulse</span>
              <strong className="text-emerald-400 font-mono text-base block mt-0.5">{preDonationBp} · 72 bpm</strong>
              <span className="text-[10px] text-slate-500">Normotensive, Regular Rhythm</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Infection Markers</span>
              <strong className="text-emerald-400 font-mono text-xs block mt-1">Non-Reactive (Passed)</strong>
              <span className="text-[10px] text-slate-500">HIV, HBV, HCV, Syphilis, MP Cleared</span>
            </div>
          </div>
        </div>

        {/* Bottom Prominent Confirmation Button */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBackToGps}
            className="text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            ← Back to Live Donor GPS &amp; Route
          </button>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full sm:w-auto px-10 py-4 rounded-xl text-sm font-black text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 shadow-xl shadow-emerald-950/60 transition-all flex items-center justify-center gap-3 cursor-pointer group disabled:opacity-50"
          >
            <CheckCircle2 className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
            <span>CONFIRM BLOOD DONATION COMPLETED AT HOSPITAL</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </form>
    </div>
  );
};
