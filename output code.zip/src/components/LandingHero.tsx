import React, { useState } from 'react';
import { 
  Heart, 
  Sparkles, 
  ShieldCheck, 
  FileSpreadsheet, 
  Send, 
  Activity, 
  ArrowRight, 
  Lock, 
  CheckCircle2,
  Clock,
  MapPin,
  Building2,
  PlayCircle
} from 'lucide-react';

interface LandingHeroProps {
  onGetStarted: () => void;
  onOpenExcelUpload: () => void;
  onOpenEmergencyRequest: () => void;
  onStartDemo: () => void;
  totalDonors: number;
  availableDonors: number;
  emergencyCount: number;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onGetStarted,
  onOpenExcelUpload,
  onOpenEmergencyRequest,
  onStartDemo,
  totalDonors,
  availableDonors,
  emergencyCount,
}) => {
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminUsername, setAdminUsername] = useState('admin@bloodnet.org');
  const [adminPassword, setAdminPassword] = useState('••••••••••••');
  const [loginSuccess, setLoginSuccess] = useState(false);

  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginSuccess(true);
    setTimeout(() => {
      setShowAdminLogin(false);
      onGetStarted();
    }, 600);
  };

  return (
    <div className="relative overflow-hidden bg-slate-950 border-b border-slate-800 py-12 lg:py-16">
      {/* Background Subtle Gradient Mesh */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(225,29,72,0.15),rgba(15,23,42,0))] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Title, Description, CTAs */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-500"></span>
              <span>Next-Gen Healthcare Technology</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-400">Final-Year B.Tech Academic Capstone</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight text-balance">
              AI-Based Blood Donor Identification &amp; Emergency Response System
            </h1>

            <p className="text-base text-slate-300 leading-relaxed max-w-2xl">
              An intelligent, end-to-end clinical platform that couples <strong>AABB Transfusion Compatibility</strong> and <strong>Decision Tree + Random Forest Heuristics</strong> with automated <strong>SMS &amp; Gmail dispatch</strong>, instant <strong>YES/NO recognition</strong>, and sequential cascading response logic.
            </p>

            {/* Quick Action CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onGetStarted}
                className="flex items-center gap-2 px-5 py-3 text-sm font-bold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 rounded-lg shadow-md transition-colors"
              >
                <span>Launch Admin Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onStartDemo}
                className="flex items-center gap-2 px-5 py-3 text-sm font-semibold text-amber-200 bg-amber-950/60 hover:bg-amber-900/60 border border-amber-700/80 rounded-lg transition-colors"
              >
                <PlayCircle className="w-4 h-4 text-amber-400" />
                <span>5-Minute Viva Demo</span>
              </button>

              <button
                onClick={() => setShowAdminLogin(true)}
                className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors"
              >
                <Lock className="w-4 h-4 text-slate-400" />
                <span>Admin Login</span>
              </button>
            </div>

            {/* Key Verification Badges */}
            <div className="flex items-center gap-6 pt-4 text-xs text-slate-400 border-t border-slate-800">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>AABB Verified Rules</span>
              </div>
              <div className="flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4 text-sky-400" />
                <span>Excel &amp; CSV Parser</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Send className="w-4 h-4 text-indigo-400" />
                <span>Twilio / MSG91 Webhook</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Healthcare Overview Card */}
          <div className="lg:col-span-5">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-rose-600/20 text-rose-500 flex items-center justify-center font-bold">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Live Emergency Command</h3>
                    <p className="text-xs text-slate-400">Regional Blood Bank Intelligence</p>
                  </div>
                </div>
                <span className="text-xs font-mono font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2.5 py-0.5 rounded">
                  System Active
                </span>
              </div>

              {/* 3 Metric Stat Blocks */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3 text-center">
                  <span className="block text-xl font-bold text-white font-mono tabular-nums">{totalDonors}</span>
                  <span className="text-[11px] text-slate-400 font-medium">Registered Donors</span>
                </div>
                <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3 text-center">
                  <span className="block text-xl font-bold text-emerald-400 font-mono tabular-nums">{availableDonors}</span>
                  <span className="text-[11px] text-slate-400 font-medium">Available Now</span>
                </div>
                <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3 text-center">
                  <span className="block text-xl font-bold text-rose-400 font-mono tabular-nums">{emergencyCount}</span>
                  <span className="text-[11px] text-slate-400 font-medium">Emergencies</span>
                </div>
              </div>

              {/* Live Pipeline Flow Preview */}
              <div className="space-y-2.5 text-xs">
                <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5 flex items-start gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-rose-950 text-rose-400 border border-rose-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                    1
                  </div>
                  <div>
                    <strong className="text-slate-200">Clinical Triage:</strong>
                    <p className="text-slate-400">Emergency request receives AABB cross-match &amp; 90-day recovery audit.</p>
                  </div>
                </div>

                <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5 flex items-start gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-sky-950 text-sky-400 border border-sky-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                    2
                  </div>
                  <div>
                    <strong className="text-slate-200">AI Scoring &amp; Ranking:</strong>
                    <p className="text-slate-400">Ensemble ranks candidates by proximity (Haversine), reliability &amp; availability.</p>
                  </div>
                </div>

                <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5 flex items-start gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                    3
                  </div>
                  <div>
                    <strong className="text-slate-200">Sequential Dispatch:</strong>
                    <p className="text-slate-400">Top candidate contacted via SMS/Gmail. YES locks donor; NO automatically cascades.</p>
                  </div>
                </div>
              </div>

              {/* Quick Triggers */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={onOpenEmergencyRequest}
                  className="flex-1 py-2 text-xs font-semibold text-white bg-rose-700 hover:bg-rose-600 rounded-lg transition-colors text-center"
                >
                  + Raise Emergency Request
                </button>
                <button
                  onClick={onOpenExcelUpload}
                  className="flex-1 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors text-center"
                >
                  Import Excel Dataset
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Admin Login Modal */}
      {showAdminLogin && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-md w-full shadow-2xl relative">
            <h3 className="text-lg font-bold text-white mb-1">Healthcare Administrator Access</h3>
            <p className="text-xs text-slate-400 mb-4">
              Enter your credential to access the hospital blood-bank management console.
            </p>

            <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Admin Email</label>
                <input
                  type="email"
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-hidden focus:border-rose-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-hidden focus:border-rose-500"
                  required
                />
              </div>

              <div className="p-2.5 rounded bg-slate-950 border border-slate-800 text-[11px] text-slate-400">
                <span>Demo Credentials: </span>
                <strong className="text-slate-200">admin@bloodnet.org</strong> / <strong className="text-slate-200">hospital#2026</strong>
              </div>

              {loginSuccess && (
                <div className="flex items-center gap-2 text-xs text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Authenticated successfully. Redirecting...</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdminLogin(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors"
                >
                  Authorize &amp; Enter
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
