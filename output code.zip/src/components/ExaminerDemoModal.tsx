import React, { useState } from 'react';
import { 
  Play, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  X, 
  Sparkles, 
  FileSpreadsheet, 
  UserPlus, 
  AlertCircle, 
  Send, 
  Smartphone, 
  Activity, 
  BarChart3, 
  ShieldCheck,
  Check
} from 'lucide-react';
import { dbService } from '../services/dbService';
import { notificationService } from '../services/notificationService';
import { runAiDonorMatching } from '../services/aiMatchingEngine';
import { downloadSampleExcelTemplate } from '../utils/excelHandler';
import confetti from 'canvas-confetti';

interface ExaminerDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: any) => void;
}

interface DemoStep {
  step: number;
  title: string;
  badge: string;
  objective: string;
  vivaTalkingPoints: string;
  actionButtonLabel: string;
  targetTab: string;
  executeAction: () => string;
}

export const ExaminerDemoModal: React.FC<ExaminerDemoModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [actionFeedback, setActionFeedback] = useState<string>('');

  if (!isOpen) return null;

  const demoSteps: DemoStep[] = [
    {
      step: 1,
      title: 'Introduction & Healthcare Architecture',
      badge: 'Architecture',
      objective: 'Present system overview, AABB clinical standards, and 20 integrated healthcare modules.',
      vivaTalkingPoints: 'Good morning Respected Examiners. Our project addresses critical blood shortages in emergency trauma care. Unlike static blood-bank registries, our system is an end-to-end intelligent platform combining AABB clinical rules, Decision Tree recovery verification, and Random Forest ensemble heuristic ranking with real-time automated SMS and Gmail cascading.',
      actionButtonLabel: 'Go to Overview Dashboard',
      targetTab: 'overview',
      executeAction: () => {
        return 'Overview Dashboard loaded. Displaying real-time registry and emergency case counts.';
      }
    },
    {
      step: 2,
      title: 'Excel & CSV Dataset Bulk Ingestion & Validation',
      badge: 'Data Layer',
      objective: 'Demonstrate bulk Excel upload, row-by-row schema validation, duplicate detection, and sample template export.',
      vivaTalkingPoints: 'The administrator can import bulk hospital donor datasets via Excel or CSV. Every record is audited for phone validity (10 digits), clinical email format, approved ABO/Rh blood groups, and prior registration duplicates. Invalid records are isolated and valid ones are committed to persistent storage.',
      actionButtonLabel: 'Download Sample Excel Template',
      targetTab: 'donors',
      executeAction: () => {
        downloadSampleExcelTemplate();
        return 'Standard blood donor template (blood_donors_template.xlsx) downloaded successfully.';
      }
    },
    {
      step: 3,
      title: 'Manual Clinical Donor Registration & Consent',
      badge: 'NBTC Compliance',
      objective: 'Showcase NBTC safety criteria (Age 18-65, Min weight 50kg, and emergency notification consent).',
      vivaTalkingPoints: 'For walk-in donors or hospital camps, manual registration validates age (18-65) and weight (>=50kg). Explicit consent is recorded to comply with privacy and emergency callout regulations.',
      actionButtonLabel: 'Open Manual Registration Form',
      targetTab: 'donors',
      executeAction: () => {
        return 'Navigated to Donor Registration. Form validates 10-digit phone and NBTC clinical parameters.';
      }
    },
    {
      step: 4,
      title: 'Emergency Patient Blood Requisition Triage',
      badge: 'Clinical Case',
      objective: 'Submit a critical emergency request for rare universal donor O- Negative at Apollo Hospital.',
      vivaTalkingPoints: 'When a severe trauma case arrives at the emergency room, hospital medical staff raise a requisition specifying patient reference ID, required units, component (e.g. PRBC or Whole Blood), and emergency priority level (Critical, Urgent, Normal).',
      actionButtonLabel: 'View Active Emergency Cases',
      targetTab: 'requests',
      executeAction: () => {
        return 'Emergency request queue loaded. Case REF-ER-2026-0881 (2 Units O- Negative) ready for matching.';
      }
    },
    {
      step: 5,
      title: 'AABB Clinical Transfusion Compatibility',
      badge: 'Clinical Rulebook',
      objective: 'Verify donor-recipient compatibility rules for Red Blood Cells, Platelets, and Fresh Frozen Plasma.',
      vivaTalkingPoints: 'Our system enforces approved AABB cross-matching standards. For instance, O- is the universal RBC donor, AB+ is the universal recipient, while for Plasma (FFP), AB is the universal donor. Incompatible donors are filtered out at the entry gate.',
      actionButtonLabel: 'Inspect AABB Compatibility',
      targetTab: 'ai-matching',
      executeAction: () => {
        return 'AABB compatibility matrix verified: O- matched for recipient O-.';
      }
    },
    {
      step: 6,
      title: 'AI Decision Tree Eligibility Filtering',
      badge: 'Decision Tree ML',
      objective: 'Audit mandatory 90-day donation interval, active availability, consent, and operational radius.',
      vivaTalkingPoints: 'Before ranking, candidates pass through a sequential Decision Tree. A candidate who donated 25 days ago is rejected with a clear explanation: "Donated 25 days ago; mandatory recovery requires 90 days." This prevents donor fatigue and honors medical safety.',
      actionButtonLabel: 'Execute AI Decision Tree',
      targetTab: 'ai-matching',
      executeAction: () => {
        const req = dbService.getRequests()[0];
        const res = runAiDonorMatching(req);
        return `Decision Tree evaluated ${res.totalDonorsEvaluated} donors: ${res.eligibleCount} Passed, ${res.ineligibleCount} Ineligible/Resting.`;
      }
    },
    {
      step: 7,
      title: 'Random Forest Multi-Factor Heuristic Ranking',
      badge: 'Ensemble ML',
      objective: 'Calculate composite match score combining Compatibility (35%), Proximity (25%), Recency (20%), and Reliability (20%).',
      vivaTalkingPoints: 'Eligible candidates are ranked by a Random Forest multi-factor model. Distance is calculated via the Haversine spherical formula between donor address and hospital coordinates. Reliability factors in historical attendance rate. Candidates are grouped into Tier 1 (Optimal), Tier 2 (Compatible), and Tier 3 (Reserve).',
      actionButtonLabel: 'Inspect Candidate Rankings',
      targetTab: 'ai-matching',
      executeAction: () => {
        return 'Rankings computed: #1 Candidate identified with 94.6 composite match score and 8-minute ETA.';
      }
    },
    {
      step: 8,
      title: 'Automated SMS & Gmail Notification Dispatch',
      badge: 'Dispatch Engine',
      objective: 'Dispatch Twilio/MSG91 compliant emergency SMS and responsive Gmail notification to #1 candidate.',
      vivaTalkingPoints: 'The system automatically dispatches an urgent SMS and Gmail alert with explicit YES/NO instructions to the highest-priority candidate. Live delivery logs record carrier delivery receipts without exposing private API credentials.',
      actionButtonLabel: 'Dispatch Emergency Alert to #1 Candidate',
      targetTab: 'notifications',
      executeAction: () => {
        const req = dbService.getRequests()[0];
        const res = notificationService.startEmergencyDispatch(req);
        return `Emergency alert dispatched to ${res.dispatchedTo?.donor.fullName || 'Candidate'}. Webhook cascade timer running (30s timeout).`;
      }
    },
    {
      step: 9,
      title: 'Automatic Webhook YES / NO Recognition',
      badge: 'NLP & Webhooks',
      objective: 'Simulate donor replying YES/NO to demonstrate automatic response parsing and state updates.',
      vivaTalkingPoints: 'When the donor replies to the SMS, our backend webhook intercepts the message, identifies the registered donor by phone, links them to the active request, and records the timestamp. A "YES" reply marks them as "WILLING TO BE CONTACTED" and locks the transfusion allocation.',
      actionButtonLabel: 'Simulate Donor Reply: YES',
      targetTab: 'live-monitor',
      executeAction: () => {
        const notifs = dbService.getNotifications();
        const phone = notifs[0]?.donorPhone || '+91 98401 23456';
        notificationService.handleIncomingResponse({
          phoneOrEmail: phone,
          responseType: 'YES',
          rawText: 'YES, I can reach Apollo Hospital in 20 minutes',
          channel: 'SMS',
        });
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
        return 'Donor response recognized: WILLING TO BE CONTACTED. Hospital staff alerted immediately.';
      }
    },
    {
      step: 10,
      title: 'Automatic Next-Donor Cascading Sequence',
      badge: 'State Machine',
      objective: 'Demonstrate sequential fallback: If Donor 1 replies NO or times out, system automatically alerts Donor 2.',
      vivaTalkingPoints: 'A vital innovation is intelligent sequential cascading. If Donor 1 declines (NO) or does not reply within the configured timeout, our system automatically advances to Candidate #2 without requiring manual human re-triage, saving precious minutes in trauma situations.',
      actionButtonLabel: 'Simulate Donor 1 Decline (Auto-Cascade to Donor 2)',
      targetTab: 'live-monitor',
      executeAction: () => {
        const notifs = dbService.getNotifications();
        const phone = notifs[0]?.donorPhone || '+91 98401 23456';
        const res = notificationService.handleIncomingResponse({
          phoneOrEmail: phone,
          responseType: 'NO',
          rawText: 'NO, I am currently out of town',
          channel: 'SMS',
        });
        return `Donor declined. Cascade engine automatically triggered alert to next candidate: ${res.nextDonorDispatched?.donor.fullName || 'Next Donor'}.`;
      }
    },
    {
      step: 11,
      title: 'Real-Time Admin Response Monitoring & GIS Map',
      badge: 'Live Telemetry',
      objective: 'Inspect live table updates without page refresh and Haversine proximity radar mapping.',
      vivaTalkingPoints: 'The administrator monitors response progression on a live dashboard updating in real-time. The GIS Map displays the hospital epicenter with 10km, 25km, and 50km radius perimeters, allowing medical officers to visualize donor proximity.',
      actionButtonLabel: 'Open Regional GIS Proximity Map',
      targetTab: 'map',
      executeAction: () => {
        return 'GIS Proximity Radar loaded. Donors mapped by geographic coordinates relative to hospital hub.';
      }
    },
    {
      step: 12,
      title: 'Analytics, Audit Trail & Academic Report Export',
      badge: 'Evaluation Ready',
      objective: 'Showcase blood stock distribution, response time analytics, and export final project evaluation report.',
      vivaTalkingPoints: 'Finally, our analytics module tracks inventory distribution, response ratios, and average turnaround times. An immutable audit trail records every clinical decision, and the evaluation report can be exported directly to Excel or printed as a PDF for university submission.',
      actionButtonLabel: 'Open Analytics & Export Report',
      targetTab: 'analytics',
      executeAction: () => {
        return 'Evaluation Report loaded. Ready for Excel export and printable examination summary.';
      }
    }
  ];

  const currentStep = demoSteps[currentStepIndex];

  const handleNext = () => {
    if (currentStepIndex < demoSteps.length - 1) {
      const nextIdx = currentStepIndex + 1;
      setCurrentStepIndex(nextIdx);
      setActionFeedback('');
      onNavigateTab(demoSteps[nextIdx].targetTab);
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      const prevIdx = currentStepIndex - 1;
      setCurrentStepIndex(prevIdx);
      setActionFeedback('');
      onNavigateTab(demoSteps[prevIdx].targetTab);
    }
  };

  const handleExecute = () => {
    const feedback = currentStep.executeAction();
    setActionFeedback(feedback);
    onNavigateTab(currentStep.targetTab);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-rose-600/20 text-rose-500 border border-rose-500/30 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">External Examiner Viva Voce Walkthrough</h3>
              <p className="text-xs text-slate-400">Step {currentStep.step} of 12 · {currentStep.title}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Step Pill & Objective */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800">
                {currentStep.badge}
              </span>
              <span className="text-xs font-bold text-white">Module Objective:</span>
            </div>
            <p className="text-sm font-medium text-slate-200 bg-slate-950 p-3 rounded-xl border border-slate-800">
              {currentStep.objective}
            </p>
          </div>

          {/* Viva Talking Points */}
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-slate-200">Recommended Viva Voce Talking Points for Student:</span>
            </div>
            <div className="text-xs text-slate-300 leading-relaxed bg-slate-950/70 p-4 rounded-xl border border-slate-800/80 italic">
              "{currentStep.vivaTalkingPoints}"
            </div>
          </div>

          {/* Live Action Feedback */}
          {actionFeedback && (
            <div className="p-3 rounded-lg bg-emerald-950/80 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{actionFeedback}</span>
            </div>
          )}
        </div>

        {/* Footer Navigation & Execution Controls */}
        <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              disabled={currentStepIndex === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white disabled:opacity-40 disabled:pointer-events-none bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>
            <span className="text-xs font-mono text-slate-400 px-2">
              {currentStepIndex + 1} / {demoSteps.length}
            </span>
            <button
              onClick={handleNext}
              disabled={currentStepIndex === demoSteps.length - 1}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white disabled:opacity-40 disabled:pointer-events-none bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExecute}
              className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 rounded-lg shadow-sm transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>{currentStep.actionButtonLabel}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
