import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  Sliders, 
  Send, 
  MapPin, 
  Clock, 
  User, 
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Info,
  MessageCircle,
  Mail,
  Phone,
  ExternalLink,
  Search,
  Filter,
  Lock,
  Activity,
  HeartCrack,
  Navigation
} from 'lucide-react';
import { EmergencyRequest, DonorMatch, SystemConfig, Donor } from '../types';
import { runAiDonorMatching, MatchingResult, IneligibleCandidate } from '../services/aiMatchingEngine';
import { 
  notificationService, 
  getDirectWhatsAppUrl, 
  getNativeSmsUrl, 
  getGmailWebComposeUrl 
} from '../services/notificationService';
import { dbService } from '../services/dbService';
import { calculateNextEligibleDate } from '../utils/bloodCompatibility';

interface AiMatchingViewProps {
  selectedRequest: EmergencyRequest | null;
  onRequestChange: (req: EmergencyRequest) => void;
  onInitiateDispatchSuccess: () => void;
}

export const AiMatchingView: React.FC<AiMatchingViewProps> = ({
  selectedRequest,
  onRequestChange,
  onInitiateDispatchSuccess,
}) => {
  const [requests, setRequests] = useState<EmergencyRequest[]>([]);
  const [activeReq, setActiveReq] = useState<EmergencyRequest | null>(selectedRequest);
  const [matchingResult, setMatchingResult] = useState<MatchingResult | null>(null);
  
  // Weights adjustment drawer
  const [showWeightSliders, setShowWeightSliders] = useState(false);
  const [weights, setWeights] = useState<SystemConfig['weights']>({
    compatibility: 0.35,
    proximity: 0.25,
    recency: 0.20,
    reliability: 0.20,
  });

  const [dispatchStatus, setDispatchStatus] = useState<string>('');

  // Ineligible candidates filtering & search
  const [ineligibleFilter, setIneligibleFilter] = useState<'ALL' | 'COOLDOWN_40D' | 'DISTANCE_FAR' | 'MEDICAL' | 'INCOMPATIBLE'>('ALL');
  const [ineligibleSearch, setIneligibleSearch] = useState('');

  // Confirm Donor & proceed directly to Dashboard 4 (Live GPS) without popper/confetti
  const handleConfirmDonor = (donor: Donor) => {
    if (!activeReq) return;
    setDispatchStatus(`Confirming donor ${donor.fullName} for emergency requisition ${activeReq.referenceId}...`);

    // 1. Update request status to DONOR_ACCEPTED
    const updated = dbService.updateRequest(activeReq.id, {
      status: 'DONOR_ACCEPTED',
      acceptedDonorId: donor.id,
      acceptedDonorName: donor.fullName,
      acceptedDonorEtaMinutes: 20,
      unitsFulfilled: Math.min(activeReq.unitsRequired, (activeReq.unitsFulfilled || 0) + 1),
    });
    if (updated) {
      setActiveReq(updated);
      onRequestChange(updated);
    }

    // 2. Add an incoming YES response to database
    dbService.addResponse({
      requestId: activeReq.id,
      donorId: donor.id,
      donorName: donor.fullName,
      donorPhone: donor.phone,
      responseType: 'YES',
      rawText: 'Yes, available.',
      channel: 'GMAIL',
      actionTaken: `Donor ${donor.fullName} confirmed acceptance. Transferred to Dashboard 4 (Live GPS Location Tracking).`,
      cascadedToNext: false,
    });

    // 3. Add audit log
    dbService.addAuditLog(
      'Medical Coordinator',
      'DONOR_CONFIRMED',
      `Donor ${donor.fullName} (${donor.bloodGroup}) confirmed for emergency request ${activeReq.referenceId}. Proceeding to Live GPS Route.`,
      'SUCCESS'
    );

    // 4. Smooth immediate transition to Dashboard 4 (No party poppers / confetti)
    setDispatchStatus(`✓ Donor ${donor.fullName} Confirmed! Opening Live Donor GPS Location Tracking...`);
    setTimeout(() => {
      onInitiateDispatchSuccess();
    }, 350);
  };

  useEffect(() => {
    const list = dbService.getRequests();
    setRequests(list);
    const active = selectedRequest || list[0] || null;
    setActiveReq(active);
    if (active) {
      const res = runAiDonorMatching(active, weights);
      setMatchingResult(res);
    }
  }, [selectedRequest]);

  const handleSelectRequest = (reqId: string) => {
    const target = requests.find(r => r.id === reqId || r.referenceId === reqId);
    if (target) {
      setActiveReq(target);
      onRequestChange(target);
      const res = runAiDonorMatching(target, weights);
      setMatchingResult(res);
      setDispatchStatus('');
    }
  };

  const handleWeightChange = (key: keyof SystemConfig['weights'], val: number) => {
    const updated = { ...weights, [key]: val };
    setWeights(updated);
    if (activeReq) {
      const res = runAiDonorMatching(activeReq, updated);
      setMatchingResult(res);
    }
  };

  const handleStartDispatch = () => {
    if (!activeReq) return;
    setDispatchStatus('Dispatching emergency alerts to #1 ranked candidate...');
    const result = notificationService.startEmergencyDispatch(activeReq);
    if (result.dispatchedTo) {
      setDispatchStatus(`Emergency alert successfully dispatched to ${result.dispatchedTo.donor.fullName} via SMS & Gmail. Cascade listener initiated.`);
      setTimeout(() => {
        onInitiateDispatchSuccess();
      }, 900);
    } else {
      setDispatchStatus('Dispatch completed or all eligible donors already in contact sequence.');
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-6xl mx-auto">
      {/* Top Header & Request Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-800/80 text-rose-300 text-xs font-bold mb-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>DASHBOARD 3 · AI-ASSISTED DONOR IDENTIFICATION AND SELECTION</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-rose-500" />
            <span>AI Donor Identification &amp; Selection Engine</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            AABB Biological Compatibility Matrix · Mandatory 90-Day Clinical Interval Decision Tree · Random Forest Multi-Factor Ranking Ensemble (Compatibility, Proximity, Recency, Reliability).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs text-slate-400 font-medium shrink-0">Emergency Case:</label>
          <select
            value={activeReq?.id || ''}
            onChange={(e) => handleSelectRequest(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
          >
            {requests.map(r => (
              <option key={r.id} value={r.id}>
                {r.referenceId} - {r.patientName} ({r.bloodGroup} {r.unitsRequired}U @ {r.hospitalName})
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowWeightSliders(!showWeightSliders)}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border transition-colors shrink-0 ${
              showWeightSliders
                ? 'bg-rose-950 text-rose-300 border-rose-800'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Tune ML Weights</span>
          </button>
        </div>
      </div>

      {/* Weight Tuning Collapsible Drawer */}
      {showWeightSliders && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-white">Random Forest Ensemble Scoring Weights</h4>
              <p className="text-[11px] text-slate-400">
                Adjust the clinical weight matrix. Rankings and composite scores dynamically recalculate.
              </p>
            </div>
            <button
              onClick={() => {
                const def = { compatibility: 0.35, proximity: 0.25, recency: 0.20, reliability: 0.20 };
                setWeights(def);
                if (activeReq) setMatchingResult(runAiDonorMatching(activeReq, def));
              }}
              className="text-xs text-rose-400 hover:underline"
            >
              Reset to Clinical Defaults
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-1">
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Compatibility:</span>
                <span className="font-mono text-rose-400 font-bold">{Math.round(weights.compatibility * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.60"
                step="0.05"
                value={weights.compatibility}
                onChange={(e) => handleWeightChange('compatibility', parseFloat(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Proximity (Distance):</span>
                <span className="font-mono text-sky-400 font-bold">{Math.round(weights.proximity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.50"
                step="0.05"
                value={weights.proximity}
                onChange={(e) => handleWeightChange('proximity', parseFloat(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer"
              />
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Interval / Recency:</span>
                <span className="font-mono text-emerald-400 font-bold">{Math.round(weights.recency * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.40"
                step="0.05"
                value={weights.recency}
                onChange={(e) => handleWeightChange('recency', parseFloat(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span>Reliability:</span>
                <span className="font-mono text-teal-400 font-bold">{Math.round(weights.reliability * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.40"
                step="0.05"
                value={weights.reliability}
                onChange={(e) => handleWeightChange('reliability', parseFloat(e.target.value))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* Case Overview & Candidate Metrics Bar */}
      {activeReq && matchingResult && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
            <span className="text-[10px] text-slate-400 block">Patient Need</span>
            <span className="text-xl font-extrabold text-rose-400 font-mono">
              {activeReq.unitsRequired} Units {activeReq.bloodGroup}
            </span>
            <span className="text-[10px] text-slate-400 block truncate">{activeReq.hospitalName}</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
            <span className="text-[10px] text-slate-400 block">Donors Evaluated</span>
            <span className="text-xl font-bold text-white font-mono tabular-nums">
              {matchingResult.totalDonorsEvaluated}
            </span>
            <span className="text-[10px] text-slate-400 block">Database Query</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
            <span className="text-[10px] text-slate-400 block">Clinical Eligible</span>
            <span className="text-xl font-bold text-emerald-400 font-mono tabular-nums">
              {matchingResult.eligibleCount}
            </span>
            <span className="text-[10px] text-emerald-300 block">Passed Decision Tree</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
            <span className="text-[10px] text-slate-400 block">Ineligible / Rest</span>
            <span className="text-xl font-bold text-amber-400 font-mono tabular-nums">
              {matchingResult.ineligibleCount}
            </span>
            <span className="text-[10px] text-slate-400 block">Rest Period / Incompatible</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 block">Emergency Dispatch</span>
            <button
              onClick={handleStartDispatch}
              disabled={matchingResult.eligibleCount === 0}
              className="w-full py-1.5 px-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded text-xs font-bold transition-colors shadow-xs"
            >
              Start Auto-Dispatch
            </button>
          </div>
        </div>
      )}

      {dispatchStatus && (
        <div className="p-3 rounded-lg bg-emerald-950/80 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{dispatchStatus}</span>
        </div>
      )}

      {/* Main Ranking Results List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-rose-500" />
            <span>Prioritized Candidate Ranking (Random Forest Multi-Factor Model)</span>
          </h3>
          <span className="text-xs text-slate-400">
            Ranked by Composite Score (0-100)
          </span>
        </div>

        {matchingResult?.rankedCandidates.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-400">
            <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-white mb-1">No Eligible Candidates Found</h4>
            <p className="text-xs max-w-md mx-auto">
              All registered donors for this blood group are either currently resting (&lt;90 days), outside operational radius, or busy.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {matchingResult?.rankedCandidates.map((candidate) => {
              const isAlreadyDispatched = activeReq?.dispatchedDonorIds?.includes(candidate.donorId);
              const isAccepted = activeReq?.acceptedDonorId === candidate.donorId;

              return (
                <div
                  key={candidate.donorId}
                  className={`bg-slate-900 border rounded-xl p-4 transition-all ${
                    isAccepted
                      ? 'border-emerald-500 bg-emerald-950/20'
                      : candidate.rankingPosition === 1
                      ? 'border-rose-500/80 shadow-md shadow-rose-950/20'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    
                    {/* Rank Badge & Donor Info */}
                    <div className="flex items-start sm:items-center gap-3">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-mono font-extrabold text-sm shrink-0 ${
                        candidate.rankingPosition === 1 
                          ? 'bg-rose-600 text-white' 
                          : candidate.rankingPosition === 2
                          ? 'bg-sky-600 text-white'
                          : 'bg-slate-800 text-slate-300'
                      }`}>
                        #{candidate.rankingPosition}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">{candidate.donor.fullName}</h4>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                            candidate.donor.bloodGroup.includes('-')
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-slate-800 text-slate-300'
                          }`}>
                            {candidate.donor.bloodGroup}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            candidate.tier === 'TIER_1_OPTIMAL'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : candidate.tier === 'TIER_2_COMPATIBLE'
                              ? 'bg-sky-950 text-sky-400 border border-sky-800'
                              : 'bg-slate-800 text-slate-400'
                          }`}>
                            {candidate.tier.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          {candidate.matchExplanation}
                        </p>
                      </div>
                    </div>

                    {/* Composite Score Bar & Actions */}
                    <div className="flex items-center gap-4 self-end sm:self-center shrink-0">
                      <div className="text-right">
                        <div className="text-xs text-slate-400">Match Score</div>
                        <div className="text-xl font-black text-rose-400 font-mono tabular-nums">
                          {candidate.compositeScore}
                          <span className="text-xs text-slate-500 font-normal">/100</span>
                        </div>
                      </div>

                      {isAccepted ? (
                        <span className="px-3.5 py-2 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-400 text-xs font-bold">
                          ✓ ACCEPTED DONOR
                        </span>
                      ) : isAlreadyDispatched ? (
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1.5 rounded-xl bg-sky-950 border border-sky-800 text-sky-400 text-xs font-medium">
                            Alert Sent · Waiting
                          </span>
                          {/* Direct External Action Triggers */}
                          {activeReq && (
                            <div className="flex items-center gap-1.5">
                              <a
                                href={getDirectWhatsAppUrl(activeReq, candidate.donor.fullName, candidate.donor.phone)}
                                target="_blank"
                                rel="noopener noreferrer"
                                title="Open WhatsApp alert to this donor"
                                className="p-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                              </a>
                              <a
                                href={getNativeSmsUrl(activeReq, candidate.donor.fullName, candidate.donor.phone)}
                                title="Open phone SMS app"
                                className="p-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                              >
                                <Phone className="w-3.5 h-3.5" />
                              </a>
                              <a
                                href={getGmailWebComposeUrl(activeReq, candidate.donor.fullName, candidate.donor.email)}
                                target="_blank"
                                rel="noopener noreferrer"
                                title="Open pre-filled Gmail alert"
                                className="p-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                              >
                                <Mail className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            onClick={() => {
                              if (activeReq) {
                                notificationService.dispatchToDonor(activeReq, candidate, 'BOTH');
                                setDispatchStatus(`Emergency alert dispatched to #${candidate.rankingPosition} ${candidate.donor.fullName} via SMS & Gmail.`);
                                setTimeout(() => {
                                  onInitiateDispatchSuccess();
                                }, 900);
                              }
                            }}
                            className={`px-4 py-2 text-xs font-black text-white rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer ${
                              candidate.rankingPosition === 1
                                ? 'bg-rose-600 hover:bg-rose-500 active:bg-rose-700 shadow-rose-900/40 ring-1 ring-rose-400'
                                : 'bg-slate-800 hover:bg-slate-700 border border-slate-700'
                            }`}
                          >
                            <Send className="w-3.5 h-3.5 text-white" />
                            <span>{candidate.rankingPosition === 1 ? 'Send Emergency Alert' : 'Dispatch Single'}</span>
                          </button>

                          {/* Direct Instant Action Links */}
                          {activeReq && (
                            <div className="flex items-center gap-1">
                              <a
                                href={getDirectWhatsAppUrl(activeReq, candidate.donor.fullName, candidate.donor.phone)}
                                target="_blank"
                                rel="noopener noreferrer"
                                title="Send WhatsApp alert to mobile number"
                                onClick={() => {
                                  if (activeReq) notificationService.dispatchToDonor(activeReq, candidate, 'SMS');
                                }}
                                className="px-2.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">WhatsApp</span>
                              </a>

                              <a
                                href={getNativeSmsUrl(activeReq, candidate.donor.fullName, candidate.donor.phone)}
                                title="Open phone default SMS app"
                                onClick={() => {
                                  if (activeReq) notificationService.dispatchToDonor(activeReq, candidate, 'SMS');
                                }}
                                className="px-2.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                              >
                                <Phone className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">SMS</span>
                              </a>

                              <a
                                href={getGmailWebComposeUrl(activeReq, candidate.donor.fullName, candidate.donor.email)}
                                target="_blank"
                                rel="noopener noreferrer"
                                title="Open pre-filled Gmail alert"
                                onClick={() => {
                                  if (activeReq) notificationService.dispatchToDonor(activeReq, candidate, 'GMAIL');
                                }}
                                className="px-2.5 py-2 rounded-xl bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                              >
                                <Mail className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">Gmail</span>
                              </a>

                              {/* Prominent Donor Confirmed button */}
                              {candidate.donor.fullName === 'Hilda Sharline' && (
                                <button
                                  onClick={() => handleConfirmDonor(candidate.donor)}
                                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-xs font-black transition-all shadow-md flex items-center gap-1.5 cursor-pointer border border-emerald-400 shrink-0"
                                  title="Confirm Hilda Sharline as accepted donor and proceed to Live GPS Tracking"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-100" />
                                  <span>Donor Confirmed →</span>
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Demonstration Donor Highlight Banner for Hilda Sharline */}
                  {candidate.donor.fullName === 'Hilda Sharline' && activeReq && (
                    <div className="mt-3 p-4 rounded-xl bg-gradient-to-r from-rose-950/70 via-slate-900 to-slate-950 border-2 border-rose-500/80 text-xs text-rose-200 space-y-4 shadow-xl">
                      {/* Top Eligibility Status Row */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-rose-800/60 gap-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                          <h5 className="font-extrabold text-white text-sm tracking-tight">
                            Hilda Sharline · Blood Donation Eligibility Status
                          </h5>
                        </div>
                        <span className="px-3 py-1 rounded-full text-[11px] font-black bg-emerald-950 text-emerald-300 border border-emerald-500 flex items-center gap-1.5 self-start sm:self-auto">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          <span>ELIGIBLE TO DONATE BLOOD NOW (IMMEDIATELY)</span>
                        </span>
                      </div>

                      {/* 3 Clinical Columns */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-semibold uppercase">LAST BLOOD DONATION</span>
                          <strong className="text-amber-300 font-mono text-base block mt-0.5">
                            170 Days Ago
                          </strong>
                          <div className="text-[11px] text-slate-300 mt-0.5">
                            Mandatory 90-day rest period completed (+80 buffer days)
                          </div>
                        </div>

                        <div className="bg-slate-950/80 p-3 rounded-lg border border-emerald-900/60 ring-1 ring-emerald-500/30">
                          <span className="text-[10px] text-emerald-400 block font-semibold uppercase">WHEN CAN SHE DONATE BLOOD?</span>
                          <strong className="text-emerald-400 font-mono text-base block mt-0.5">
                            Eligible Today (NOW)
                          </strong>
                          <div className="text-[11px] text-slate-300 mt-0.5">
                            Hemoglobin (14.2 g/dL) &amp; vitals fully replenished
                          </div>
                        </div>

                        <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-semibold uppercase">NEXT DONATION IF DONATED TODAY</span>
                          <strong className="text-sky-300 font-mono text-base block mt-0.5">
                            After 90 Days
                          </strong>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            Standard clinical RBC interval starts after donation
                          </div>
                        </div>
                      </div>

                      {/* Hospital Destination & Distance Row */}
                      <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                        <div className="space-y-1">
                          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Target Emergency Medical Center:</span>
                          <strong className="text-white text-xs block">Srinivasan Medical College &amp; Hospital (Multi-speciality)</strong>
                          <span className="text-[11px] text-slate-300 block">NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112 · Phone: 0431-2677777</span>
                          <a
                            href={`https://maps.google.com/?q=${encodeURIComponent('Srinivasan Medical College & Hospital, NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-950/80 hover:bg-sky-900 border border-sky-600/70 text-sky-200 hover:text-white text-[11px] font-bold transition-all shadow-sm mt-1 cursor-pointer"
                            title="Touch or click to open live location directly in Google Maps mobile app"
                          >
                            <MapPin className="w-3.5 h-3.5 text-sky-400" />
                            <span>📍 Touch Address to Open in Google Maps (Mobile Navigation)</span>
                            <ExternalLink className="w-3 h-3 text-sky-300" />
                          </a>
                        </div>
                        <div className="text-left sm:text-right shrink-0">
                          <span className="text-[10px] text-emerald-400 uppercase font-bold block">APPROXIMATE DISTANCE &amp; TIMING</span>
                          <strong className="text-emerald-300 font-mono text-xs block">1–3 km · 15–30 minutes</strong>
                          <span className="text-[10px] text-slate-400">Via NH-45 Highway Service Route</span>
                        </div>
                      </div>

                      {/* Manual WhatsApp & Email Action Section */}
                      <div className="pt-2 border-t border-rose-900/60 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold text-white flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                            <span>Manual User Messaging (Send WhatsApp &amp; Email Alert to Donor):</span>
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            Direct manual action links
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2.5">
                          {/* Manual WhatsApp Message Button */}
                          <a
                            href={getDirectWhatsAppUrl(activeReq, candidate.donor.fullName, candidate.donor.phone)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
                          >
                            <MessageCircle className="w-4 h-4" />
                            <span>Send Manual WhatsApp Message (8778434228)</span>
                            <ExternalLink className="w-3.5 h-3.5 text-emerald-200" />
                          </a>

                          {/* Manual Email / Gmail Message Button */}
                          <a
                            href={getGmailWebComposeUrl(activeReq, candidate.donor.fullName, candidate.donor.email)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
                          >
                            <Mail className="w-4 h-4" />
                            <span>Send Manual Email (hilda.sharline.dh@gmail.com)</span>
                            <ExternalLink className="w-3.5 h-3.5 text-rose-200" />
                          </a>

                          {/* Manual Mobile SMS Button */}
                          <a
                            href={getNativeSmsUrl(activeReq, candidate.donor.fullName, candidate.donor.phone)}
                            className="px-3.5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
                          >
                            <Phone className="w-4 h-4" />
                            <span>Mobile SMS (8778434228)</span>
                          </a>

                          {/* "Donor Confirmed" prominent click button */}
                          <button
                            onClick={() => handleConfirmDonor(candidate.donor)}
                            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-black text-xs shadow-lg shadow-emerald-950/70 border-2 border-emerald-300 transition-all flex items-center gap-2 cursor-pointer ring-2 ring-emerald-500/50 group shrink-0"
                            title="Confirm Hilda Sharline as accepted donor and navigate directly to Dashboard 4 (Live GPS Tracking)"
                          >
                            <CheckCircle2 className="w-4 h-4 text-emerald-100 group-hover:scale-110 transition-transform" />
                            <span>✓ Donor Confirmed (Go to Live GPS) →</span>
                          </button>
                        </div>

                        {/* Emergency Notification & Maps Link Preview */}
                        <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 text-[11px] text-slate-300 space-y-1.5 font-mono">
                          <div className="flex items-center justify-between text-xs text-rose-300 font-sans font-bold">
                            <span className="flex items-center gap-1.5">
                              <Mail className="w-3.5 h-3.5 text-rose-400" />
                              <span>Emergency Email &amp; Mobile Navigation Format:</span>
                            </span>
                            <span className="text-[10px] text-slate-400 font-normal">Pre-filled in Gmail Compose</span>
                          </div>
                          <div className="text-slate-400 text-[10px] leading-relaxed space-y-0.5">
                            <div>Hospital: <strong className="text-white">Srinivasan Medical College &amp; Hospital</strong></div>
                            <div>Address: <span className="text-slate-200">NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112</span></div>
                            <div className="text-sky-300 flex items-center gap-1">
                              <span>🗺️ Touch Link:</span>
                              <a 
                                href={`https://maps.google.com/?q=${encodeURIComponent('Srinivasan Medical College & Hospital, NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112')}`}
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="underline hover:text-sky-200"
                              >
                                maps.google.com (Tap to Open Native Google Maps App on Mobile) ↗
                              </a>
                            </div>
                            <div className="text-slate-300">Reply prompt: <span className="text-emerald-300 font-semibold">Reply "YES" if you can attend or "NO" if unavailable</span></div>
                            <div className="text-slate-400">Signature: <span className="text-amber-300 font-semibold">Thank you, hilda</span></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Feature Breakdown Subscores */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-slate-400">
                    <div>
                      <span>Compatibility: </span>
                      <strong className="text-white font-mono">{candidate.compatibilityScore}%</strong>
                    </div>
                    <div>
                      <span>Proximity (Haversine): </span>
                      <strong className="text-sky-300 font-mono">{candidate.distanceKm} km ({candidate.proximityScore} pts)</strong>
                    </div>
                    <div>
                      <span>Recency Freshness: </span>
                      <strong className="text-emerald-300 font-mono">{candidate.recencyScore} pts</strong>
                    </div>
                    <div>
                      <span>Attendance History: </span>
                      <strong className="text-teal-300 font-mono">{candidate.reliabilityScore}%</strong>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ============================================================== */}
      {/* SECTION: EVALUATED INELIGIBLE DONORS REGISTRY & CLINICAL TRIAGE */}
      {/* User requested: Hilda Sharline #1, and below her, lots of donors */}
      {/* displayed with realistic ineligibility (e.g. 40 days cooldown,   */}
      {/* far away distance, low hemoglobin, underweight, etc.)           */}
      {/* ============================================================== */}
      {matchingResult && (
        <div className="space-y-4 pt-4 border-t border-slate-800/80">
          {/* Section Header & Ineligibility Stats */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-950/80 border border-amber-800/80 text-amber-300 text-xs font-bold mb-1.5">
                  <HeartCrack className="w-3.5 h-3.5 text-amber-400" />
                  <span>AABB CLINICAL DECISION TREE · EVALUATED REGIONAL DONORS ({matchingResult.ineligibleCount} INELIGIBLE)</span>
                </div>
                <h3 className="text-lg font-black text-white tracking-tight flex items-center gap-2">
                  <span>Evaluated Regional Donors Triage &amp; Clinical Deferrals</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 max-w-3xl">
                  <strong>#1 Candidate Hilda Sharline</strong> is fully eligible and ready for immediate dispatch. Below are the other <strong>{matchingResult.ineligibleCount} registered donors</strong> evaluated against clinical criteria who are currently <strong>INELIGIBLE</strong> (e.g., donated blood 40 days ago, distance far away &gt; 50km, low hemoglobin, or blood mismatch).
                </p>
              </div>

              {/* Search bar inside Ineligible Donors section */}
              <div className="relative w-full md:w-72 shrink-0">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter by name, city, phone..."
                  value={ineligibleSearch}
                  onChange={(e) => setIneligibleSearch(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-rose-500"
                />
              </div>
            </div>

            {/* Ineligibility Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/80">
              <span className="text-xs text-slate-400 font-semibold flex items-center gap-1 mr-1">
                <Filter className="w-3.5 h-3.5 text-slate-500" />
                <span>Filter By Ineligibility Reason:</span>
              </span>

              <button
                onClick={() => setIneligibleFilter('ALL')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  ineligibleFilter === 'ALL'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                All Evaluated Donors ({matchingResult.ineligibleCount})
              </button>

              <button
                onClick={() => setIneligibleFilter('COOLDOWN_40D')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  ineligibleFilter === 'COOLDOWN_40D'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-slate-950 text-amber-400 hover:text-amber-300 border border-amber-900/50'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Donated 40 Days Ago / Rest ({matchingResult.rejectedCandidates.filter(c => c.ineligibilityType === 'COOLDOWN_INTERVAL').length})</span>
              </button>

              <button
                onClick={() => setIneligibleFilter('DISTANCE_FAR')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  ineligibleFilter === 'DISTANCE_FAR'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'bg-slate-950 text-sky-400 hover:text-sky-300 border border-sky-900/50'
                }`}
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>Distance Far Away &gt; 50km ({matchingResult.rejectedCandidates.filter(c => c.ineligibilityType === 'DISTANCE_FAR_AWAY').length})</span>
              </button>

              <button
                onClick={() => setIneligibleFilter('MEDICAL')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  ineligibleFilter === 'MEDICAL'
                    ? 'bg-rose-700 text-white shadow-xs'
                    : 'bg-slate-950 text-rose-400 hover:text-rose-300 border border-rose-900/50'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Low Hemoglobin &amp; Weight ({matchingResult.rejectedCandidates.filter(c => c.ineligibilityType === 'LOW_HEMOGLOBIN' || c.ineligibilityType === 'UNDERWEIGHT').length})</span>
              </button>

              <button
                onClick={() => setIneligibleFilter('INCOMPATIBLE')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  ineligibleFilter === 'INCOMPATIBLE'
                    ? 'bg-slate-700 text-white shadow-xs'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>Blood Mismatch &amp; Other ({matchingResult.rejectedCandidates.filter(c => c.ineligibilityType === 'BLOOD_INCOMPATIBLE' || c.ineligibilityType === 'UNAVAILABLE' || c.ineligibilityType === 'CONSENT_OPT_OUT').length})</span>
              </button>
            </div>
          </div>

          {/* Cards List for Ineligible Donors */}
          <div className="space-y-3.5">
            {matchingResult.rejectedCandidates
              .filter((item) => {
                // Category Filter
                if (ineligibleFilter === 'COOLDOWN_40D' && item.ineligibilityType !== 'COOLDOWN_INTERVAL') return false;
                if (ineligibleFilter === 'DISTANCE_FAR' && item.ineligibilityType !== 'DISTANCE_FAR_AWAY') return false;
                if (ineligibleFilter === 'MEDICAL' && item.ineligibilityType !== 'LOW_HEMOGLOBIN' && item.ineligibilityType !== 'UNDERWEIGHT') return false;
                if (ineligibleFilter === 'INCOMPATIBLE' && item.ineligibilityType !== 'BLOOD_INCOMPATIBLE' && item.ineligibilityType !== 'UNAVAILABLE' && item.ineligibilityType !== 'CONSENT_OPT_OUT') return false;

                // Search Filter
                if (ineligibleSearch.trim()) {
                  const q = ineligibleSearch.toLowerCase().trim();
                  return (
                    item.donor.fullName.toLowerCase().includes(q) ||
                    item.donor.city.toLowerCase().includes(q) ||
                    item.donor.phone.includes(q) ||
                    item.donor.bloodGroup.toLowerCase().includes(q) ||
                    item.reason.toLowerCase().includes(q) ||
                    item.ineligibilityBadge.toLowerCase().includes(q)
                  );
                }
                return true;
              })
              .map((item, idx) => {
                const displayRank = idx + 2; // Hilda is #1, these follow below
                const cooldownPercentage = Math.min(100, Math.round((item.daysSinceLastDonation / 90) * 100));
                const nextEligibleStr = calculateNextEligibleDate(item.donor.lastDonationDate);

                return (
                  <div
                    key={item.donor.id}
                    className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 sm:p-5 transition-all hover:border-slate-700/80 space-y-3 shadow-md"
                  >
                    {/* Top Row: Rank, Donor Name, Contact, & Ineligible Badge */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start sm:items-center gap-3">
                        {/* Position Badge */}
                        <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 font-mono font-bold flex flex-col items-center justify-center shrink-0">
                          <span className="text-xs">#{displayRank}</span>
                          <span className="text-[8px] text-rose-400 font-semibold uppercase leading-none">NO</span>
                        </div>

                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="text-sm font-bold text-white">{item.donor.fullName}</h4>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              item.donor.bloodGroup.includes('-')
                                ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                : 'bg-slate-800 text-slate-300'
                            }`}>
                              {item.donor.bloodGroup}
                            </span>
                            <span className="text-xs text-slate-400">
                              {item.donor.age} yrs · {item.donor.gender}
                            </span>
                            <span className="text-xs text-slate-500 font-mono">
                              (ID: {item.donor.id})
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-xs text-slate-400 mt-1">
                            <span className="flex items-center gap-1 font-mono text-slate-300">
                              <Phone className="w-3 h-3 text-slate-500" />
                              <span>{item.donor.phone}</span>
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-slate-500" />
                              <strong className="text-slate-200">{item.donor.city}</strong>
                              <span className="text-slate-500">({item.distanceKm} km)</span>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Explicit INELIGIBILITY Badge */}
                      <div className="flex flex-col items-start sm:items-end gap-1 shrink-0">
                        <span className="px-3 py-1 rounded-full text-[11px] font-black bg-rose-950/80 text-rose-300 border border-rose-700/80 flex items-center gap-1.5 shadow-xs">
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                          <span>NOT ELIGIBLE FOR DISPATCH</span>
                        </span>
                        <span className="text-[10px] text-amber-400 font-mono font-semibold">
                          {item.ineligibilityBadge}
                        </span>
                      </div>
                    </div>

                    {/* Dedicated Feature Callout based on user prompt criteria */}
                    {/* Scenario 1: Blood Donated 40 Days Ago (Recent Donation Cooldown) */}
                    {item.ineligibilityType === 'COOLDOWN_INTERVAL' && (
                      <div className="p-3.5 rounded-xl bg-slate-950 border border-amber-900/60 text-xs space-y-2.5">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-slate-300">
                          <div className="flex items-center gap-2 font-bold text-amber-300">
                            <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                            <span>Donation Interval Violation: Donated Blood {item.daysSinceLastDonation} Days Ago</span>
                          </div>
                          <span className="text-[11px] font-mono text-amber-400 font-bold">
                            {item.daysRemaining} More Days Required For Cooldown
                          </span>
                        </div>

                        {/* Cooldown Visual Progress Bar */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                            <span>Cooldown Progress: {item.daysSinceLastDonation} / 90 Days Completed ({cooldownPercentage}%)</span>
                            <span className="text-amber-300 font-bold">50 Days Remaining</span>
                          </div>
                          <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
                            <div 
                              className="bg-gradient-to-r from-amber-600 to-rose-600 h-full rounded-full transition-all"
                              style={{ width: `${cooldownPercentage}%` }}
                            />
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] text-slate-400 pt-1 border-t border-slate-900">
                          <span>
                            Last Donated: <strong className="text-slate-200 font-mono">{item.donor.lastDonationDate}</strong> ({item.daysSinceLastDonation} days ago)
                          </span>
                          <span className="text-amber-300">
                            Next Eligible Date: <strong className="text-white font-mono">{nextEligibleStr}</strong> (Mandatory 90-day clinical rest)
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Scenario 2: Distance Far Away (> 50 km) */}
                    {item.ineligibilityType === 'DISTANCE_FAR_AWAY' && (
                      <div className="p-3.5 rounded-xl bg-slate-950 border border-sky-900/60 text-xs space-y-2">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-slate-300">
                          <div className="flex items-center gap-2 font-bold text-sky-300">
                            <Navigation className="w-4 h-4 text-sky-400 shrink-0" />
                            <span>Distance Far Away: {item.distanceKm} km from Srinivasan Medical College &amp; Hospital</span>
                          </div>
                          <span className="text-[11px] font-mono text-rose-400 font-bold">
                            Exceeds 50 km Operational Radius
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
                          <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                            <span className="text-[10px] text-slate-500 uppercase block">DONOR LOCATION</span>
                            <strong className="text-white">{item.donor.city} ({item.donor.address || 'Registered city'})</strong>
                          </div>
                          <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                            <span className="text-[10px] text-slate-500 uppercase block">ESTIMATED TRAVEL TIME</span>
                            <strong className="text-sky-300 font-mono">~{Math.round(item.distanceKm / 45 * 60)} mins ({(item.distanceKm / 45).toFixed(1)} hrs)</strong>
                          </div>
                          <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                            <span className="text-[10px] text-slate-500 uppercase block">CLINICAL DISPATCH RULE</span>
                            <strong className="text-rose-400">Locked (Too far for STAT emergency)</strong>
                          </div>
                        </div>

                        <p className="text-[11px] text-slate-400 pt-1">
                          Clinical rationale: Patient emergency in Trichy requires immediate blood transfusion. Donor in {item.donor.city} is {item.distanceKm} km away, which exceeds the safe maximum emergency response radius.
                        </p>
                      </div>
                    )}

                    {/* Scenario 3: Low Hemoglobin / Underweight */}
                    {(item.ineligibilityType === 'LOW_HEMOGLOBIN' || item.ineligibilityType === 'UNDERWEIGHT') && (
                      <div className="p-3.5 rounded-xl bg-slate-950 border border-rose-900/60 text-xs space-y-1.5">
                        <div className="flex items-center gap-2 font-bold text-rose-300">
                          <Activity className="w-4 h-4 text-rose-400 shrink-0" />
                          <span>
                            {item.ineligibilityType === 'LOW_HEMOGLOBIN' 
                              ? `Low Hemoglobin Level: ${item.donor.hemoglobinGdl || 10.2} g/dL (Clinical Safety Minimum: 12.5 g/dL)`
                              : `Donor Weight Below Safety Minimum: ${item.donor.weightKg} kg (Required Minimum: 50 kg)`}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">
                          {item.reason} In compliance with National Blood Transfusion Council regulations, donor is clinically deferred to safeguard personal health and avoid transfusion anemia.
                        </p>
                      </div>
                    )}

                    {/* Scenario 4: Blood Incompatible / Unavailable / Opt-Out */}
                    {(item.ineligibilityType === 'BLOOD_INCOMPATIBLE' || item.ineligibilityType === 'UNAVAILABLE' || item.ineligibilityType === 'CONSENT_OPT_OUT') && (
                      <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1.5">
                        <div className="flex items-center gap-2 font-bold text-slate-300">
                          <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          <span>{item.reason}</span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {item.ineligibilityType === 'BLOOD_INCOMPATIBLE'
                            ? `Donor blood group (${item.donor.bloodGroup}) cannot be cross-matched for an ${activeReq?.bloodGroup} recipient requiring ${activeReq?.componentNeeded}.`
                            : 'Donor is marked unavailable in the registry or has opted out of automated callout dispatch.'}
                        </p>
                      </div>
                    )}

                    {/* Decision Tree 5-Point Audit Breakdown & Disabled Action Button */}
                    <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      {/* Decision Tree Badges */}
                      <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-semibold">
                        <span className={`px-2 py-0.5 rounded ${
                          item.treeChecks.bloodCompatible 
                            ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60' 
                            : 'bg-rose-950 text-rose-400 border border-rose-800/80 font-bold'
                        }`}>
                          {item.treeChecks.bloodCompatible ? '✓ Blood Match' : '✗ Incompatible'}
                        </span>

                        <span className={`px-2 py-0.5 rounded ${
                          item.treeChecks.intervalEligible 
                            ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60' 
                            : 'bg-amber-950 text-amber-400 border border-amber-800/80 font-bold'
                        }`}>
                          {item.treeChecks.intervalEligible ? '✓ 90d Cooldown' : `✗ Rest (${item.daysSinceLastDonation}d/90d)`}
                        </span>

                        <span className={`px-2 py-0.5 rounded ${
                          item.treeChecks.withinOperationalRadius 
                            ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60' 
                            : 'bg-sky-950 text-sky-400 border border-sky-800/80 font-bold'
                        }`}>
                          {item.treeChecks.withinOperationalRadius ? '✓ &lt;50km Zone' : `✗ Far (${item.distanceKm}km)`}
                        </span>

                        <span className={`px-2 py-0.5 rounded ${
                          item.treeChecks.hemoglobinEligible && item.treeChecks.weightEligible
                            ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60' 
                            : 'bg-rose-950 text-rose-400 border border-rose-800/80 font-bold'
                        }`}>
                          {item.treeChecks.hemoglobinEligible && item.treeChecks.weightEligible ? '✓ Vitals &amp; Weight' : '✗ Vitals Fail'}
                        </span>

                        <span className={`px-2 py-0.5 rounded ${
                          item.treeChecks.availabilityConfirmed && item.treeChecks.consentGranted
                            ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60' 
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}>
                          {item.treeChecks.availabilityConfirmed && item.treeChecks.consentGranted ? '✓ Available' : '✗ Busy / No-Consent'}
                        </span>
                      </div>

                      {/* Locked Dispatch Action */}
                      <button
                        disabled
                        title="Dispatch locked: Donor is clinically ineligible."
                        className="px-3.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-500 font-bold text-xs flex items-center gap-1.5 cursor-not-allowed opacity-75 self-end sm:self-auto"
                      >
                        <Lock className="w-3.5 h-3.5 text-slate-600" />
                        <span>Dispatch Locked (Ineligible)</span>
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Clinical Verification Notice */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 flex items-start gap-3">
        <Info className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-200 block mb-0.5">Clinical Protocol &amp; Regulatory Disclaimer:</strong>
          <span>
            Blood group compatibility, donation intervals, and cross-matching logic are audited strictly in compliance with Association for the Advancement of Blood &amp; Biotherapies (AABB) and National Blood Transfusion Council regulations. Automated algorithms prioritize communication candidates; definitive transfusions must be physically cross-matched by licensed blood-bank pathologists.
          </span>
        </div>
      </div>
    </div>
  );
};
