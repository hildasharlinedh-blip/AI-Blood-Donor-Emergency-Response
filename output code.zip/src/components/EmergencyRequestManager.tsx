import React, { useState, useEffect } from 'react';
import { 
  AlertCircle, 
  Plus, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Building2, 
  Phone, 
  User, 
  Send,
  Eye,
  Filter,
  Check
} from 'lucide-react';
import { EmergencyRequest, BloodGroup, BloodComponent, UrgencyLevel, RequestStatus } from '../types';
import { dbService } from '../services/dbService';
import { VALID_BLOOD_GROUPS } from '../utils/excelHandler';

interface EmergencyRequestManagerProps {
  onSelectForMatching: (request: EmergencyRequest) => void;
  openCreateModalDirectly?: boolean;
}

export const EmergencyRequestManager: React.FC<EmergencyRequestManagerProps> = ({
  onSelectForMatching,
  openCreateModalDirectly = false,
}) => {
  const [requests, setRequests] = useState<EmergencyRequest[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(openCreateModalDirectly);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [viewDetailsRequest, setViewDetailsRequest] = useState<EmergencyRequest | null>(null);

  // New Request Form state
  const [formData, setFormData] = useState({
    patientName: '',
    patientAge: 32,
    patientGender: 'Female' as 'Male' | 'Female' | 'Other',
    bloodGroup: 'O-' as BloodGroup,
    componentNeeded: 'Red Blood Cells (PRBC)' as BloodComponent,
    unitsRequired: 2,
    hospitalName: 'Apollo Speciality Hospital',
    hospitalAddress: 'Greams Road, Thousand Lights',
    city: 'Chennai',
    urgency: 'CRITICAL' as UrgencyLevel,
    contactPerson: 'Dr. Mathivanan (ER Trauma)',
    contactPhone: '+91 44 2829 0200',
    diagnosis: 'Acute trauma with hemorrhagic shock',
    notes: 'Require immediate PRBC transfusion.',
  });

  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  const loadRequests = () => {
    setRequests(dbService.getRequests());
  };

  useEffect(() => {
    loadRequests();
    const unsubscribe = dbService.subscribe(loadRequests);
    return () => unsubscribe();
  }, []);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    if (!formData.patientName.trim()) {
      setFormError('Patient Name is required.');
      return;
    }
    if (formData.unitsRequired < 1) {
      setFormError('At least 1 blood unit must be requested.');
      return;
    }

    try {
      const created = dbService.createRequest({
        ...formData,
        location: {
          latitude: 13.0569,
          longitude: 80.2520,
          city: formData.city,
          address: formData.hospitalAddress,
        },
        requiredBefore: new Date(Date.now() + 4 * 3600000).toISOString(),
      });

      setFormSuccess(`Emergency Request ${created.referenceId} submitted to clinical triage.`);
      setTimeout(() => {
        setShowCreateModal(false);
        setFormSuccess('');
        onSelectForMatching(created);
      }, 700);
    } catch (err: any) {
      setFormError(err.message || 'Failed to submit emergency request.');
    }
  };

  const handleCancelRequest = (id: string, refId: string) => {
    const reason = window.prompt(`Enter reason for cancelling request ${refId}:`, 'Patient stabilized / alternate blood source arranged');
    if (reason) {
      dbService.cancelRequest(id, reason);
    }
  };

  const filteredRequests = requests.filter(r => {
    if (selectedStatusFilter === 'ALL') return true;
    return r.status === selectedStatusFilter;
  });

  const getStatusBadge = (status: RequestStatus) => {
    switch (status) {
      case 'PENDING':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-400 border border-amber-800">PENDING MATCH</span>;
      case 'DISPATCHED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-950 text-sky-400 border border-sky-800">ALERTS DISPATCHED</span>;
      case 'DONOR_ACCEPTED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">DONOR ACCEPTED</span>;
      case 'FULFILLED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-950 text-teal-300 border border-teal-800">FULFILLED</span>;
      case 'CANCELLED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">CANCELLED</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400">{status}</span>;
    }
  };

  const getUrgencyBadge = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'CRITICAL':
        return <span className="text-rose-400 font-bold">CRITICAL</span>;
      case 'URGENT':
        return <span className="text-amber-400 font-bold">URGENT</span>;
      default:
        return <span className="text-emerald-400 font-medium">NORMAL</span>;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Emergency Patient Request Module</h2>
          <p className="text-xs text-slate-400">
            Hospital blood requisition management, clinical priority triage, and direct AI donor matching handoff.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedStatusFilter}
            onChange={(e) => setSelectedStatusFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300 focus:outline-hidden focus:border-rose-500 font-medium"
          >
            <option value="ALL">All Request Statuses</option>
            <option value="PENDING">Pending Match</option>
            <option value="DISPATCHED">Dispatched / In Cascade</option>
            <option value="DONOR_ACCEPTED">Donor Accepted</option>
            <option value="FULFILLED">Fulfilled</option>
            <option value="CANCELLED">Cancelled</option>
          </select>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-lg shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create Emergency Request</span>
          </button>
        </div>
      </div>

      {/* Emergency Requests Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-slate-400">
                <th className="py-3 px-3.5 font-semibold">Reference ID</th>
                <th className="py-3 px-3.5 font-semibold">Patient</th>
                <th className="py-3 px-3.5 font-semibold">Blood Needed</th>
                <th className="py-3 px-3.5 font-semibold">Units (Req/Done)</th>
                <th className="py-3 px-3.5 font-semibold">Hospital &amp; City</th>
                <th className="py-3 px-3.5 font-semibold">Priority</th>
                <th className="py-3 px-3.5 font-semibold">Request Date</th>
                <th className="py-3 px-3.5 font-semibold text-center">Status</th>
                <th className="py-3 px-3.5 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredRequests.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    No emergency requests found for the selected filter.
                  </td>
                </tr>
              ) : (
                filteredRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 px-3.5 font-mono text-rose-400 font-bold whitespace-nowrap">
                      {req.referenceId}
                    </td>
                    <td className="py-3 px-3.5 text-white font-medium">
                      <div>{req.patientName}</div>
                      <div className="text-[11px] text-slate-400">{req.patientAge}y · {req.patientGender}</div>
                    </td>
                    <td className="py-3 px-3.5 font-mono">
                      <span className="text-base font-extrabold text-white mr-1.5">{req.bloodGroup}</span>
                      <span className="text-[10px] text-slate-400 font-sans block">{req.componentNeeded}</span>
                    </td>
                    <td className="py-3 px-3.5 font-mono tabular-nums text-slate-200">
                      <span className="text-emerald-400 font-bold">{req.unitsFulfilled}</span> / <span>{req.unitsRequired} Units</span>
                    </td>
                    <td className="py-3 px-3.5 text-slate-300">
                      <div className="font-medium text-white">{req.hospitalName}</div>
                      <div className="text-[11px] text-slate-400">{req.city}</div>
                    </td>
                    <td className="py-3 px-3.5 whitespace-nowrap font-mono text-[11px]">
                      {getUrgencyBadge(req.urgency)}
                    </td>
                    <td className="py-3 px-3.5 text-slate-400 font-mono tabular-nums whitespace-nowrap">
                      {new Date(req.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-3 px-3.5 text-center whitespace-nowrap">
                      {getStatusBadge(req.status)}
                    </td>
                    <td className="py-3 px-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectForMatching(req)}
                          title="Run AI Decision Tree & Random Forest Ranking"
                          className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-rose-300 bg-rose-950/70 hover:bg-rose-900 border border-rose-800/80 rounded transition-colors"
                        >
                          <Sparkles className="w-3 h-3 text-rose-400" />
                          <span>AI Match</span>
                        </button>
                        <button
                          onClick={() => setViewDetailsRequest(req)}
                          title="View patient history and clinical details"
                          className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {req.status !== 'CANCELLED' && req.status !== 'FULFILLED' && (
                          <button
                            onClick={() => handleCancelRequest(req.id, req.referenceId)}
                            title="Cancel Request"
                            className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
          <span>Active Patient Emergency Cases: {requests.filter(r => r.status === 'PENDING' || r.status === 'DISPATCHED').length}</span>
          <span className="font-mono text-emerald-400">Live Hospital Webhooks: Active</span>
        </div>
      </div>

      {/* CREATE EMERGENCY REQUEST MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-rose-500" />
                <span>Create Hospital Emergency Blood Requisition</span>
              </h3>
              <p className="text-xs text-slate-400">
                Submit an urgent patient request for automated clinical compatibility matching and donor alerts.
              </p>
            </div>

            {formSuccess && (
              <div className="mb-4 p-3 rounded-lg bg-emerald-950/70 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{formSuccess}</span>
              </div>
            )}

            {formError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-950/70 border border-rose-800 text-xs text-rose-300 flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              {/* Patient Info */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Patient Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Anita Ramesh"
                    value={formData.patientName}
                    onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Patient Age *</label>
                  <input
                    type="number"
                    min="1"
                    max="110"
                    required
                    value={formData.patientAge}
                    onChange={(e) => setFormData({ ...formData, patientAge: parseInt(e.target.value, 10) || 1 })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Blood Group & Component & Units */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Required Blood Group *</label>
                  <select
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value as BloodGroup })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                  >
                    {VALID_BLOOD_GROUPS.map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Blood Component *</label>
                  <select
                    value={formData.componentNeeded}
                    onChange={(e) => setFormData({ ...formData, componentNeeded: e.target.value as BloodComponent })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                  >
                    <option value="Red Blood Cells (PRBC)">Red Blood Cells (PRBC)</option>
                    <option value="Whole Blood">Whole Blood</option>
                    <option value="Platelets">Platelets</option>
                    <option value="Fresh Frozen Plasma (FFP)">Fresh Frozen Plasma (FFP)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Units Required *</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    required
                    value={formData.unitsRequired}
                    onChange={(e) => setFormData({ ...formData, unitsRequired: parseInt(e.target.value, 10) || 1 })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Hospital & City */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Hospital Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Apollo Speciality Hospital"
                    value={formData.hospitalName}
                    onChange={(e) => setFormData({ ...formData, hospitalName: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Chennai"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Priority & Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Emergency Priority *</label>
                  <select
                    value={formData.urgency}
                    onChange={(e) => setFormData({ ...formData, urgency: e.target.value as UrgencyLevel })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                  >
                    <option value="CRITICAL">CRITICAL (Immediate Transfusion Needed)</option>
                    <option value="URGENT">URGENT (Required within 2-4 Hours)</option>
                    <option value="NORMAL">NORMAL (Scheduled Surgery)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Hospital Contact Phone *</label>
                  <input
                    type="text"
                    required
                    placeholder="+91 44 2829 0200"
                    value={formData.contactPhone}
                    onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Diagnosis / Clinical Indication</label>
                <input
                  type="text"
                  placeholder="e.g. Post-partum hemorrhage with acute hypovolemic shock"
                  value={formData.diagnosis}
                  onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-lg shadow-sm"
                >
                  Submit &amp; Launch AI Match
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW DETAILS MODAL */}
      {viewDetailsRequest && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <h3 className="text-base font-bold text-white">Emergency Case Details</h3>
                <p className="text-xs font-mono text-rose-400">{viewDetailsRequest.referenceId}</p>
              </div>
              {getStatusBadge(viewDetailsRequest.status)}
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="grid grid-cols-2 gap-2">
                  <div>Patient: <strong className="text-white">{viewDetailsRequest.patientName}</strong> ({viewDetailsRequest.patientAge}y, {viewDetailsRequest.patientGender})</div>
                  <div>Blood Group: <strong className="text-rose-400 font-mono text-sm">{viewDetailsRequest.bloodGroup}</strong></div>
                  <div>Component: <span className="text-slate-200">{viewDetailsRequest.componentNeeded}</span></div>
                  <div>Units: <strong className="text-white">{viewDetailsRequest.unitsFulfilled} / {viewDetailsRequest.unitsRequired}</strong></div>
                </div>
              </div>

              <div>Hospital: <strong className="text-white">{viewDetailsRequest.hospitalName}</strong></div>
              <div>Address: <span className="text-slate-400">{viewDetailsRequest.hospitalAddress}, {viewDetailsRequest.city}</span></div>
              <div>Clinical Diagnosis: <span className="text-slate-200">{viewDetailsRequest.diagnosis}</span></div>
              <div>Hospital Contact: <span className="text-sky-400 font-mono">{viewDetailsRequest.contactPhone}</span></div>
              
              {viewDetailsRequest.acceptedDonorName && (
                <div className="p-2.5 rounded bg-emerald-950/70 border border-emerald-800 text-emerald-300">
                  Accepted Donor: <strong>{viewDetailsRequest.acceptedDonorName}</strong> (ETA ~{viewDetailsRequest.acceptedDonorEtaMinutes} mins)
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-800 mt-4">
              <button
                onClick={() => setViewDetailsRequest(null)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const req = viewDetailsRequest;
                  setViewDetailsRequest(null);
                  onSelectForMatching(req);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-lg"
              >
                Launch AI Matching
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
