import React from 'react';
import { 
  Heart, 
  Sparkles, 
  Activity, 
  AlertCircle,
  Navigation,
  Building2,
  Award
} from 'lucide-react';
import { SystemConfig } from '../types';

export type NavTab = 
  | 'dashboard-1'
  | 'dashboard-2'
  | 'dashboard-3'
  | 'dashboard-4'
  | 'dashboard-5'
  | 'dashboard-6';

interface HeaderNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  config: SystemConfig;
  onToggleMode: () => void;
  activeEmergencyCount: number;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeTab,
  onTabChange,
  config,
  onToggleMode,
  activeEmergencyCount,
}) => {
  const navItems: { id: NavTab; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard-1', label: '1. Request Form', icon: <AlertCircle className="w-3.5 h-3.5 text-rose-400" /> },
    { id: 'dashboard-2', label: '2. Request Details', icon: <AlertCircle className="w-3.5 h-3.5 text-amber-400" /> },
    { id: 'dashboard-3', label: '3. AI Matching', icon: <Sparkles className="w-3.5 h-3.5 text-sky-400" /> },
    { id: 'dashboard-4', label: '4. Live Donor GPS', icon: <Navigation className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'dashboard-5', label: '5. Donation Completed At Hospital', icon: <Building2 className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'dashboard-6', label: '6. Donation Record Updated', icon: <Award className="w-3.5 h-3.5 text-rose-400" /> },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
      {/* Top Banner Zone: Strict 3-Zone Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-rose-600/20 border border-rose-500/30 flex items-center justify-center text-rose-500 shadow-sm">
            <Heart className="w-5 h-5 fill-rose-500/20" />
          </div>
          <button 
            onClick={() => onTabChange('dashboard-1')}
            className="text-left font-bold text-white text-base tracking-tight hover:text-rose-400 transition-colors whitespace-nowrap shrink-0"
          >
            Remix AI Blood Donor &amp; Emergency Response
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-4 xl:gap-5 text-xs font-semibold text-slate-300">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex items-center gap-1.5 py-1 px-1.5 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === item.id 
                  ? 'text-rose-400 font-bold underline underline-offset-8 decoration-rose-500 decoration-2' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Zone 3: Mode Switcher */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onToggleMode}
            title="Click to toggle between Test Simulation Mode and Live API Mode"
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              config.mode === 'TEST'
                ? 'bg-amber-950/60 text-amber-300 border-amber-800 hover:bg-amber-900/50'
                : 'bg-emerald-950/60 text-emerald-300 border-emerald-800 hover:bg-emerald-900/50'
            }`}
          >
            Mode: {config.mode === 'TEST' ? 'TEST SIMULATION' : 'REAL API'}
          </button>
        </div>
      </div>

      {/* Mobile / Compact Sub-Navigation Bar */}
      <div className="lg:hidden bg-slate-950/90 border-t border-slate-800/80 px-4 py-2 overflow-x-auto">
        <div className="flex items-center gap-2 min-w-max">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-slate-800 text-rose-400 font-bold border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
