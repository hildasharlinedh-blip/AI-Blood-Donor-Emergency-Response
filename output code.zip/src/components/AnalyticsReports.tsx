import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Download, 
  Printer, 
  FileSpreadsheet, 
  PieChart, 
  TrendingUp, 
  Clock, 
  Users, 
  MapPin, 
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { Donor, EmergencyRequest, NotificationLog, DonorResponse, BloodGroup } from '../types';
import { dbService } from '../services/dbService';
import { exportEmergencyAuditToExcel, exportDonorsToExcel, VALID_BLOOD_GROUPS } from '../utils/excelHandler';

export const AnalyticsReports: React.FC = () => {
  const [donors, setDonors] = useState<Donor[]>([]);
  const [requests, setRequests] = useState<EmergencyRequest[]>([]);
  const [notifications, setNotifications] = useState<NotificationLog[]>([]);
  const [responses, setResponses] = useState<DonorResponse[]>([]);

  useEffect(() => {
    setDonors(dbService.getDonors());
    setRequests(dbService.getRequests());
    setNotifications(dbService.getNotifications());
    setResponses(dbService.getResponses());
  }, []);

  // Blood Group Counts
  const bloodCounts = VALID_BLOOD_GROUPS.map(bg => ({
    bloodGroup: bg,
    count: donors.filter(d => d.bloodGroup === bg).length,
    available: donors.filter(d => d.bloodGroup === bg && d.isAvailable).length,
  }));
  const maxBloodCount = Math.max(...bloodCounts.map(b => b.count), 1);

  // City-wise Distribution
  const cityMap: Record<string, number> = {};
  donors.forEach(d => {
    cityMap[d.city] = (cityMap[d.city] || 0) + 1;
  });
  const cityDistribution = Object.entries(cityMap).map(([city, count]) => ({ city, count }));
  const maxCityCount = Math.max(...cityDistribution.map(c => c.count), 1);

  // Response Ratios
  const yesCount = responses.filter(r => r.responseType === 'YES').length;
  const noCount = responses.filter(r => r.responseType === 'NO').length;
  const timeoutCount = responses.filter(r => r.responseType === 'TIMEOUT').length;
  const totalResponses = responses.length;

  const handlePrintSummary = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 print:text-black print:bg-white">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800 print:hidden">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-rose-500" />
            <span>Clinical Analytics &amp; Project Evaluation Reports</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Statistical distribution, emergency cascade turnaround metrics, and academic audit export.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportEmergencyAuditToExcel}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4 text-sky-400" />
            <span>Export Audit (.xlsx)</span>
          </button>
          <button
            onClick={handlePrintSummary}
            className="flex items-center gap-1.5 px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold shadow-sm transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print Evaluation Report</span>
          </button>
        </div>
      </div>

      {/* Printable Evaluation Summary Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 print:border-none print:shadow-none print:bg-white print:text-black">
        <div className="border-b border-slate-800 pb-4">
          <h3 className="text-lg font-extrabold text-white print:text-black">
            AI-BASED BLOOD DONOR IDENTIFICATION &amp; EMERGENCY RESPONSE SYSTEM
          </h3>
          <p className="text-xs text-slate-400 print:text-gray-600 mt-1">
            Department of Information Technology · Final Year Academic Capstone Project Evaluation Report
          </p>
        </div>

        {/* 4 Top Statistical Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-xs text-slate-400 print:text-gray-500 block">Total Registry</span>
            <span className="text-2xl font-bold text-white font-mono tabular-nums print:text-black">{donors.length}</span>
            <span className="text-[10px] text-emerald-400 block mt-1">
              {donors.filter(d => d.isAvailable).length} Available for Dispatch
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-xs text-slate-400 print:text-gray-500 block">Emergency Requests</span>
            <span className="text-2xl font-bold text-rose-400 font-mono tabular-nums">{requests.length}</span>
            <span className="text-[10px] text-slate-400 block mt-1">
              {requests.filter(r => r.urgency === 'CRITICAL').length} Critical Trauma Cases
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-xs text-slate-400 print:text-gray-500 block">Notification Delivery</span>
            <span className="text-2xl font-bold text-sky-400 font-mono tabular-nums">
              {notifications.filter(n => n.status === 'DELIVERED').length} / {notifications.length}
            </span>
            <span className="text-[10px] text-sky-300 block mt-1">
              SMS &amp; Gmail Dispatches
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-xs text-slate-400 print:text-gray-500 block">YES/NO Acceptance</span>
            <span className="text-2xl font-bold text-teal-300 font-mono tabular-nums">
              {totalResponses > 0 ? Math.round((yesCount / totalResponses) * 100) : 0}%
            </span>
            <span className="text-[10px] text-teal-400 block mt-1">
              {yesCount} Confirmed Willing Donors
            </span>
          </div>
        </div>

        {/* Charts Grid: Blood Group Distribution & City Distribution */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Blood Group Distribution Bar Visual */}
          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50 space-y-3">
            <h4 className="text-xs font-bold text-white print:text-black uppercase tracking-wider">
              Blood Group Inventory Distribution (ABO / Rh System)
            </h4>
            <div className="space-y-2 pt-1">
              {bloodCounts.map(item => (
                <div key={item.bloodGroup} className="space-y-0.5">
                  <div className="flex justify-between text-xs">
                    <span className="font-mono font-bold text-slate-200 print:text-black">{item.bloodGroup}</span>
                    <span className="font-mono text-slate-400 print:text-gray-600">
                      {item.available} available / {item.count} total
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 print:bg-gray-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-rose-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${(item.count / maxBloodCount) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* City Distribution */}
          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50 space-y-3">
            <h4 className="text-xs font-bold text-white print:text-black uppercase tracking-wider">
              Regional Geographic Reach (City Breakdown)
            </h4>
            <div className="space-y-2 pt-1">
              {cityDistribution.map(item => (
                <div key={item.city} className="space-y-0.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-200 print:text-black font-medium">{item.city}</span>
                    <span className="font-mono text-slate-400 print:text-gray-600">{item.count} Donors</span>
                  </div>
                  <div className="w-full bg-slate-900 print:bg-gray-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-sky-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${(item.count / maxCityCount) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* System Highlights Table */}
        <div className="border-t border-slate-800 pt-4 text-xs text-slate-400 print:text-gray-600">
          <div className="font-semibold text-slate-200 print:text-black mb-2">Technical Evaluation Checklist Verified:</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>AABB Clinical Compatibility Matrix (RBC, FFP, Platelets)</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Haversine Geographical Proximity Engine</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Decision Tree (90-day recovery + NBTC age/weight rules)</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Random Forest Ensemble Multi-Factor Heuristic Ranking</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Automatic Sequential Cascading State Machine (Donor 1 → Donor 2)</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Excel (.xlsx/.csv) Bulk Dataset Ingestion &amp; Validation</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
