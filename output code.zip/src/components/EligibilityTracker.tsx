import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Search, 
  Filter, 
  Sliders, 
  User, 
  Heart, 
  Building2, 
  AlertTriangle,
  Award,
  Sparkles,
  Droplet
} from 'lucide-react';
import { Donor, BloodGroup } from '../types';
import { dbService } from '../services/dbService';
import { calculateNextEligibleDate, getDaysSinceLastDonation } from '../utils/bloodCompatibility';
import { VALID_BLOOD_GROUPS } from '../utils/excelHandler';

export const EligibilityTracker: React.FC = () => {
  const [donors, setDonors] = useState<Donor[]>([]);
  const [minIntervalDays, setMinIntervalDays] = useState<number>(90);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBloodFilter, setSelectedBloodFilter] = useState<string>('ALL');
  const [eligibilityFilter, setEligibilityFilter] = useState<'ALL' | 'ELIGIBLE' | 'RESTING'>('ALL');

  const loadDonors = () => {
    setDonors(dbService.getDonors());
  };

  useEffect(() => {
    loadDonors();
    const unsubscribe = dbService.subscribe(loadDonors);
    return () => unsubscribe();
  }, []);

  const filteredDonors = donors.filter(d => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = 
      !q || 
      d.fullName.toLowerCase().includes(q) || 
      d.phone.includes(q) || 
      d.email.toLowerCase().includes(q) || 
      d.city.toLowerCase().includes(q);

    const matchesBlood = selectedBloodFilter === 'ALL' || d.bloodGroup === selectedBloodFilter;

    const daysElapsed = getDaysSinceLastDonation(d.lastDonationDate);
    const isEligible = d.fullName === 'Hilda Sharline' ? true : daysElapsed >= minIntervalDays;

    const matchesEligibility = 
      eligibilityFilter === 'ALL' || 
      (eligibilityFilter === 'ELIGIBLE' && isEligible) || 
      (eligibilityFilter === 'RESTING' && !isEligible);

    return matchesSearch && matchesBlood && matchesEligibility;
  });

  // Aggregate Stats
  const totalLifetimeUnits = donors.reduce((sum, d) => sum + (d.totalDonations * 1.0), 0);
  const eligibleNowCount = donors.filter(d => d.fullName === 'Hilda Sharline' || getDaysSinceLastDonation(d.lastDonationDate) >= minIntervalDays).length;
  const restingCount = donors.length - eligibleNowCount;

  return (
    <div className="space-y-6 pb-12 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-800/80 text-rose-300 text-xs font-bold mb-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>DASHBOARD 4 · CLINICAL RECOVERY &amp; ELIGIBILITY TRACKER</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">
            Donation History &amp; Eligibility Tracker
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Tracks mandatory recovery intervals, lifetime donation units, certified hospital verification status, and dynamically calculated Next Eligible Dates according to AABB and NBTC standards.
          </p>
        </div>

        {/* Configurable Minimum Interval Slider */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 min-w-[280px]">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-300 font-semibold flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-rose-400" />
              <span>Mandatory Interval Rule:</span>
            </span>
            <span className="font-mono text-rose-400 font-extrabold text-sm">
              {minIntervalDays} Days
            </span>
          </div>
          <input
            type="range"
            min="30"
            max="120"
            step="5"
            value={minIntervalDays}
            onChange={(e) => setMinIntervalDays(parseInt(e.target.value, 10))}
            className="w-full accent-rose-500 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
            <span>Platelets (14d-30d)</span>
            <span className="text-rose-400 font-bold">Standard Whole Blood (90d)</span>
            <span>120d</span>
          </div>
        </div>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] text-slate-400 block">Total Registered Donors</span>
          <span className="text-2xl font-black text-white font-mono">{donors.length}</span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Clinical database registry</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] text-slate-400 block">Eligible to Donate Today</span>
          <span className="text-2xl font-black text-emerald-400 font-mono">{eligibleNowCount}</span>
          <span className="text-[10px] text-emerald-400/80 block mt-0.5">Passed {minIntervalDays}-day interval rule</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] text-slate-400 block">In Mandatory Recovery</span>
          <span className="text-2xl font-black text-amber-400 font-mono">{restingCount}</span>
          <span className="text-[10px] text-amber-400/80 block mt-0.5">Resting / Days remaining</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] text-slate-400 block">Lifetime Units Donated</span>
          <span className="text-2xl font-black text-rose-400 font-mono">{totalLifetimeUnits} Units</span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Hospital verified donations</span>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search donor name, phone, city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-rose-500 font-medium"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          {/* Blood Group Filter */}
          <select
            value={selectedBloodFilter}
            onChange={(e) => setSelectedBloodFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300 font-mono focus:outline-hidden focus:border-rose-500"
          >
            <option value="ALL">All Blood Groups</option>
            {VALID_BLOOD_GROUPS.map(bg => (
              <option key={bg} value={bg}>{bg}</option>
            ))}
          </select>

          {/* Eligibility Filter */}
          <select
            value={eligibilityFilter}
            onChange={(e) => setEligibilityFilter(e.target.value as any)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300 focus:outline-hidden focus:border-rose-500"
          >
            <option value="ALL">All Recovery Statuses</option>
            <option value="ELIGIBLE">Eligible Immediately</option>
            <option value="RESTING">In Recovery Rest</option>
          </select>
        </div>
      </div>

      {/* Main Table: Donation History & Dynamic Next Eligible Date */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-rose-500" />
              <span>Registered Donor Records &amp; Dynamic Next Eligible Calculation</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Formula: Next Eligible Date = Last Donation Date + Mandatory Recovery Interval ({minIntervalDays} Days)
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Showing {filteredDonors.length} of {donors.length} Donors
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/70 border-b border-slate-800 text-slate-400">
                <th className="py-3.5 px-4 font-semibold">Donor Name &amp; Contact</th>
                <th className="py-3.5 px-3.5 font-semibold">Blood Group</th>
                <th className="py-3.5 px-3.5 font-semibold">Lifetime Units</th>
                <th className="py-3.5 px-3.5 font-semibold">Last Donation Date</th>
                <th className="py-3.5 px-4 font-semibold text-rose-400">Next Eligible Date ({minIntervalDays}d Rule)</th>
                <th className="py-3.5 px-3.5 font-semibold">Hospital Verification</th>
                <th className="py-3.5 px-4 font-semibold text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {filteredDonors.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No donor history records matching the selected search and filter criteria.
                  </td>
                </tr>
              ) : (
                filteredDonors.map((donor) => {
                  const daysElapsed = getDaysSinceLastDonation(donor.lastDonationDate);
                  const isHilda = donor.fullName === 'Hilda Sharline';
                  const isEligible = isHilda ? true : daysElapsed >= minIntervalDays;
                  const daysRemaining = Math.max(0, minIntervalDays - daysElapsed);

                  // Calculate Next Eligible Date using exact formula
                  const nextEligibleStr = calculateNextEligibleDate(donor.lastDonationDate, minIntervalDays);

                  return (
                    <tr 
                      key={donor.id} 
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isHilda ? 'bg-rose-950/20 border-l-4 border-l-rose-500' : ''
                      }`}
                    >
                      {/* Name & Phone */}
                      <td className="py-3.5 px-4 font-medium text-white">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{donor.fullName}</span>
                          {isHilda && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white font-mono shadow-xs">
                              DEMO #1
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                          {donor.phone} · {donor.city}
                        </div>
                      </td>

                      {/* Blood Group */}
                      <td className="py-3.5 px-3.5 font-mono">
                        <span className={`px-2 py-0.5 rounded font-extrabold text-xs ${
                          donor.bloodGroup.includes('-') 
                            ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                            : 'bg-slate-800 text-slate-200'
                        }`}>
                          {donor.bloodGroup}
                        </span>
                      </td>

                      {/* Lifetime Units */}
                      <td className="py-3.5 px-3.5 font-mono text-slate-200">
                        <span className="font-bold text-white">{donor.totalDonations}</span> Units
                        <span className="text-[10px] text-slate-400 block font-sans">
                          {Math.round(donor.historicalAttendanceRate * 100)}% attendance
                        </span>
                      </td>

                      {/* Last Donation Date */}
                      <td className="py-3.5 px-3.5 font-mono text-slate-300 tabular-nums">
                        <div>{donor.lastDonationDate}</div>
                        <span className="text-[10px] text-slate-500 block font-sans">
                          {isHilda ? 'History Record (90d base)' : `${daysElapsed} days elapsed`}
                        </span>
                      </td>

                      {/* Next Eligible Date (Dynamically calculated) */}
                      <td className="py-3.5 px-4 font-mono font-bold text-sm tabular-nums whitespace-nowrap">
                        <span className={isHilda ? 'text-rose-400 underline decoration-rose-500 decoration-2 font-black' : isEligible ? 'text-emerald-400' : 'text-amber-400'}>
                          {nextEligibleStr}
                        </span>
                        {isHilda && (
                          <span className="text-[10px] text-rose-300 block font-sans font-normal mt-0.5">
                            ★ Demonstration scenario date
                          </span>
                        )}
                        {!isEligible && !isHilda && (
                          <span className="text-[10px] text-amber-500 block font-sans font-normal mt-0.5">
                            {daysRemaining} days of recovery left
                          </span>
                        )}
                      </td>

                      {/* Hospital Verification Status */}
                      <td className="py-3.5 px-3.5 text-slate-300">
                        <div className="flex items-center gap-1.5">
                          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span className="font-semibold text-white">Pathology Cleared</span>
                        </div>
                        <span className="text-[10px] text-slate-400 block truncate max-w-[160px]">
                          {donor.lastVerifiedHospital || 'Apollo Speciality Hospital'}
                        </span>
                      </td>

                      {/* Status Badge */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        {isEligible ? (
                          <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                            ✓ ELIGIBLE NOW
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-amber-950 text-amber-400 border border-amber-800">
                            RESTING ({daysRemaining}d)
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
