import React, { useState } from 'react';
import { 
  AlertCircle, 
  CheckCircle2, 
  Sparkles, 
  Building2, 
  MapPin, 
  Phone, 
  User, 
  Droplet, 
  Flame, 
  AlertTriangle, 
  Clock, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { BloodGroup, BloodComponent, UrgencyLevel, EmergencyRequest } from '../types';
import { dbService } from '../services/dbService';
import { VALID_BLOOD_GROUPS } from '../utils/excelHandler';

interface PatientRequestFormProps {
  onSubmitSuccess: (createdRequest: EmergencyRequest) => void;
  onMatchDirectly: (request: EmergencyRequest) => void;
}

export const PatientRequestForm: React.FC<PatientRequestFormProps> = ({
  onSubmitSuccess,
  onMatchDirectly,
}) => {
  // Form State
  const [patientName, setPatientName] = useState('Anita Ramesh');
  const [patientAge, setPatientAge] = useState<number>(34);
  const [patientGender, setPatientGender] = useState<'Male' | 'Female' | 'Other'>('Female');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O-');
  const [patientContactNumber, setPatientContactNumber] = useState('0431-2677777');
  const [hospitalName, setHospitalName] = useState('Srinivasan Medical College & Hospital');
  const [hospitalAddress, setHospitalAddress] = useState('NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112');
  const [unitsRequired, setUnitsRequired] = useState<number>(2);
  const [emergencyLevel, setEmergencyLevel] = useState<UrgencyLevel>('CRITICAL');
  const [componentNeeded, setComponentNeeded] = useState<BloodComponent>('Red Blood Cells (PRBC)');
  const [diagnosis, setDiagnosis] = useState('Acute post-partum hemorrhage with hypovolemic shock');

  // UI feedback
  const [formError, setFormError] = useState<string>('');
  const [successInfo, setSuccessInfo] = useState<{ id: string; refId: string } | null>(null);

  const validateForm = (): boolean => {
    if (!patientName.trim()) {
      setFormError('Patient Full Name is required.');
      return false;
    }
    if (!patientAge || patientAge < 1 || patientAge > 115) {
      setFormError('Valid Patient Age (1 - 115) is required.');
      return false;
    }
    if (!patientContactNumber.trim() || patientContactNumber.replace(/\D/g, '').length < 8) {
      setFormError('Valid Patient / Attendant Contact Number is required.');
      return false;
    }
    if (!hospitalName.trim()) {
      setFormError('Hospital Name is required.');
      return false;
    }
    if (!hospitalAddress.trim()) {
      setFormError('Hospital Address is required.');
      return false;
    }
    if (!unitsRequired || unitsRequired < 1) {
      setFormError('At least 1 blood unit must be requested.');
      return false;
    }
    return true;
  };

  const handleSaveAndSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!validateForm()) return;

    try {
      const newRequest = dbService.createRequest({
        patientName: patientName.trim(),
        patientAge,
        patientGender,
        bloodGroup,
        componentNeeded,
        unitsRequired,
        hospitalName: hospitalName.trim(),
        hospitalAddress: hospitalAddress.trim(),
        city: 'Tiruchirappalli',
        location: {
          latitude: 10.9250,
          longitude: 78.7450,
          city: 'Tiruchirappalli',
          address: hospitalAddress.trim(),
        },
        urgency: emergencyLevel,
        requiredBefore: new Date(Date.now() + 3 * 3600000).toISOString(),
        contactPerson: 'ER Trauma Physician',
        contactPhone: patientContactNumber.trim(),
        patientContactNumber: patientContactNumber.trim(),
        diagnosis: diagnosis.trim() || 'Acute emergency transfusion requisition',
        notes: `Requisition created via Dashboard 1. Emergency Level: ${emergencyLevel}`,
      });

      setSuccessInfo({ id: newRequest.id, refId: newRequest.referenceId });

      // Smooth auto-navigation to Dashboard 2
      setTimeout(() => {
        onSubmitSuccess(newRequest);
      }, 900);
    } catch (err: any) {
      setFormError(err.message || 'Failed to submit emergency blood request.');
    }
  };

  const handleMatchDonorsNow = () => {
    if (!validateForm()) return;

    try {
      const newRequest = dbService.createRequest({
        patientName: patientName.trim(),
        patientAge,
        patientGender,
        bloodGroup,
        componentNeeded,
        unitsRequired,
        hospitalName: hospitalName.trim(),
        hospitalAddress: hospitalAddress.trim(),
        city: 'Tiruchirappalli',
        location: {
          latitude: 10.9250,
          longitude: 78.7450,
          city: 'Tiruchirappalli',
          address: hospitalAddress.trim(),
        },
        urgency: emergencyLevel,
        requiredBefore: new Date(Date.now() + 3 * 3600000).toISOString(),
        contactPerson: 'ER Trauma Physician',
        contactPhone: patientContactNumber.trim(),
        patientContactNumber: patientContactNumber.trim(),
        diagnosis: diagnosis.trim() || 'Immediate AI matching requisition',
        notes: `Immediate donor matching launched from Dashboard 1.`,
      });

      onMatchDirectly(newRequest);
    } catch (err: any) {
      setFormError(err.message || 'Failed to initiate donor matching.');
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-800/80 text-rose-300 text-xs font-bold mb-2">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              <span>DASHBOARD 1 · PATIENT BLOOD REQUISITION</span>
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">
              Patient Blood Request Form
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Register an emergency blood requisition. Validates clinical parameters, saves directly to the hospital database, assigns a unique Patient Request ID, and initiates AI donor matching.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 self-start sm:self-auto">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>AABB / NBTC Triage Active</span>
          </div>
        </div>
      </div>

      {/* Success Notification Alert */}
      {successInfo && (
        <div className="p-4 rounded-xl bg-emerald-950/90 border border-emerald-600 text-emerald-200 text-sm flex items-center justify-between shadow-lg animate-in fade-in duration-300">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold text-white">Emergency Request Submitted Successfully!</p>
              <p className="text-xs text-emerald-300 font-mono">
                Assigned Request ID: <strong className="text-white underline">{successInfo.refId}</strong> · Navigating to Dashboard 2...
              </p>
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-emerald-400 animate-pulse" />
        </div>
      )}

      {/* Error Message */}
      {formError && (
        <div className="p-3.5 rounded-xl bg-rose-950/90 border border-rose-600 text-rose-200 text-xs flex items-center gap-2 shadow-lg">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{formError}</span>
        </div>
      )}

      {/* Main Request Form */}
      <form onSubmit={handleSaveAndSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        
        {/* Section 1: Patient Personal Details */}
        <div className="space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-rose-500" />
              <span>1. Patient Personal Details</span>
            </h3>
            <p className="text-[11px] text-slate-400">Clinical identity and emergency patient demographics</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 1. Patient Name */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                1. Patient Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                placeholder="e.g. Anita Ramesh"
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-hidden transition-colors"
              />
            </div>

            {/* 2. Patient Age */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                2. Patient Age (Years) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                max="115"
                required
                value={patientAge}
                onChange={(e) => setPatientAge(parseInt(e.target.value, 10) || 1)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:outline-hidden transition-colors"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 3. Gender */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                3. Gender <span className="text-rose-500">*</span>
              </label>
              <select
                value={patientGender}
                onChange={(e) => setPatientGender(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden transition-colors"
              >
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* 4. Required Blood Group */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                4. Required Blood Group <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <select
                  value={bloodGroup}
                  onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                  className="w-full bg-slate-950 border border-rose-500/80 rounded-xl px-4 py-2.5 text-sm text-rose-400 font-mono font-bold focus:outline-hidden transition-colors"
                >
                  {VALID_BLOOD_GROUPS.map(bg => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* 5. Patient Contact Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                5. Contact Number <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={patientContactNumber}
                  onChange={(e) => setPatientContactNumber(e.target.value)}
                  placeholder="+91 94440 88210"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:outline-hidden transition-colors"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Hospital & Blood Requirements */}
        <div className="space-y-4 pt-2">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Building2 className="w-4 h-4 text-sky-400" />
              <span>2. Hospital Location &amp; Blood Unit Requisition</span>
            </h3>
            <p className="text-[11px] text-slate-400">Receiving medical center and component specs</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 6. Hospital Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                6. Hospital Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={hospitalName}
                onChange={(e) => setHospitalName(e.target.value)}
                placeholder="Apollo Speciality Hospital"
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden transition-colors"
              />
            </div>

            {/* 7. Hospital Address */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                7. Hospital Address <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={hospitalAddress}
                onChange={(e) => setHospitalAddress(e.target.value)}
                placeholder="21 Greams Lane, Thousand Lights, Chennai"
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden transition-colors"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 8. Required Blood Units */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                8. Required Blood Units <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                max="10"
                required
                value={unitsRequired}
                onChange={(e) => setUnitsRequired(parseInt(e.target.value, 10) || 1)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white font-mono font-bold focus:outline-hidden transition-colors"
              />
            </div>

            {/* Component Needed */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Blood Component Needed
              </label>
              <select
                value={componentNeeded}
                onChange={(e) => setComponentNeeded(e.target.value as BloodComponent)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden transition-colors"
              >
                <option value="Red Blood Cells (PRBC)">Red Blood Cells (PRBC)</option>
                <option value="Whole Blood">Whole Blood</option>
                <option value="Platelets">Platelets</option>
                <option value="Fresh Frozen Plasma (FFP)">Fresh Frozen Plasma (FFP)</option>
              </select>
            </div>

            {/* Clinical Indication */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Clinical Diagnosis / Indication
              </label>
              <input
                type="text"
                value={diagnosis}
                onChange={(e) => setDiagnosis(e.target.value)}
                placeholder="e.g. Acute trauma hemorrhagic shock"
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-hidden transition-colors"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Emergency Level Selection (3 Large Selectable Cards) */}
        <div className="space-y-4 pt-2">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-500" />
              <span>9. Emergency Level Selection</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Select clinical urgency to determine notification priority and AI arrival time calculation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Card 1: URGENT (Yellow) */}
            <div
              onClick={() => setEmergencyLevel('URGENT')}
              className={`cursor-pointer rounded-2xl p-5 border-2 transition-all relative ${
                emergencyLevel === 'URGENT'
                  ? 'bg-amber-950/50 border-amber-400 shadow-lg shadow-amber-950/40 ring-2 ring-amber-400/30'
                  : 'bg-slate-950/70 border-slate-800 hover:border-amber-600/60'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <Clock className="w-5 h-5" />
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase font-mono ${
                  emergencyLevel === 'URGENT' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}>
                  {emergencyLevel === 'URGENT' ? 'SELECTED' : 'YELLOW'}
                </span>
              </div>
              <h4 className="text-base font-extrabold text-amber-400 tracking-tight">URGENT</h4>
              <p className="text-xs text-slate-300 mt-1">Required within 2 - 4 hours</p>
              <p className="text-[11px] text-slate-500 mt-2">Planned surgery stabilization or moderate clinical hemoglobin deficit.</p>
            </div>

            {/* Card 2: CRITICAL (Orange) */}
            <div
              onClick={() => setEmergencyLevel('CRITICAL')}
              className={`cursor-pointer rounded-2xl p-5 border-2 transition-all relative ${
                emergencyLevel === 'CRITICAL'
                  ? 'bg-orange-950/50 border-orange-500 shadow-lg shadow-orange-950/40 ring-2 ring-orange-500/30'
                  : 'bg-slate-950/70 border-slate-800 hover:border-orange-600/60'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="p-2.5 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30">
                  <AlertTriangle className="w-5 h-5" />
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase font-mono ${
                  emergencyLevel === 'CRITICAL' ? 'bg-orange-500 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {emergencyLevel === 'CRITICAL' ? 'SELECTED' : 'ORANGE'}
                </span>
              </div>
              <h4 className="text-base font-extrabold text-orange-400 tracking-tight">CRITICAL</h4>
              <p className="text-xs text-slate-300 mt-1">Required within 30 - 60 minutes</p>
              <p className="text-[11px] text-slate-500 mt-2">Acute trauma, intensive care unit resuscitation, or profound blood loss.</p>
            </div>

            {/* Card 3: DANGER (Red) */}
            <div
              onClick={() => setEmergencyLevel('DANGER')}
              className={`cursor-pointer rounded-2xl p-5 border-2 transition-all relative ${
                emergencyLevel === 'DANGER'
                  ? 'bg-rose-950/60 border-rose-500 shadow-xl shadow-rose-950/50 ring-2 ring-rose-500/40 animate-pulse'
                  : 'bg-slate-950/70 border-slate-800 hover:border-rose-600/60'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="p-2.5 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30">
                  <Flame className="w-5 h-5" />
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase font-mono ${
                  emergencyLevel === 'DANGER' ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {emergencyLevel === 'DANGER' ? 'SELECTED' : 'RED'}
                </span>
              </div>
              <h4 className="text-base font-extrabold text-rose-500 tracking-tight">DANGER</h4>
              <p className="text-xs text-slate-200 mt-1">IMMEDIATE STAT EMERGENCY</p>
              <p className="text-[11px] text-slate-400 mt-2">Active massive hemorrhage, code red, emergency siren cascade triggered.</p>
            </div>
          </div>
        </div>

        {/* Buttons at Bottom (Displayed prominently in red) */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-end gap-4">
          {/* Button 1: Submit Blood Request */}
          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl text-sm font-extrabold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 shadow-lg shadow-rose-900/40 hover:shadow-rose-900/60 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Submit Blood Request</span>
          </button>

          {/* Button 2: Match Donors */}
          <button
            type="button"
            onClick={handleMatchDonorsNow}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl text-sm font-extrabold text-white bg-red-700 hover:bg-red-600 active:bg-red-800 border border-red-500/50 shadow-lg shadow-red-950/50 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-white" />
            <span>Match Donors</span>
          </button>
        </div>
      </form>
    </div>
  );
};
