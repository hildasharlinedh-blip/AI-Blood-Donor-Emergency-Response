import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Building2, 
  Navigation, 
  ShieldCheck, 
  Filter, 
  User, 
  Phone, 
  CheckCircle2,
  Droplet
} from 'lucide-react';
import { Donor, EmergencyRequest, BloodGroup } from '../types';
import { dbService } from '../services/dbService';
import { calculateHaversineDistance } from '../utils/bloodCompatibility';
import { VALID_BLOOD_GROUPS } from '../utils/excelHandler';

export const MapView: React.FC = () => {
  const [donors, setDonors] = useState<Donor[]>([]);
  const [requests, setRequests] = useState<EmergencyRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<EmergencyRequest | null>(null);
  const [selectedBloodFilter, setSelectedBloodFilter] = useState<string>('ALL');
  const [activeDonorCard, setActiveDonorCard] = useState<{ donor: Donor; distanceKm: number } | null>(null);

  useEffect(() => {
    const dList = dbService.getDonors();
    const rList = dbService.getRequests();
    setDonors(dList);
    setRequests(rList);
    if (rList.length > 0) {
      setSelectedRequest(rList[0]);
    }
  }, []);

  const hospitalCenter = selectedRequest?.location || { latitude: 13.0569, longitude: 80.2520, city: 'Chennai' };

  // Filter donors by blood group if specified
  const filteredDonors = donors.filter(d => {
    if (selectedBloodFilter === 'ALL') return true;
    return d.bloodGroup === selectedBloodFilter;
  });

  // Project lat/lng to SVG coordinate box (center at 400, 300)
  // 1 degree ~ 111 km. At 50km radius scale, 0.1 degree ~ 25 pixels
  const centerLat = hospitalCenter.latitude;
  const centerLng = hospitalCenter.longitude;
  const scale = 1400; // pixels per degree

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <MapPin className="w-5 h-5 text-rose-500" />
            <span>Regional GIS Geospatial &amp; Proximity Map</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Haversine distance mapping between active hospital emergency departments and verified donor addresses.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedRequest?.id || ''}
            onChange={(e) => {
              const req = requests.find(r => r.id === e.target.value);
              if (req) setSelectedRequest(req);
            }}
            className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-hidden focus:border-rose-500"
          >
            {requests.map(r => (
              <option key={r.id} value={r.id}>
                Hospital: {r.hospitalName} ({r.city})
              </option>
            ))}
          </select>

          <select
            value={selectedBloodFilter}
            onChange={(e) => setSelectedBloodFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300 font-mono focus:outline-hidden focus:border-rose-500"
          >
            <option value="ALL">All Blood Groups</option>
            {VALID_BLOOD_GROUPS.map(bg => (
              <option key={bg} value={bg}>{bg}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Map Box & Legend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* SVG Interactive Map Area (8 cols) */}
        <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[460px]">
          {/* Subtle Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:32px_32px] opacity-25 pointer-events-none" />

          {/* Map Overlay Badge */}
          <div className="relative z-10 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
              <span className="font-semibold text-white">{selectedRequest?.hospitalName}</span>
              <span>({hospitalCenter.city})</span>
            </div>
            <span className="font-mono text-[11px] text-slate-400">
              Center: {centerLat.toFixed(4)}°N, {centerLng.toFixed(4)}°E
            </span>
          </div>

          {/* Interactive SVG Projection */}
          <div className="relative w-full h-[360px] my-auto">
            <svg viewBox="0 0 800 450" className="w-full h-full">
              {/* Concentric Haversine Range Rings */}
              {/* 10 km ring (~50px radius) */}
              <circle cx="400" cy="225" r="70" fill="none" stroke="#334155" strokeDasharray="3 3" />
              <text x="475" y="222" fill="#64748B" fontSize="10" fontFamily="monospace">10 km</text>

              {/* 25 km ring (~130px radius) */}
              <circle cx="400" cy="225" r="150" fill="none" stroke="#334155" strokeDasharray="4 4" />
              <text x="555" y="222" fill="#64748B" fontSize="10" fontFamily="monospace">25 km</text>

              {/* 50 km ring (~260px radius) */}
              <circle cx="400" cy="225" r="260" fill="none" stroke="#1E293B" />
              <text x="665" y="222" fill="#475569" fontSize="10" fontFamily="monospace">50 km max operational radius</text>

              {/* Donor Markers */}
              {filteredDonors.map((donor) => {
                const distanceKm = calculateHaversineDistance(hospitalCenter, donor.location);
                // Relative projection from center
                const dLng = donor.location.longitude - centerLng;
                const dLat = donor.location.latitude - centerLat;

                const x = 400 + dLng * scale;
                // Invert y since svg y grows downwards
                const y = 225 - dLat * scale;

                // Clamp within bounds for smooth visual
                const clampedX = Math.max(30, Math.min(770, x));
                const clampedY = Math.max(30, Math.min(420, y));

                const isO_Neg = donor.bloodGroup === 'O-';
                const isSelected = activeDonorCard?.donor.id === donor.id;

                return (
                  <g
                    key={donor.id}
                    className="cursor-pointer transition-transform hover:scale-125"
                    onClick={() => setActiveDonorCard({ donor, distanceKm })}
                  >
                    {/* Pulsing ring if selected */}
                    {isSelected && (
                      <circle cx={clampedX} cy={clampedY} r="18" fill="none" stroke="#E11D48" strokeWidth="2" opacity="0.8" />
                    )}

                    <circle
                      cx={clampedX}
                      cy={clampedY}
                      r="9"
                      fill={isO_Neg ? '#E11D48' : donor.isAvailable ? '#0284C7' : '#64748B'}
                      stroke="#FFFFFF"
                      strokeWidth="1.5"
                    />

                    {/* Blood Group text in circle */}
                    <text
                      x={clampedX}
                      y={clampedY + 3}
                      textAnchor="middle"
                      fill="#FFFFFF"
                      fontSize="7"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      {donor.bloodGroup}
                    </text>
                  </g>
                );
              })}

              {/* Hospital Center Marker */}
              <g className="cursor-pointer">
                <circle cx="400" cy="225" r="14" fill="#DC2626" stroke="#FFFFFF" strokeWidth="2.5" />
                <path
                  d="M 400 219 L 400 231 M 394 225 L 406 225"
                  stroke="#FFFFFF"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />
              </g>
            </svg>
          </div>

          {/* Map Footer Bar */}
          <div className="relative z-10 flex flex-wrap items-center justify-between text-[11px] text-slate-400 border-t border-slate-900 pt-2">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-600 inline-block border border-white"></span>
                <span>Hospital Hub</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-sky-600 inline-block"></span>
                <span>Registered Donors</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-700 inline-block"></span>
                <span>Universal Safe (O-)</span>
              </span>
            </div>

            <span>Click any pin to inspect donor suitability &amp; ETA</span>
          </div>
        </div>

        {/* Selected Donor Inspector Card & Legend (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {activeDonorCard ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h4 className="text-sm font-bold text-white">{activeDonorCard.donor.fullName}</h4>
                  <p className="text-xs text-slate-400 font-mono">{activeDonorCard.donor.id}</p>
                </div>
                <span className="text-sm font-extrabold text-rose-400 font-mono px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
                  {activeDonorCard.donor.bloodGroup}
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>Haversine Distance:</span>
                  <strong className="text-white font-mono">{activeDonorCard.distanceKm} km</strong>
                </div>

                <div className="flex justify-between text-slate-300">
                  <span>Estimated Arrival:</span>
                  <strong className="text-emerald-400 font-mono">
                    ~{Math.max(10, Math.round(activeDonorCard.distanceKm / 0.45))} mins
                  </strong>
                </div>

                <div className="flex justify-between text-slate-300">
                  <span>Availability:</span>
                  <strong className={activeDonorCard.donor.isAvailable ? 'text-emerald-400' : 'text-slate-400'}>
                    {activeDonorCard.donor.isAvailable ? 'Available Now' : 'Currently Resting'}
                  </strong>
                </div>

                <div className="flex justify-between text-slate-300">
                  <span>City &amp; Address:</span>
                  <span className="text-slate-200 text-right truncate max-w-[170px]">
                    {activeDonorCard.donor.address}, {activeDonorCard.donor.city}
                  </span>
                </div>

                <div className="flex justify-between text-slate-300">
                  <span>Contact Phone:</span>
                  <span className="font-mono text-sky-400">{activeDonorCard.donor.phone}</span>
                </div>

                <div className="flex justify-between text-slate-300">
                  <span>Attendance Rate:</span>
                  <span className="font-mono text-white">
                    {Math.round(activeDonorCard.donor.historicalAttendanceRate * 100)}%
                  </span>
                </div>
              </div>

              <div className="p-2.5 rounded bg-slate-950 border border-slate-800 text-[11px] text-slate-400">
                Registered via {activeDonorCard.donor.createdSource === 'excel_upload' ? 'Excel Import' : 'Clinical Database'} with emergency contact consent.
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
              <Navigation className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <h4 className="text-xs font-bold text-white mb-1">Geospatial Inspector</h4>
              <p className="text-[11px] text-slate-400">
                Select any donor marker on the radar map to inspect distance, travel ETA, and clinical compatibility.
              </p>
            </div>
          )}

          {/* Quick Proximity Stats */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
            <h5 className="font-bold text-white mb-2">Hospital Operational Perimeter</h5>
            <div className="flex justify-between text-slate-300">
              <span>Within 10 km:</span>
              <strong className="text-white font-mono">
                {donors.filter(d => calculateHaversineDistance(hospitalCenter, d.location) <= 10).length} Donors
              </strong>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Within 25 km:</span>
              <strong className="text-white font-mono">
                {donors.filter(d => calculateHaversineDistance(hospitalCenter, d.location) <= 25).length} Donors
              </strong>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Within 50 km (Operational):</span>
              <strong className="text-emerald-400 font-mono">
                {donors.filter(d => calculateHaversineDistance(hospitalCenter, d.location) <= 50).length} Donors
              </strong>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
