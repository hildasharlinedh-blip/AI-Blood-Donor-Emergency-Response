import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  AlertTriangle, 
  Sparkles, 
  Droplet, 
  Database, 
  Building2, 
  CheckCircle2, 
  Info,
  Layers,
  ThermometerSnowflake,
  FileCheck
} from 'lucide-react';
import { RarePhenotype } from '../types';

interface RarePhenotypeInfo {
  phenotype: RarePhenotype;
  isbtNumber: string;
  systemName: string;
  populationFrequency: string;
  clinicalSignificance: string;
  antibodyRisk: string;
  transfusionProtocol: string;
  registeredRareDonorsCount: number;
}

export const RARE_PHENOTYPES_DATA: RarePhenotypeInfo[] = [
  {
    phenotype: 'PP1Pk-neg',
    isbtNumber: 'ISBT 003 / 028',
    systemName: 'P1PK & GLOB Blood Group System (p phenotype)',
    populationFrequency: '< 1 in 1,000,000 (< 0.0001%)',
    clinicalSignificance: 'Severe acute & delayed hemolytic transfusion reactions (HTR) and recurrent habitual spontaneous abortions.',
    antibodyRisk: 'Naturally occurring potent anti-PP1Pk (anti-Tja) hemolysins; IgM + IgG causing immediate complement lysis.',
    transfusionProtocol: 'Requires strictly p-phenotype cryopreserved red blood cells. Incompatible with all ABO standard O- blood.',
    registeredRareDonorsCount: 2,
  },
  {
    phenotype: 'I-neg',
    isbtNumber: 'ISBT 027',
    systemName: 'I Blood Group System (Adult i phenotype)',
    populationFrequency: '< 1 in 100,000 (0.001%)',
    clinicalSignificance: 'Severe cold agglutinin disease (CAD) exacerbation and thermal amplitude hemolysis during hypothermic cardiopulmonary bypass.',
    antibodyRisk: 'Potent cold auto/allo-anti-I reacting at 4°C to 37°C.',
    transfusionProtocol: 'Blood warmer mandatory at 37°C; provide adult i-negative or pre-warmed washed red blood cells.',
    registeredRareDonorsCount: 3,
  },
  {
    phenotype: 'In(a+b−)',
    isbtNumber: 'ISBT 023',
    systemName: 'Indian Blood Group System (CD44 glycoprotein)',
    populationFrequency: '0.01% in Indian Subcontinent; < 0.0001% Caucasian',
    clinicalSignificance: 'Alloimmunization following pregnancy or prior transfusion causing moderate to severe HTR.',
    antibodyRisk: 'Allo-anti-Inb (IN2) reactive at 37°C in indirect antiglobulin test (IAT).',
    transfusionProtocol: 'Screen rare donor registry in Western & Southern India; supply In(b−) units for pediatric thalassemia.',
    registeredRareDonorsCount: 5,
  },
  {
    phenotype: 'Di(b−)',
    isbtNumber: 'ISBT 010',
    systemName: 'Diego Blood Group System (Band 3 / AE1 anion exchanger)',
    populationFrequency: '< 0.01% overall; rare variant in East Asian / Indigenous populations',
    clinicalSignificance: 'Severe hemolytic disease of the fetus and newborn (HDFN) and acute extravascular transfusion reactions.',
    antibodyRisk: 'Allo-anti-Dib; warm-reacting IgG1 and IgG3 capable of placental transfer.',
    transfusionProtocol: 'Immediate molecular genotyping of maternal and donor blood; autologous or Dib-negative frozen units.',
    registeredRareDonorsCount: 4,
  },
  {
    phenotype: 'Ge-neg',
    isbtNumber: 'ISBT 020',
    systemName: 'Gerbich Blood Group System (Glycophorin C & D)',
    populationFrequency: '< 0.01% (Ge:-2,-3 Yus type or Leach phenotype)',
    clinicalSignificance: 'Elliptocytosis membrane fragility and acute delayed hemolytic transfusion reactions.',
    antibodyRisk: 'Anti-Ge2, Anti-Ge3 warm antibodies; may cause severe neonatal hyperbilirubinemia.',
    transfusionProtocol: 'Supply Gerbich-negative units from National Rare Donor Registry.',
    registeredRareDonorsCount: 3,
  },
  {
    phenotype: 'Yt(a−)',
    isbtNumber: 'ISBT 011',
    systemName: 'Cartwright Blood Group System (GPI-linked Acetylcholinesterase)',
    populationFrequency: '~0.02% (1 in 5,000 in European / Israeli populations)',
    clinicalSignificance: 'Delayed hemolytic transfusion reactions and shortened red cell survival time in vivo.',
    antibodyRisk: 'Allo-anti-Yta IgG antibody active by standard IAT; rarely fixes complement.',
    transfusionProtocol: 'Yt(a−) cross-matched units required for patients with documented declining hematocrit post-transfusion.',
    registeredRareDonorsCount: 6,
  },
  {
    phenotype: 'Do(a−)',
    isbtNumber: 'ISBT 014',
    systemName: 'Dombrock Blood Group System (Mono-ADP-ribosyltransferase ART4)',
    populationFrequency: '~34% Caucasian, but critical when combined with multi-antibody panels',
    clinicalSignificance: 'Frequently implicated in severe delayed hemolytic transfusion reactions masked by other alloantibodies.',
    antibodyRisk: 'Allo-anti-Doa; notoriously elusive warm IgG antibody that fades rapidly in vitro.',
    transfusionProtocol: 'Enzyme-treated red cell panels (Papain/Ficin) for detection; Do(a−) antigen-negative donor selection.',
    registeredRareDonorsCount: 18,
  },
  {
    phenotype: 'Hy-neg',
    isbtNumber: 'ISBT 014',
    systemName: 'Holley-negative variant (Dombrock Blood Group System)',
    populationFrequency: '< 0.01% in general population; predominantly African ancestry variant',
    clinicalSignificance: 'Severe post-transfusion hemolytic crisis in sickle cell disease (SCD) patients with Hy alloimmunization.',
    antibodyRisk: 'Anti-Hy; reacts with all standard RBCs except Hy-negative and Gy(a−) cells.',
    transfusionProtocol: 'Requires rare donor alert to National Rare Blood Donor Program; cryopreserved liquid nitrogen storage.',
    registeredRareDonorsCount: 2,
  },
  {
    phenotype: 'Jo(a−)',
    isbtNumber: 'ISBT 014',
    systemName: 'Joseph-negative variant (Dombrock Blood Group System)',
    populationFrequency: '< 0.01% worldwide',
    clinicalSignificance: 'Severe delayed hemolytic transfusion reactions and refractory transfusion response.',
    antibodyRisk: 'Anti-Joa; high-incidence antigen antibody reactive by antiglobulin technique.',
    transfusionProtocol: 'Siblings and extended family screening recommended for donor recruitment.',
    registeredRareDonorsCount: 2,
  },
  {
    phenotype: 'Kp(b−)',
    isbtNumber: 'ISBT 006',
    systemName: 'Kell Blood Group System (KEL4 Rautenberg negative)',
    populationFrequency: '< 0.02% (1 in 5,000 individuals)',
    clinicalSignificance: 'Severe fatal hemolytic disease of the fetus and newborn (HDFN) and acute hemolytic reactions.',
    antibodyRisk: 'Anti-Kpb (anti-KEL4); warm IgG immune antibody causing profound erythroid progenitor suppression.',
    transfusionProtocol: 'Kp(b−) or Kp(a+b−) units required. Strictly incompatible with 99.9% of normal donors.',
    registeredRareDonorsCount: 4,
  },
  {
    phenotype: 'Js(b−)',
    isbtNumber: 'ISBT 006',
    systemName: 'Kell Blood Group System (KEL7 Matthews negative)',
    populationFrequency: '< 0.01% in Caucasian; ~1% in African populations',
    clinicalSignificance: 'Severe HDFN and acute hemolytic transfusion reactions in poly-transfused hemoglobinopathy cases.',
    antibodyRisk: 'Anti-Jsb (anti-KEL7); potent immune warm antibody refractory to standard crossmatch.',
    transfusionProtocol: 'Maintain dedicated liquid nitrogen inventory of Js(b−) PRBC units.',
    registeredRareDonorsCount: 5,
  },
  {
    phenotype: 'LW(a−)',
    isbtNumber: 'ISBT 016',
    systemName: 'Landsteiner-Wiener Blood Group System (ICAM-4 glycoprotein)',
    populationFrequency: '< 0.01% (LW1 negative)',
    clinicalSignificance: 'Diagnostic confusion with Rh(D) negative phenotypes; transient suppression during pregnancy and lymphoma.',
    antibodyRisk: 'Allo-anti-LWa; reacts strongly with Rh-positive and weakly with Rh-negative red cells.',
    transfusionProtocol: 'Requires specialized reference laboratory adsorption and elution tests; LW(a−) or Rh-null donor allocation.',
    registeredRareDonorsCount: 3,
  },
];

export const RarePhenotypeRegistry: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPhenotype, setSelectedPhenotype] = useState<RarePhenotypeInfo | null>(RARE_PHENOTYPES_DATA[0]);

  const filtered = RARE_PHENOTYPES_DATA.filter(p => {
    const q = searchQuery.toLowerCase().trim();
    return (
      !q ||
      p.phenotype.toLowerCase().includes(q) ||
      p.systemName.toLowerCase().includes(q) ||
      p.isbtNumber.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 pb-12 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-800/80 text-rose-300 text-xs font-bold mb-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>AABB / ISBT EXTENDED ANTIGEN REGISTRY</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Layers className="w-6 h-6 text-rose-500" />
            <span>Rare Blood Groups &amp; Extended Antigen Phenotypes</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Separate clinical registry for the 12 rare red cell antigen phenotypes (ISBT 001-030). Handled strictly independently from standard ABO/Rh(D) grouping to prevent acute hemolytic transfusion reactions in poly-transfused patients.
          </p>
        </div>

        <div className="bg-slate-950 px-4 py-2.5 rounded-xl border border-slate-800 text-xs font-mono text-slate-300 flex items-center gap-2 self-start md:self-auto">
          <ThermometerSnowflake className="w-4 h-4 text-sky-400" />
          <span>Cryopreserved Inventory (-196°C)</span>
        </div>
      </div>

      {/* Clinical Segregation Notice Card */}
      <div className="p-4 rounded-xl bg-slate-900 border border-rose-900/60 text-xs text-slate-300 flex items-start gap-3 shadow-md">
        <Info className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-white block mb-0.5">Clinical Separation from ABO/Rh:</strong>
          <span>
            Standard cross-matching (e.g. O- to O-) will FAIL catastrophically if an alloimmunized patient possesses rare antibodies such as Anti-PP1Pk or Anti-Kpb. In this platform, rare blood phenotypes are classified as independent immunogenetic entities with mandatory specialized antigen-negative donor retrieval.
          </span>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search rare phenotype (e.g., PP1Pk, In(a+b-), Kp(b-))..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-rose-500 font-medium"
          />
        </div>
        <span className="text-xs font-mono text-slate-400">
          Showing {filtered.length} of {RARE_PHENOTYPES_DATA.length} Extended Phenotypes
        </span>
      </div>

      {/* Two Column Layout: Phenotype List & Detailed Pathological Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: 12 Rare Phenotype Cards (5 cols) */}
        <div className="lg:col-span-5 space-y-2.5 max-h-[640px] overflow-y-auto pr-1">
          {filtered.map((item) => {
            const isSelected = selectedPhenotype?.phenotype === item.phenotype;
            return (
              <div
                key={item.phenotype}
                onClick={() => setSelectedPhenotype(item)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-rose-950/50 border-rose-500 shadow-md ring-1 ring-rose-500/40'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono font-black text-sm text-rose-400">
                    {item.phenotype}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                    {item.isbtNumber}
                  </span>
                </div>
                <div className="text-xs text-white font-medium truncate">{item.systemName}</div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-2 border-t border-slate-800/60 font-mono">
                  <span>Freq: {item.populationFrequency.split(';')[0]}</span>
                  <span className="text-emerald-400 font-bold">{item.registeredRareDonorsCount} Donors</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Detailed Clinical Protocol & Dossier (7 cols) */}
        {selectedPhenotype && (
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-rose-400 uppercase font-mono tracking-widest block">
                  ISBT CLINICAL DOSSIER
                </span>
                <h3 className="text-2xl font-black text-white font-mono mt-0.5">
                  {selectedPhenotype.phenotype}
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">{selectedPhenotype.systemName}</p>
              </div>

              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-slate-950 text-rose-300 border border-rose-800">
                {selectedPhenotype.isbtNumber}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">POPULATION FREQUENCY</span>
                <span className="text-white font-mono font-bold text-xs mt-1 block">
                  {selectedPhenotype.populationFrequency}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">REGISTERED RARE DONORS</span>
                <span className="text-emerald-400 font-mono font-bold text-base mt-1 block">
                  {selectedPhenotype.registeredRareDonorsCount} Verified Donors
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-rose-400 font-bold uppercase tracking-wider block mb-1">
                  CLINICAL SIGNIFICANCE &amp; HTR PATHOLOGY
                </span>
                <p className="text-slate-200 leading-relaxed">
                  {selectedPhenotype.clinicalSignificance}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block mb-1">
                  ANTIBODY RISK &amp; IMMUNOLOGICAL BEHAVIOR
                </span>
                <p className="text-slate-200 leading-relaxed">
                  {selectedPhenotype.antibodyRisk}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-sky-400 font-bold uppercase tracking-wider block mb-1">
                  MANDATORY TRANSFUSION MANAGEMENT PROTOCOL
                </span>
                <p className="text-slate-200 leading-relaxed">
                  {selectedPhenotype.transfusionProtocol}
                </p>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800">
              <span className="flex items-center gap-1.5 font-mono text-[11px]">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                <span>Reference: AABB Technical Manual 20th Ed. &amp; ISBT Standards</span>
              </span>
              <span className="text-rose-400 font-mono font-bold">
                Level 1 Cryopreservation
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
