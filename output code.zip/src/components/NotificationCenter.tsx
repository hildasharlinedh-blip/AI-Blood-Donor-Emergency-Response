import React, { useState, useEffect } from 'react';
import { 
  Send, 
  Mail, 
  Smartphone, 
  RotateCcw, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Eye, 
  ShieldCheck,
  Check,
  X
} from 'lucide-react';
import { NotificationLog } from '../types';
import { dbService } from '../services/dbService';
import { notificationService } from '../services/notificationService';

export const NotificationCenter: React.FC = () => {
  const [notifications, setNotifications] = useState<NotificationLog[]>([]);
  const [selectedNotif, setSelectedNotif] = useState<NotificationLog | null>(null);
  const [previewMode, setPreviewMode] = useState<'SMS' | 'EMAIL'>('SMS');
  const [retrySuccess, setRetrySuccess] = useState<string>('');

  const loadNotifications = () => {
    setNotifications(dbService.getNotifications());
  };

  useEffect(() => {
    loadNotifications();
    const unsubscribe = dbService.subscribe(loadNotifications);
    return () => unsubscribe();
  }, []);

  const handleRetry = (id: string) => {
    const success = notificationService.retryNotification(id);
    if (success) {
      setRetrySuccess(`Notification ${id} successfully re-queued and delivered.`);
      setTimeout(() => setRetrySuccess(''), 4000);
      loadNotifications();
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Send className="w-5 h-5 text-sky-400" />
            <span>Emergency Notification Center &amp; Message Dispatch Logs</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Twilio / MSG91 compliant SMS delivery logs, responsive Gmail template engine, and automated retries.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">
            Total Dispatches: <strong className="text-white">{notifications.length}</strong>
          </span>
        </div>
      </div>

      {retrySuccess && (
        <div className="p-3 rounded-lg bg-emerald-950/80 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{retrySuccess}</span>
        </div>
      )}

      {/* Notifications Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-slate-400">
                <th className="py-3 px-3.5 font-semibold">Log ID</th>
                <th className="py-3 px-3.5 font-semibold">Recipient</th>
                <th className="py-3 px-3.5 font-semibold">Request Case</th>
                <th className="py-3 px-3.5 font-semibold">Channel</th>
                <th className="py-3 px-3.5 font-semibold">Provider Engine</th>
                <th className="py-3 px-3.5 font-semibold">Sent Timestamp</th>
                <th className="py-3 px-3.5 font-semibold text-center">Delivery Status</th>
                <th className="py-3 px-3.5 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {notifications.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    No dispatch history recorded yet.
                  </td>
                </tr>
              ) : (
                notifications.map((notif, index) => (
                  <tr key={`${notif.id}-${index}`} className="hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 px-3.5 font-mono text-slate-400 font-medium">
                      {notif.id}
                    </td>
                    <td className="py-3 px-3.5 text-white font-medium">
                      <div>{notif.donorName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{notif.donorPhone}</div>
                    </td>
                    <td className="py-3 px-3.5 font-mono text-rose-400">
                      {notif.requestId}
                    </td>
                    <td className="py-3 px-3.5 text-slate-300 font-semibold">
                      {notif.channel}
                    </td>
                    <td className="py-3 px-3.5 font-mono text-[11px] text-slate-400">
                      {notif.provider}
                    </td>
                    <td className="py-3 px-3.5 text-slate-400 font-mono tabular-nums">
                      {new Date(notif.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </td>
                    <td className="py-3 px-3.5 text-center">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                        notif.status === 'DELIVERED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : notif.status === 'SENT'
                          ? 'bg-sky-950 text-sky-400 border border-sky-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}>
                        {notif.status === 'DELIVERED' && <Check className="w-3 h-3" />}
                        <span>{notif.status}</span>
                      </span>
                    </td>
                    <td className="py-3 px-3.5 text-right whitespace-nowrap">
                      <button
                        onClick={() => { setSelectedNotif(notif); setPreviewMode('SMS'); }}
                        className="px-2.5 py-1 text-xs text-sky-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors mr-1"
                      >
                        Preview
                      </button>
                      <button
                        onClick={() => handleRetry(notif.id)}
                        title="Retry delivery"
                        className="p-1 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Message Preview Modal */}
      {selectedNotif && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <h3 className="text-base font-bold text-white">Emergency Message Dispatch Inspector</h3>
                <p className="text-xs text-slate-400">
                  Recipient: {selectedNotif.donorName} ({selectedNotif.donorPhone}) · Case: {selectedNotif.requestId}
                </p>
              </div>

              {/* Mode Toggle: SMS vs Gmail */}
              <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg">
                <button
                  onClick={() => setPreviewMode('SMS')}
                  className={`flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded ${
                    previewMode === 'SMS' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3 h-3" />
                  <span>SMS Payload</span>
                </button>
                <button
                  onClick={() => setPreviewMode('EMAIL')}
                  className={`flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded ${
                    previewMode === 'EMAIL' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Mail className="w-3 h-3" />
                  <span>Gmail HTML</span>
                </button>
              </div>
            </div>

            {previewMode === 'SMS' ? (
              <div className="space-y-3">
                <div className="text-xs text-slate-400">
                  Twilio / MSG91 GSM-7 Text Message format:
                </div>
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 whitespace-pre-line leading-relaxed">
                  {selectedNotif.smsContent}
                </div>
                <div className="p-3 rounded bg-slate-950 border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Sender ID: <strong className="text-white">BLDREC (Twilio)</strong></span>
                  <span className="text-emerald-400 font-mono">Status: Delivered (Carrier ACK 200 OK)</span>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="text-xs text-slate-400">
                  Subject: <strong className="text-white">{selectedNotif.emailSubject}</strong>
                </div>
                {/* Embedded HTML iframe or container */}
                <div 
                  className="bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-x-auto text-xs"
                  dangerouslySetInnerHTML={{ __html: selectedNotif.emailHtml }}
                />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-800 mt-4">
              <button
                onClick={() => setSelectedNotif(null)}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 rounded-lg"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
