import { 
  Donor, 
  EmergencyRequest, 
  NotificationLog, 
  DonorResponse, 
  AuditLog, 
  SystemConfig,
  BloodGroup
} from '../types';

const STORAGE_KEYS = {
  DONORS: 'remix_blood_donors_v3',
  REQUESTS: 'remix_blood_requests_v3',
  NOTIFICATIONS: 'remix_blood_notifications_v3',
  RESPONSES: 'remix_blood_responses_v3',
  AUDIT: 'remix_blood_audit_v3',
  CONFIG: 'remix_blood_config_v3',
  COMPLETED_DONATIONS: 'remix_blood_completed_donations_v3',
};

// Initial realistic donors dataset (Healthcare verified formats)
export const INITIAL_DONORS: Donor[] = [
  {
    id: 'DNR-1000',
    fullName: 'Hilda Sharline',
    phone: '8778434228',
    email: 'hilda.sharline.dh@gmail.com',
    bloodGroup: 'O-',
    age: 24,
    gender: 'Female',
    weightKg: 58,
    hemoglobinGdl: 14.2,
    city: 'Tiruchirappalli',
    address: 'Near KRCT Campus, Samayapuram',
    location: { latitude: 10.9328, longitude: 78.7380, city: 'Tiruchirappalli', address: 'Near KRCT Campus, Samayapuram' },
    lastDonationDate: new Date(Date.now() - 170 * 86400000).toISOString().split('T')[0], // Donated 170 days ago (Mandatory 90-day whole blood interval completed)
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 6,
    historicalAttendanceRate: 0.98,
    historicalResponseRate: 0.99,
    createdSource: 'seeded',
    createdAt: '2025-01-01T08:00:00Z',
    hospitalVerificationStatus: 'VERIFIED',
    lastVerifiedHospital: 'Srinivasan Medical College & Hospital, Samayapuram',
  },
  {
    id: 'DNR-1001',
    fullName: 'K. Rajesh Kumar',
    phone: '+91 94431 87654',
    email: 'rajesh.kumar@gmail.com',
    bloodGroup: 'O-',
    age: 28,
    gender: 'Male',
    weightKg: 72,
    hemoglobinGdl: 14.8,
    city: 'Tiruchirappalli',
    address: 'Samayapuram Main Road, Tollgate',
    location: { latitude: 10.9280, longitude: 78.7420, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 40 * 86400000).toISOString().split('T')[0], // Donated 40 days ago (INELIGIBLE: 50 days left in 90-day cooldown)
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 5,
    historicalAttendanceRate: 0.92,
    historicalResponseRate: 0.94,
    createdSource: 'seeded',
    createdAt: '2025-01-10T09:00:00Z',
    hospitalVerificationStatus: 'VERIFIED',
    lastVerifiedHospital: 'Srinivasan Medical College & Hospital',
  },
  {
    id: 'DNR-1002',
    fullName: 'Dr. Vignesh Sundaram',
    phone: '+91 98401 23456',
    email: 'vignesh.sundaram@gmail.com',
    bloodGroup: 'O-',
    age: 32,
    gender: 'Male',
    weightKg: 75,
    hemoglobinGdl: 15.2,
    city: 'Chennai',
    address: '14, Cathedral Road, Gopalapuram',
    location: { latitude: 13.0489, longitude: 80.2541, city: 'Chennai' }, // DISTANCE: ~312 km away (INELIGIBLE: Exceeds 50km radius)
    lastDonationDate: new Date(Date.now() - 140 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 8,
    historicalAttendanceRate: 0.95,
    historicalResponseRate: 0.98,
    createdSource: 'seeded',
    createdAt: '2025-01-12T10:15:00Z',
    hospitalVerificationStatus: 'VERIFIED',
    lastVerifiedHospital: 'Rajiv Gandhi Govt General Hospital',
  },
  {
    id: 'DNR-1003',
    fullName: 'P. Suresh Balaji',
    phone: '+91 98842 55662',
    email: 'suresh.balaji@gmail.com',
    bloodGroup: 'O-',
    age: 29,
    gender: 'Male',
    weightKg: 68,
    hemoglobinGdl: 14.5,
    city: 'Tiruchirappalli',
    address: 'Near Old Bus Stand, Thillai Nagar',
    location: { latitude: 10.8280, longitude: 78.6870, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 40 * 86400000).toISOString().split('T')[0], // Donated 40 days ago (INELIGIBLE: 50 days of mandatory recovery left)
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 4,
    historicalAttendanceRate: 0.90,
    historicalResponseRate: 0.92,
    createdSource: 'seeded',
    createdAt: '2025-01-15T11:00:00Z',
  },
  {
    id: 'DNR-1004',
    fullName: 'Sneha Venkatesh',
    phone: '+91 98841 88990',
    email: 'sneha.venkat@gmail.com',
    bloodGroup: 'O-',
    age: 27,
    gender: 'Female',
    weightKg: 56,
    hemoglobinGdl: 13.5,
    city: 'Coimbatore',
    address: '18, Avinashi Road, Peelamedu',
    location: { latitude: 11.0287, longitude: 77.0185, city: 'Coimbatore' }, // DISTANCE: ~215 km away (INELIGIBLE: Exceeds 50km radius)
    lastDonationDate: new Date(Date.now() - 130 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 3,
    historicalAttendanceRate: 0.88,
    historicalResponseRate: 0.90,
    createdSource: 'seeded',
    createdAt: '2025-01-20T14:30:00Z',
  },
  {
    id: 'DNR-1005',
    fullName: 'Naveen Kumar',
    phone: '+91 98843 66773',
    email: 'naveen.k@gmail.com',
    bloodGroup: 'O-',
    age: 30,
    gender: 'Male',
    weightKg: 71,
    hemoglobinGdl: 14.6,
    city: 'Bangalore',
    address: '100 Feet Road, Indiranagar',
    location: { latitude: 12.9719, longitude: 77.6412, city: 'Bangalore' }, // DISTANCE: ~335 km away in Bangalore (INELIGIBLE: Exceeds radius)
    lastDonationDate: new Date(Date.now() - 110 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 6,
    historicalAttendanceRate: 0.92,
    historicalResponseRate: 0.95,
    createdSource: 'seeded',
    createdAt: '2024-11-20T09:30:00Z',
  },
  {
    id: 'DNR-1006',
    fullName: 'Priya Narayanan',
    phone: '+91 98840 98765',
    email: 'priya.narayanan@gmail.com',
    bloodGroup: 'O-',
    age: 26,
    gender: 'Female',
    weightKg: 57,
    hemoglobinGdl: 13.8,
    city: 'Tiruchirappalli',
    address: 'Woraiyur Car Street',
    location: { latitude: 10.8230, longitude: 78.6720, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 25 * 86400000).toISOString().split('T')[0], // Donated 25 days ago (INELIGIBLE: Cooldown active)
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 5,
    historicalAttendanceRate: 0.90,
    historicalResponseRate: 0.92,
    createdSource: 'seeded',
    createdAt: '2025-02-01T11:00:00Z',
  },
  {
    id: 'DNR-1007',
    fullName: 'Kavitha Ramachandran',
    phone: '+91 97909 33445',
    email: 'kavitha.ram@gmail.com',
    bloodGroup: 'O-',
    age: 31,
    gender: 'Female',
    weightKg: 58,
    hemoglobinGdl: 10.2, // LOW HEMOGLOBIN (INELIGIBLE: < 12.5 g/dL safety cutoff)
    city: 'Tiruchirappalli',
    address: 'Cantonment, Near Collector Office',
    location: { latitude: 10.8050, longitude: 78.6850, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 150 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 4,
    historicalAttendanceRate: 0.88,
    historicalResponseRate: 0.94,
    createdSource: 'seeded',
    createdAt: '2025-02-10T14:20:00Z',
  },
  {
    id: 'DNR-1008',
    fullName: 'Manoj Prabhakar',
    phone: '+91 94441 22334',
    email: 'manoj.prabhakar@gmail.com',
    bloodGroup: 'O-',
    age: 22,
    gender: 'Male',
    weightKg: 46, // UNDERWEIGHT (INELIGIBLE: < 50 kg safety threshold)
    hemoglobinGdl: 13.9,
    city: 'Tiruchirappalli',
    address: 'K.K. Nagar 4th Cross',
    location: { latitude: 10.7850, longitude: 78.6920, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 160 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 2,
    historicalAttendanceRate: 0.85,
    historicalResponseRate: 0.88,
    createdSource: 'seeded',
    createdAt: '2024-08-12T11:15:00Z',
  },
  {
    id: 'DNR-1009',
    fullName: 'Arun Varma',
    phone: '+91 94440 11223',
    email: 'arun.varma@gmail.com',
    bloodGroup: 'O-',
    age: 34,
    gender: 'Male',
    weightKg: 76,
    hemoglobinGdl: 14.9,
    city: 'Tiruchirappalli',
    address: 'Samayapuram North Street',
    location: { latitude: 10.9310, longitude: 78.7410, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 120 * 86400000).toISOString().split('T')[0],
    isAvailable: false, // TEMPORARILY UNAVAILABLE / BUSY (INELIGIBLE)
    consentNotifications: true,
    totalDonations: 7,
    historicalAttendanceRate: 0.91,
    historicalResponseRate: 0.89,
    createdSource: 'seeded',
    createdAt: '2024-11-05T08:30:00Z',
  },
  {
    id: 'DNR-1010',
    fullName: 'Ananya Krishnan',
    phone: '+91 97910 44556',
    email: 'ananya.k@gmail.com',
    bloodGroup: 'O-',
    age: 23,
    gender: 'Female',
    weightKg: 54,
    hemoglobinGdl: 13.0,
    city: 'Tiruchirappalli',
    address: 'Lalgudi Main Road',
    location: { latitude: 10.8710, longitude: 78.8150, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 110 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: false, // CONSENT NOT GRANTED (INELIGIBLE)
    totalDonations: 2,
    historicalAttendanceRate: 0.88,
    historicalResponseRate: 0.90,
    createdSource: 'seeded',
    createdAt: '2025-03-10T16:00:00Z',
  },
  {
    id: 'DNR-1011',
    fullName: 'Rohit Sharma',
    phone: '+91 94443 88994',
    email: 'rohit.s@gmail.com',
    bloodGroup: 'O-',
    age: 32,
    gender: 'Male',
    weightKg: 74,
    hemoglobinGdl: 15.1,
    city: 'Madurai',
    address: 'Anna Nagar 80 Feet Road',
    location: { latitude: 9.9252, longitude: 78.1198, city: 'Madurai' }, // DISTANCE: ~135 km from Trichy (INELIGIBLE: Exceeds 50km radius)
    lastDonationDate: new Date(Date.now() - 135 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 6,
    historicalAttendanceRate: 0.91,
    historicalResponseRate: 0.93,
    createdSource: 'seeded',
    createdAt: '2024-10-05T11:00:00Z',
  },
  {
    id: 'DNR-1012',
    fullName: 'Lakshmi Prasanna',
    phone: '+91 98403 44552',
    email: 'lakshmi.p@gmail.com',
    bloodGroup: 'O-',
    age: 25,
    gender: 'Female',
    weightKg: 53,
    hemoglobinGdl: 13.1,
    city: 'Salem',
    address: 'Fairlands Junction',
    location: { latitude: 11.6643, longitude: 78.1460, city: 'Salem' }, // DISTANCE: ~140 km from Trichy (INELIGIBLE: Exceeds 50km radius)
    lastDonationDate: new Date(Date.now() - 120 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 3,
    historicalAttendanceRate: 0.88,
    historicalResponseRate: 0.90,
    createdSource: 'seeded',
    createdAt: '2025-01-05T10:00:00Z',
  },
  {
    id: 'DNR-1013',
    fullName: 'Harish Ranganathan',
    phone: '+91 94442 77883',
    email: 'harish.r@gmail.com',
    bloodGroup: 'O-',
    age: 27,
    gender: 'Male',
    weightKg: 70,
    hemoglobinGdl: 14.4,
    city: 'Tiruchirappalli',
    address: 'Mannachanallur Main Bazaar',
    location: { latitude: 10.9050, longitude: 78.7050, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 40 * 86400000).toISOString().split('T')[0], // Donated 40 days ago (INELIGIBLE: 50 days left in cooling interval)
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 4,
    historicalAttendanceRate: 0.89,
    historicalResponseRate: 0.88,
    createdSource: 'seeded',
    createdAt: '2025-02-14T10:00:00Z',
  },
  {
    id: 'DNR-1014',
    fullName: 'Karthik Balaji',
    phone: '+91 99620 55667',
    email: 'karthik.balaji@gmail.com',
    bloodGroup: 'O+', // INCOMPATIBLE FOR O- PATIENT (INELIGIBLE)
    age: 24,
    gender: 'Male',
    weightKg: 68,
    hemoglobinGdl: 15.0,
    city: 'Tiruchirappalli',
    address: 'Srirangam Temple Street',
    location: { latitude: 10.8625, longitude: 78.6917, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 110 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 5,
    historicalAttendanceRate: 0.90,
    historicalResponseRate: 0.89,
    createdSource: 'seeded',
    createdAt: '2025-02-10T14:20:00Z',
  },
  {
    id: 'DNR-1015',
    fullName: 'Deepak Sivakumar',
    phone: '+91 98410 77889',
    email: 'deepak.siva@gmail.com',
    bloodGroup: 'A+', // INCOMPATIBLE FOR O- PATIENT (INELIGIBLE)
    age: 38,
    gender: 'Male',
    weightKg: 80,
    hemoglobinGdl: 14.5,
    city: 'Tiruchirappalli',
    address: 'Rockfort Bazaar Road',
    location: { latitude: 10.8280, longitude: 78.6980, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 130 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 9,
    historicalAttendanceRate: 0.93,
    historicalResponseRate: 0.95,
    createdSource: 'seeded',
    createdAt: '2024-10-18T10:00:00Z',
  },
  {
    id: 'DNR-1016',
    fullName: 'Divya Subramanian',
    phone: '+91 98402 33441',
    email: 'divya.subbu@gmail.com',
    bloodGroup: 'B+', // INCOMPATIBLE FOR O- PATIENT (INELIGIBLE)
    age: 30,
    gender: 'Female',
    weightKg: 59,
    hemoglobinGdl: 13.4,
    city: 'Tiruchirappalli',
    address: 'TVS Tolgate Road',
    location: { latitude: 10.7980, longitude: 78.6910, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 120 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 4,
    historicalAttendanceRate: 0.92,
    historicalResponseRate: 0.94,
    createdSource: 'seeded',
    createdAt: '2025-01-20T13:30:00Z',
  },
  {
    id: 'DNR-1017',
    fullName: 'Rahul Chandrasekar',
    phone: '+91 99622 66778',
    email: 'rahul.cs@gmail.com',
    bloodGroup: 'AB+', // INCOMPATIBLE FOR O- PATIENT (INELIGIBLE)
    age: 41,
    gender: 'Male',
    weightKg: 82,
    hemoglobinGdl: 14.8,
    city: 'Tiruchirappalli',
    address: 'Crawford High Road',
    location: { latitude: 10.7720, longitude: 78.6750, city: 'Tiruchirappalli' },
    lastDonationDate: new Date(Date.now() - 140 * 86400000).toISOString().split('T')[0],
    isAvailable: true,
    consentNotifications: true,
    totalDonations: 7,
    historicalAttendanceRate: 0.91,
    historicalResponseRate: 0.90,
    createdSource: 'seeded',
    createdAt: '2024-09-01T08:00:00Z',
  }
];

// Initial realistic emergency requests
export const INITIAL_REQUESTS: EmergencyRequest[] = [
  {
    id: 'REQ-8801',
    referenceId: 'REF-ER-2026-0881',
    patientName: 'Anita Ramesh',
    patientAge: 34,
    patientGender: 'Female',
    bloodGroup: 'O-',
    componentNeeded: 'Red Blood Cells (PRBC)',
    unitsRequired: 2,
    unitsFulfilled: 0,
    hospitalName: 'Srinivasan Medical College & Hospital',
    hospitalAddress: 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112',
    city: 'Tiruchirappalli',
    location: { latitude: 10.9250, longitude: 78.7450, city: 'Tiruchirappalli', address: 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112' },
    urgency: 'CRITICAL',
    requiredBefore: '2026-03-01T18:00:00Z',
    contactPerson: 'ER Trauma Team',
    contactPhone: '0431-2677777',
    patientContactNumber: '0431-2677777',
    diagnosis: 'Post-partum hemorrhage with acute hypovolemic shock',
    notes: 'Immediate PRBC transfusion indicated. Universal safe donor preferred.',
    status: 'PENDING',
    createdAt: new Date().toISOString(),
    dispatchedDonorIds: [],
  },
  {
    id: 'REQ-8802',
    referenceId: 'REF-ER-2026-0882',
    patientName: 'Rajesh Kumar Sundar',
    patientAge: 48,
    patientGender: 'Male',
    bloodGroup: 'B+',
    componentNeeded: 'Whole Blood',
    unitsRequired: 3,
    unitsFulfilled: 1,
    hospitalName: 'Rajiv Gandhi Govt General Hospital',
    hospitalAddress: 'EVR Periyar Salai, Park Town',
    city: 'Chennai',
    location: { latitude: 13.0827, longitude: 80.2707, city: 'Chennai' },
    urgency: 'URGENT',
    requiredBefore: '2026-03-02T12:00:00Z',
    contactPerson: 'Staff Nurse Geetha (Blood Bank)',
    contactPhone: '+91 44 2530 5000',
    diagnosis: 'Multiple trauma from highway vehicular accident',
    notes: 'Orthopedic emergency surgery scheduled.',
    status: 'DISPATCHED',
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    dispatchedDonorIds: ['DNR-1008'],
  },
  {
    id: 'REQ-8803',
    referenceId: 'REF-ER-2026-0883',
    patientName: 'Meera Somasundaram',
    patientAge: 22,
    patientGender: 'Female',
    bloodGroup: 'A-',
    componentNeeded: 'Platelets',
    unitsRequired: 1,
    unitsFulfilled: 1,
    hospitalName: 'MIOT International',
    hospitalAddress: '4/112 Mount Poonamallee Road, Manapakkam',
    city: 'Chennai',
    location: { latitude: 13.0183, longitude: 80.1788, city: 'Chennai' },
    urgency: 'CRITICAL',
    requiredBefore: '2026-03-01T15:00:00Z',
    contactPerson: 'Dr. Abraham (Hematology)',
    contactPhone: '+91 44 4200 2288',
    diagnosis: 'Dengue fever with profound thrombocytopenia (< 18,000/uL)',
    status: 'FULFILLED',
    createdAt: new Date(Date.now() - 7200000).toISOString(),
    dispatchedDonorIds: ['DNR-1007'],
    acceptedDonorId: 'DNR-1007',
    acceptedDonorName: 'Sneha Venkatesh',
    acceptedDonorEtaMinutes: 20,
  }
];

export const INITIAL_NOTIFICATIONS: NotificationLog[] = [
  {
    id: 'NOTIF-901',
    requestId: 'REQ-8802',
    donorId: 'DNR-1008',
    donorName: 'Manoj Prabhakar',
    donorPhone: '+91 94441 22334',
    donorEmail: 'manoj.prabhakar@gmail.com',
    channel: 'BOTH',
    smsContent: `URGENT BLOOD DONATION REQUEST\nHello Manoj Prabhakar,\nAn emergency patient requires B+ blood near Rajiv Gandhi Govt General Hospital, Chennai.\nYour response is important.\nAre you willing to be contacted?\nReply:\nYES - If you are willing.\nNO - If you are unavailable.\nRequest ID: REF-ER-2026-0882\nThank you.`,
    emailSubject: `[CRITICAL] Emergency Blood Donation Needed: B+ at Rajiv Gandhi Govt General Hospital`,
    emailHtml: `<p>Dear Manoj Prabhakar,</p><p>A critical emergency patient requires 3 Units of B+ blood.</p>`,
    status: 'DELIVERED',
    sentAt: new Date(Date.now() - 3500000).toISOString(),
    deliveredAt: new Date(Date.now() - 3490000).toISOString(),
    retryCount: 0,
    provider: 'TWILIO_MSG91_SIMULATED',
  }
];

export const INITIAL_RESPONSES: DonorResponse[] = [
  {
    id: 'RESP-701',
    requestId: 'REQ-8803',
    donorId: 'DNR-1007',
    donorName: 'Sneha Venkatesh',
    donorPhone: '+91 98841 88990',
    responseType: 'YES',
    rawText: 'YES, I can reach MIOT in 20 minutes',
    receivedAt: new Date(Date.now() - 6500000).toISOString(),
    channel: 'SMS',
    actionTaken: 'Status updated to WILLING TO BE CONTACTED. Hospital staff dispatched confirmation pin.',
    cascadedToNext: false,
  }
];

export const INITIAL_AUDIT: AuditLog[] = [
  {
    id: 'AUD-001',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    actor: 'System Admin (admin@hospital.org)',
    action: 'SYSTEM_BOOT',
    details: 'AI Blood Donor & Emergency Response platform initialized with AABB clinical rulebooks.',
    severity: 'INFO',
  },
  {
    id: 'AUD-002',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    actor: 'Dr. Abraham (Hematology)',
    action: 'CREATE_REQUEST',
    details: 'Submitted Emergency Request REQ-8803 for Meera Somasundaram (A- Platelets).',
    severity: 'WARN',
  },
  {
    id: 'AUD-003',
    timestamp: new Date(Date.now() - 6500000).toISOString(),
    actor: 'Donor DNR-1007',
    action: 'WEBHOOK_RESPONSE_YES',
    details: 'Donor Sneha Venkatesh replied YES. Transfusion lock initiated.',
    severity: 'SUCCESS',
  }
];

export const DEFAULT_CONFIG: SystemConfig = {
  mode: 'TEST',
  twilioSid: 'AC_DEMO_REMIX_TWILIO_SID_HEALTHCARE',
  twilioAuthToken: 'demo_auth_token_secret_encrypted',
  twilioPhoneNumber: '+1 800 555 0199',
  msg91ApiKey: 'MSG91_AUTH_KEY_VERIFIED_7788',
  msg91SenderId: 'BLDREC',
  gmailAddress: 'hilda.sharline.dh@gmail.com',
  gmailAppPassword: 'demo_app_password_masked',
  autoCascadeTimeoutSeconds: 30, // 30 seconds for evaluation demo
  maxRadiusKm: 50,
  minIntervalDays: 90,
  weights: {
    compatibility: 0.35,
    proximity: 0.25,
    recency: 0.20,
    reliability: 0.20,
  }
};

// Event-driven pub/sub for real-time reactivity without websockets
type Listener = () => void;
const listeners: Set<Listener> = new Set();
let globalCounter = 1000;

function notifyListeners() {
  listeners.forEach(fn => {
    try {
      fn();
    } catch (e) {
      console.error('Error invoking listener:', e);
    }
  });
}

function generateEntityId(prefix: string): string {
  globalCounter += 1;
  const rand = Math.random().toString(36).substring(2, 7);
  return `${prefix}-${Date.now().toString().slice(-6)}-${rand}-${globalCounter}`;
}

export const dbService = {
  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },

  // Donors CRUD
  getDonors(): Donor[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DONORS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(INITIAL_DONORS));
        return INITIAL_DONORS;
      }
      const donors: Donor[] = JSON.parse(data);
      if (!donors.some(d => d.fullName === 'K. Rajesh Kumar')) {
        localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(INITIAL_DONORS));
        return INITIAL_DONORS;
      }
      const todayStr = new Date().toISOString().split('T')[0];
      const hilda = donors.find(d => d.fullName === 'Hilda Sharline');
      if (hilda) {
        if (hilda.city !== 'Tiruchirappalli') {
          hilda.city = 'Tiruchirappalli';
          hilda.address = 'Near KRCT Campus, Samayapuram';
          hilda.location = { latitude: 10.9328, longitude: 78.7380, city: 'Tiruchirappalli', address: 'Near KRCT Campus, Samayapuram' };
          hilda.lastVerifiedHospital = 'Srinivasan Medical College & Hospital, Samayapuram';
        }
        if (hilda.lastDonationDate !== todayStr) {
          const expected170DaysAgo = new Date(Date.now() - 170 * 86400000).toISOString().split('T')[0];
          if (hilda.lastDonationDate !== expected170DaysAgo) {
            hilda.lastDonationDate = expected170DaysAgo;
          }
        }
        localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(donors));
      }
      return donors;
    } catch {
      return INITIAL_DONORS;
    }
  },

  completeDonationAtHospital(data: {
    requestId: string;
    donorId: string;
    donorName: string;
    bloodGroup: BloodGroup;
    unitsDonated: number;
    bagBarcode: string;
    attendingDoctor: string;
    hospitalName: string;
    phlebotomyStation?: string;
    patientName?: string;
    notes?: string;
  }) {
    const todayStr = new Date().toISOString().split('T')[0];
    const completedRecord = {
      id: generateEntityId('REC'),
      timestamp: new Date().toISOString(),
      ...data,
      dateCompleted: todayStr,
      nextEligibleDate: new Date(Date.now() + 90 * 86400000).toISOString().split('T')[0],
    };

    // Store completed donation
    const completedList = this.getCompletedDonations();
    completedList.unshift(completedRecord);
    localStorage.setItem(STORAGE_KEYS.COMPLETED_DONATIONS, JSON.stringify(completedList));

    // Update donor record: set lastDonationDate to today, increment totalDonations
    const donors = this.getDonors();
    const dIdx = donors.findIndex(d => d.id === data.donorId || d.fullName === data.donorName);
    if (dIdx !== -1) {
      donors[dIdx].lastDonationDate = todayStr;
      donors[dIdx].totalDonations = (donors[dIdx].totalDonations || 0) + 1;
      localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(donors));
    }

    // Update emergency request
    const req = this.getRequestById(data.requestId);
    if (req) {
      this.updateRequest(req.id, {
        status: 'FULFILLED',
        unitsFulfilled: Math.min(req.unitsRequired, (req.unitsFulfilled || 0) + data.unitsDonated),
        acceptedDonorName: data.donorName,
      });
    }

    this.addAuditLog(
      data.attendingDoctor,
      'HOSPITAL_DONATION_COMPLETED',
      `Blood donation completed for ${data.unitsDonated} Unit (${data.bloodGroup}) by ${data.donorName}. Bag ID: ${data.bagBarcode}`,
      'SUCCESS'
    );
    notifyListeners();
    return completedRecord;
  },

  getCompletedDonations(): any[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.COMPLETED_DONATIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  getLatestCompletedDonation(): any | null {
    const list = this.getCompletedDonations();
    return list.length > 0 ? list[0] : null;
  },

  getDonorById(id: string): Donor | undefined {
    return this.getDonors().find(d => d.id === id);
  },

  addDonor(donor: Omit<Donor, 'id' | 'createdAt'>): Donor {
    const donors = this.getDonors();
    const newId = `DNR-${1000 + donors.length + 1}`;
    const newDonor: Donor = {
      ...donor,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    donors.unshift(newDonor);
    localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(donors));
    this.addAuditLog('Admin', 'DONOR_REGISTERED', `Registered new donor ${newDonor.fullName} (${newDonor.bloodGroup})`, 'SUCCESS');
    notifyListeners();
    return newDonor;
  },

  addDonorsBulk(newDonors: Partial<Donor>[]): { addedCount: number; duplicates: number } {
    const existing = this.getDonors();
    const existingPhones = new Set(existing.map(d => d.phone.replace(/\D/g, '')));
    const existingEmails = new Set(existing.map(d => d.email.toLowerCase().trim()));

    let addedCount = 0;
    let duplicates = 0;
    const toAdd: Donor[] = [];

    newDonors.forEach((rec, idx) => {
      const cleanPhone = (rec.phone || '').replace(/\D/g, '');
      const cleanEmail = (rec.email || '').toLowerCase().trim();

      if (existingPhones.has(cleanPhone) || existingEmails.has(cleanEmail)) {
        duplicates++;
        return;
      }

      existingPhones.add(cleanPhone);
      if (cleanEmail) existingEmails.add(cleanEmail);

      const d: Donor = {
        id: `DNR-${1000 + existing.length + toAdd.length + 1}`,
        fullName: rec.fullName || `Donor ${idx + 1}`,
        phone: rec.phone || '+91 90000 00000',
        email: rec.email || `donor${idx}@healthnet.org`,
        bloodGroup: (rec.bloodGroup as BloodGroup) || 'O+',
        age: Number(rec.age) || 28,
        gender: rec.gender || 'Other',
        weightKg: Number(rec.weightKg) || 65,
        hemoglobinGdl: Number(rec.hemoglobinGdl) || 14.0,
        city: rec.city || 'Chennai',
        address: rec.address || 'Uploaded Address',
        location: rec.location || { latitude: 13.0827, longitude: 80.2707, city: rec.city || 'Chennai' },
        lastDonationDate: rec.lastDonationDate || '2025-10-01',
        isAvailable: rec.isAvailable !== false,
        consentNotifications: rec.consentNotifications !== false,
        totalDonations: Number(rec.totalDonations) || 1,
        historicalAttendanceRate: 0.90,
        historicalResponseRate: 0.90,
        createdSource: 'excel_upload',
        createdAt: new Date().toISOString(),
      };
      toAdd.push(d);
      addedCount++;
    });

    if (toAdd.length > 0) {
      const combined = [...toAdd, ...existing];
      localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(combined));
      this.addAuditLog('Admin', 'EXCEL_DATASET_IMPORTED', `Bulk imported ${addedCount} donors from Excel. (${duplicates} skipped duplicates)`, 'SUCCESS');
      notifyListeners();
    }

    return { addedCount, duplicates };
  },

  updateDonor(id: string, updates: Partial<Donor>): Donor | null {
    const donors = this.getDonors();
    const index = donors.findIndex(d => d.id === id);
    if (index === -1) return null;
    donors[index] = { ...donors[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(donors));
    this.addAuditLog('Admin', 'DONOR_UPDATED', `Updated donor details for ${donors[index].fullName}`, 'INFO');
    notifyListeners();
    return donors[index];
  },

  deleteDonor(id: string): boolean {
    const donors = this.getDonors();
    const target = donors.find(d => d.id === id);
    const filtered = donors.filter(d => d.id !== id);
    if (filtered.length === donors.length) return false;
    localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(filtered));
    this.addAuditLog('Admin', 'DONOR_DELETED', `Deleted donor ${target?.fullName || id}`, 'WARN');
    notifyListeners();
    return true;
  },

  // Emergency Requests CRUD
  getRequests(): EmergencyRequest[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.REQUESTS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(INITIAL_REQUESTS));
        return INITIAL_REQUESTS;
      }
      const reqs: EmergencyRequest[] = JSON.parse(data);
      const r1 = reqs.find(r => r.id === 'REQ-8801');
      if (r1 && (r1.hospitalName !== 'Srinivasan Medical College & Hospital' || r1.hospitalAddress !== 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112' || r1.contactPhone !== '0431-2677777')) {
        r1.hospitalName = 'Srinivasan Medical College & Hospital';
        r1.hospitalAddress = 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112';
        r1.city = 'Tiruchirappalli';
        r1.location = { latitude: 10.9250, longitude: 78.7450, city: 'Tiruchirappalli', address: 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112' };
        r1.contactPhone = '0431-2677777';
        r1.patientContactNumber = '0431-2677777';
        localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(reqs));
      }
      return reqs;
    } catch {
      return INITIAL_REQUESTS;
    }
  },

  getRequestById(id: string): EmergencyRequest | undefined {
    return this.getRequests().find(r => r.id === id || r.referenceId === id);
  },

  createRequest(req: Omit<EmergencyRequest, 'id' | 'referenceId' | 'status' | 'createdAt' | 'dispatchedDonorIds' | 'unitsFulfilled'>): EmergencyRequest {
    const requests = this.getRequests();
    const newSeq = 8800 + requests.length + 1;
    const newReq: EmergencyRequest = {
      ...req,
      id: `REQ-${newSeq}`,
      referenceId: `REF-ER-2026-0${newSeq}`,
      status: 'PENDING',
      unitsFulfilled: 0,
      createdAt: new Date().toISOString(),
      dispatchedDonorIds: [],
    };
    requests.unshift(newReq);
    localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(requests));
    this.addAuditLog(
      'Medical Staff', 
      'CREATE_EMERGENCY_REQUEST', 
      `Raised ${newReq.urgency} request for ${newReq.unitsRequired} units of ${newReq.bloodGroup} at ${newReq.hospitalName}`,
      newReq.urgency === 'CRITICAL' ? 'CRITICAL' : 'WARN'
    );
    notifyListeners();
    return newReq;
  },

  updateRequest(id: string, updates: Partial<EmergencyRequest>): EmergencyRequest | null {
    const requests = this.getRequests();
    const idx = requests.findIndex(r => r.id === id || r.referenceId === id);
    if (idx === -1) return null;
    requests[idx] = { ...requests[idx], ...updates };
    localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(requests));
    this.addAuditLog('System', 'UPDATE_REQUEST', `Updated emergency request ${requests[idx].referenceId} (Status: ${requests[idx].status})`, 'INFO');
    notifyListeners();
    return requests[idx];
  },

  cancelRequest(id: string, reason: string): boolean {
    const updated = this.updateRequest(id, { status: 'CANCELLED', notes: `Cancelled: ${reason}` });
    return updated !== null;
  },

  // Notifications
  getNotifications(): NotificationLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
        return INITIAL_NOTIFICATIONS;
      }
      const rawList: NotificationLog[] = JSON.parse(data);
      const seen = new Set<string>();
      let hadDupes = false;
      const deduplicated = rawList.map((item, idx) => {
        if (!item.id || seen.has(item.id)) {
          hadDupes = true;
          const cleanId = `${item.id || 'NOTIF'}-${idx}-${Math.random().toString(36).substring(2, 6)}`;
          seen.add(cleanId);
          return { ...item, id: cleanId };
        }
        seen.add(item.id);
        return item;
      });
      if (hadDupes) {
        localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(deduplicated));
      }
      return deduplicated;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  },

  addNotification(notif: Omit<NotificationLog, 'id'>): NotificationLog {
    const list = this.getNotifications();
    const newNotif: NotificationLog = {
      ...notif,
      id: generateEntityId('NOTIF'),
    };
    list.unshift(newNotif);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(list));
    this.addAuditLog('Notification Engine', 'DISPATCH_ALERT', `Dispatched ${newNotif.channel} alert to ${newNotif.donorName} (${newNotif.donorPhone})`, 'INFO');
    notifyListeners();
    return newNotif;
  },

  updateNotificationStatus(id: string, status: NotificationLog['status'], deliveredAt?: string): void {
    const list = this.getNotifications();
    const idx = list.findIndex(n => n.id === id);
    if (idx !== -1) {
      list[idx].status = status;
      if (deliveredAt) list[idx].deliveredAt = deliveredAt;
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(list));
      notifyListeners();
    }
  },

  // Responses
  getResponses(): DonorResponse[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.RESPONSES);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.RESPONSES, JSON.stringify(INITIAL_RESPONSES));
        return INITIAL_RESPONSES;
      }
      const rawList: DonorResponse[] = JSON.parse(data);
      const seen = new Set<string>();
      let hadDupes = false;
      const deduplicated = rawList.map((item, idx) => {
        if (!item.id || seen.has(item.id)) {
          hadDupes = true;
          const cleanId = `${item.id || 'RESP'}-${idx}-${Math.random().toString(36).substring(2, 6)}`;
          seen.add(cleanId);
          return { ...item, id: cleanId };
        }
        seen.add(item.id);
        return item;
      });
      if (hadDupes) {
        localStorage.setItem(STORAGE_KEYS.RESPONSES, JSON.stringify(deduplicated));
      }
      return deduplicated;
    } catch {
      return INITIAL_RESPONSES;
    }
  },

  addResponse(resp: Omit<DonorResponse, 'id' | 'receivedAt'>): DonorResponse {
    const list = this.getResponses();
    const newResp: DonorResponse = {
      ...resp,
      id: generateEntityId('RESP'),
      receivedAt: new Date().toISOString(),
    };
    list.unshift(newResp);
    localStorage.setItem(STORAGE_KEYS.RESPONSES, JSON.stringify(list));
    this.addAuditLog(
      `Donor (${newResp.donorName})`,
      `REPLY_${newResp.responseType}`,
      `Incoming ${newResp.channel} response: "${newResp.rawText}". Action: ${newResp.actionTaken}`,
      newResp.responseType === 'YES' ? 'SUCCESS' : newResp.responseType === 'NO' ? 'WARN' : 'INFO'
    );
    notifyListeners();
    return newResp;
  },

  // Audit Logs
  getAuditLogs(): AuditLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AUDIT);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(INITIAL_AUDIT));
        return INITIAL_AUDIT;
      }
      const rawList: AuditLog[] = JSON.parse(data);
      const seenIds = new Set<string>();
      let hadDuplicates = false;
      const deduplicated = rawList.map((log, index) => {
        if (!log.id || seenIds.has(log.id)) {
          hadDuplicates = true;
          const cleanId = `${log.id || 'AUD'}-${index}-${Math.random().toString(36).substring(2, 6)}`;
          seenIds.add(cleanId);
          return { ...log, id: cleanId };
        }
        seenIds.add(log.id);
        return log;
      });

      if (hadDuplicates) {
        localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(deduplicated));
      }

      return deduplicated;
    } catch {
      return INITIAL_AUDIT;
    }
  },

  addAuditLog(actor: string, action: string, details: string, severity: AuditLog['severity'] = 'INFO'): void {
    const list = this.getAuditLogs();
    const newLog: AuditLog = {
      id: generateEntityId('AUD'),
      timestamp: new Date().toISOString(),
      actor,
      action,
      details,
      severity,
    };
    list.unshift(newLog);
    // Keep max 200 logs
    const trimmed = list.slice(0, 200);
    localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(trimmed));
  },

  // Config
  getConfig(): SystemConfig {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CONFIG);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(DEFAULT_CONFIG));
        return DEFAULT_CONFIG;
      }
      return JSON.parse(data);
    } catch {
      return DEFAULT_CONFIG;
    }
  },

  updateConfig(updates: Partial<SystemConfig>): SystemConfig {
    const current = this.getConfig();
    const merged: SystemConfig = {
      ...current,
      ...updates,
      weights: {
        ...current.weights,
        ...(updates.weights || {}),
      }
    };
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(merged));
    this.addAuditLog('Admin', 'CONFIG_UPDATED', `Updated system settings (Mode: ${merged.mode})`, 'INFO');
    notifyListeners();
    return merged;
  },

  // Reset database to initial state
  resetToPristine(): void {
    localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(INITIAL_DONORS));
    localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(INITIAL_REQUESTS));
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
    localStorage.setItem(STORAGE_KEYS.RESPONSES, JSON.stringify(INITIAL_RESPONSES));
    localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(INITIAL_AUDIT));
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(DEFAULT_CONFIG));
    notifyListeners();
  }
};
