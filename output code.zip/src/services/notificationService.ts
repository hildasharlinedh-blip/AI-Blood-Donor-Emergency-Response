import { 
  EmergencyRequest, 
  DonorMatch, 
  NotificationLog, 
  DonorResponse, 
  ResponseType,
  NotificationChannel
} from '../types';
import { dbService } from './dbService';
import { runAiDonorMatching } from './aiMatchingEngine';

export interface DispatchPlan {
  requestId: string;
  donorId: string;
  donorName: string;
  donorPhone: string;
  donorEmail: string;
  channel: NotificationChannel;
  rank: number;
}

// Active cascade timeout timers map
const activeTimers: Map<string, NodeJS.Timeout> = new Map();

/**
 * Generate Google Maps navigation link that opens directly in Google Maps mobile app
 */
export function getGoogleMapsUrl(hospitalName: string, hospitalAddress: string): string {
  const query = `${hospitalName}, ${hospitalAddress}`;
  return `https://maps.google.com/?q=${encodeURIComponent(query)}`;
}

/**
 * Build compliant SMS text matching clinical specifications
 */
export function generateSmsContent(request: EmergencyRequest, donorName: string): string {
  const hospitalName = request.hospitalName || 'Srinivasan Medical College & Hospital';
  const hospitalAddress = request.hospitalAddress || 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112';
  const mapsUrl = getGoogleMapsUrl(hospitalName, hospitalAddress);

  return `URGENT BLOOD DONATION REQUEST

Hello ${donorName},

An emergency patient at ${hospitalName} urgently requires ${request.unitsRequired} units of ${request.bloodGroup} (${request.componentNeeded}).

EMERGENCY REQUISITION DETAILS:
- Patient Name: ${request.patientName} (${request.patientAge} years, ${request.patientGender})
- Blood Group: ${request.bloodGroup}
- Units Required: ${request.unitsRequired} Units
- Emergency Priority: ${request.urgency}
- Hospital: ${hospitalName}
- Address: ${hospitalAddress}
- Location (Google Maps): ${mapsUrl}
- Requisition Reference: ${request.referenceId}
- ER Phone Contact: ${request.contactPhone}

Are you available to donate right now?
Please reply to this email or SMS with:
- "YES" if you can attend
- "NO" if you are currently unavailable

Thank you,
hilda`;
}

/**
 * Generate Direct WhatsApp Alert Dispatch URL
 * Opens WhatsApp directly with pre-formatted message addressed to the donor's phone number
 */
export function getDirectWhatsAppUrl(request: EmergencyRequest, donorName: string, donorPhone: string): string {
  const hospitalName = request.hospitalName || 'Srinivasan Medical College & Hospital';
  const hospitalAddress = request.hospitalAddress || 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112';
  const mapsUrl = getGoogleMapsUrl(hospitalName, hospitalAddress);

  const cleanPhone = donorPhone.replace(/\D/g, '');
  const phoneFormatted = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
  const text = `🚨 *URGENT EMERGENCY BLOOD REQUEST*

Dear *${donorName}*,

An emergency patient at *${hospitalName}* urgently requires *${request.unitsRequired} units of ${request.bloodGroup}* (${request.componentNeeded}).

*EMERGENCY REQUISITION DETAILS:*
- Patient Name: ${request.patientName} (${request.patientAge} years, ${request.patientGender})
- Blood Group: *${request.bloodGroup}*
- Units Required: *${request.unitsRequired} Units*
- Emergency Priority: *${request.urgency}*
- Hospital: *${hospitalName}*
- Address: ${hospitalAddress}
- Requisition Reference: ${request.referenceId}
- ER Phone Contact: ${request.contactPhone}

📍 *GOOGLE MAPS LIVE LOCATION (Tap to open in Google Maps):*
${mapsUrl}

Are you available to donate right now?
Please reply to this email or SMS with:
- *"YES"* if you can attend
- *"NO"* if you are currently unavailable

Thank you,
*hilda*`;

  return `https://api.whatsapp.com/send?phone=${phoneFormatted}&text=${encodeURIComponent(text)}`;
}

/**
 * Generate Native Mobile SMS Link (Opens default phone messaging app)
 */
export function getNativeSmsUrl(request: EmergencyRequest, donorName: string, donorPhone: string): string {
  const hospitalName = request.hospitalName || 'Srinivasan Medical College & Hospital';
  const hospitalAddress = request.hospitalAddress || 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112';
  const mapsUrl = getGoogleMapsUrl(hospitalName, hospitalAddress);

  const cleanPhone = donorPhone.replace(/\D/g, '');
  const phoneFormatted = cleanPhone.length === 10 ? `+91${cleanPhone}` : cleanPhone;
  const text = `URGENT BLOOD REQUISITION: ${request.referenceId}
Dear ${donorName}, emergency patient urgently requires ${request.unitsRequired} units of ${request.bloodGroup} at ${hospitalName}.
Address: ${hospitalAddress}
📍 Google Maps Link (Tap to navigate): ${mapsUrl}
Reply "YES" if you can attend or "NO" if unavailable.
ER Contact: ${request.contactPhone}
Thank you, hilda`;

  return `sms:${phoneFormatted}?body=${encodeURIComponent(text)}`;
}

/**
 * Generate Direct Gmail Web Compose URL (Opens Gmail with pre-filled alert)
 */
export function getGmailWebComposeUrl(request: EmergencyRequest, donorName: string, donorEmail: string): string {
  const hospitalName = request.hospitalName || 'Srinivasan Medical College & Hospital';
  const hospitalAddress = request.hospitalAddress || 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112';
  const mapsUrl = getGoogleMapsUrl(hospitalName, hospitalAddress);

  const subject = `[CRITICAL BLOOD ALERT] Urgent ${request.bloodGroup} Needed at ${hospitalName} (Ref: ${request.referenceId})`;
  const body = `Dear ${donorName},

An emergency patient at ${hospitalName} urgently requires ${request.unitsRequired} units of ${request.bloodGroup} (${request.componentNeeded}).

EMERGENCY REQUISITION DETAILS:
- Patient Name: ${request.patientName} (${request.patientAge} years, ${request.patientGender})
- Blood Group: ${request.bloodGroup}
- Units Required: ${request.unitsRequired} Units
- Emergency Priority: ${request.urgency}
- Hospital: ${hospitalName}
- Address: ${hospitalAddress}
- Requisition Reference: ${request.referenceId}
- ER Phone Contact: ${request.contactPhone}

📍 GOOGLE MAPS LOCATION (Tap link below to open directly in Google Maps):
${mapsUrl}

Are you available to donate right now?
Please reply to this email or SMS with:
- "YES" if you can attend
- "NO" if you are currently unavailable

Thank you,
hilda`;

  const toField = donorName === 'Hilda Sharline' ? 'hilda.sharline.dh@gmail.com' : donorEmail;
  const ccField = donorName === 'Hilda Sharline' ? '&cc=hildasharline.it23@krct.ac.in' : '';

  return `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(toField)}${ccField}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/**
 * Generate Standard Mailto Link
 */
export function getMailtoUrl(request: EmergencyRequest, donorName: string, donorEmail: string): string {
  const hospitalName = request.hospitalName || 'Srinivasan Medical College & Hospital';
  const hospitalAddress = request.hospitalAddress || 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112';
  const mapsUrl = getGoogleMapsUrl(hospitalName, hospitalAddress);

  const subject = `[URGENT] ${request.bloodGroup} Donation Requisition - ${hospitalName}`;
  const body = `Dear ${donorName}, emergency patient requires ${request.bloodGroup} at ${hospitalName}.
Address: ${hospitalAddress}
Maps: ${mapsUrl}
Please reply "YES" or "NO".
Thank you, hilda`;
  return `mailto:${donorEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/**
 * Build professional responsive HTML Email
 */
export function generateEmailHtml(request: EmergencyRequest, donorName: string): string {
  const isCrit = request.urgency === 'CRITICAL';
  const badgeColor = isCrit ? '#DC2626' : '#D97706';
  const hospitalName = request.hospitalName || 'Srinivasan Medical College & Hospital';
  const hospitalAddress = request.hospitalAddress || 'NH-45, Trichy Chennai Trunk Road, near the Samayapuram Toll Plaza in Samayapuram, Tiruchirappalli, Tamil Nadu 621112';
  const mapsUrl = getGoogleMapsUrl(hospitalName, hospitalAddress);

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Emergency Blood Request</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #0F172A; color: #F1F5F9; padding: 24px; margin: 0;">
  <div style="max-width: 600px; margin: 0 auto; background: #1E293B; border-radius: 12px; border: 1px solid #334155; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5);">
    <div style="background: linear-gradient(135deg, #991B1B, #E11D48); padding: 24px; text-align: center;">
      <h1 style="margin: 0; font-size: 20px; font-weight: 800; letter-spacing: -0.5px; color: #FFFFFF;">
        CRITICAL BLOOD DONATION ALERT
      </h1>
      <p style="margin: 6px 0 0; font-size: 13px; color: #FFE4E6;">
        AI Emergency Response Network · Request ID: ${request.referenceId}
      </p>
    </div>

    <div style="padding: 24px;">
      <p style="font-size: 16px; margin: 0 0 16px; color: #F8FAFC;">
        Hello <strong>${donorName}</strong>,
      </p>
      
      <p style="font-size: 14px; line-height: 1.6; color: #CBD5E1; margin: 0 0 20px;">
        An urgent request for <strong>${request.unitsRequired} units of ${request.bloodGroup} (${request.componentNeeded})</strong> has been verified by medical personnel for an emergency patient in critical need at <strong>${hospitalName}</strong>.
      </p>

      <div style="background: #0F172A; border-radius: 8px; border: 1px solid #334155; padding: 16px; margin-bottom: 24px;">
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          <tr>
            <td style="color: #94A3B8; padding: 6px 0;">Hospital:</td>
            <td style="color: #FFFFFF; font-weight: 600; text-align: right;">${hospitalName}</td>
          </tr>
          <tr>
            <td style="color: #94A3B8; padding: 6px 0; vertical-align: top;">Address:</td>
            <td style="color: #FFFFFF; text-align: right;">${hospitalAddress}</td>
          </tr>
          <tr>
            <td style="color: #94A3B8; padding: 8px 0; vertical-align: top;">📍 Google Maps:</td>
            <td style="text-align: right; padding: 8px 0;">
              <a href="${mapsUrl}" target="_blank" style="display: inline-block; background-color: #0369A1; color: #FFFFFF; padding: 6px 14px; font-size: 12px; font-weight: 700; border-radius: 6px; text-decoration: none;">
                Tap to Open in Google Maps ↗
              </a>
            </td>
          </tr>
          <tr>
            <td style="color: #94A3B8; padding: 6px 0;">Required Blood Group:</td>
            <td style="color: #F43F5E; font-weight: 700; text-align: right; font-size: 15px;">${request.bloodGroup}</td>
          </tr>
          <tr>
            <td style="color: #94A3B8; padding: 6px 0;">Urgency Level:</td>
            <td style="color: ${badgeColor}; font-weight: 700; text-align: right;">${request.urgency}</td>
          </tr>
          <tr>
            <td style="color: #94A3B8; padding: 6px 0;">Hospital Contact:</td>
            <td style="color: #38BDF8; font-weight: 600; text-align: right;">${request.contactPhone}</td>
          </tr>
        </table>
      </div>

      <p style="font-size: 14px; font-weight: 600; color: #FFFFFF; margin: 0 0 12px; text-align: center;">
        Are you available to donate right now?
      </p>

      <p style="font-size: 13px; color: #CBD5E1; text-align: center; margin: 0 0 16px;">
        Please reply to this email or SMS with: <strong>"YES"</strong> if you can attend, or <strong>"NO"</strong> if currently unavailable.
      </p>

      <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid #334155; font-size: 13px; color: #94A3B8;">
        <p style="margin: 0 0 4px;">Thank you,</p>
        <p style="margin: 0; font-weight: 700; color: #F8FAFC;">hilda</p>
      </div>
    </div>
  </div>
</body>
</html>
`;
}

export const notificationService = {
  /**
   * Dispatch single notification to a donor (SMS and/or Email)
   */
  dispatchToDonor(
    request: EmergencyRequest, 
    candidate: DonorMatch, 
    channel: NotificationChannel = 'BOTH'
  ): NotificationLog {
    const config = dbService.getConfig();
    const smsContent = generateSmsContent(request, candidate.donor.fullName);
    const emailSubject = `[URGENT] ${request.urgency} Blood Donation Needed: ${request.bloodGroup} at ${request.hospitalName}`;
    const emailHtml = generateEmailHtml(request, candidate.donor.fullName);

    const notif = dbService.addNotification({
      requestId: request.id,
      donorId: candidate.donorId,
      donorName: candidate.donor.fullName,
      donorPhone: candidate.donor.phone,
      donorEmail: candidate.donor.email,
      channel,
      smsContent,
      emailSubject,
      emailHtml,
      status: 'DELIVERED', // Simulated immediate delivery in test mode
      sentAt: new Date().toISOString(),
      deliveredAt: new Date(Date.now() + 800).toISOString(),
      retryCount: 0,
      provider: config.mode === 'REAL' ? 'LIVE_SMS' : 'TWILIO_MSG91_SIMULATED',
    });

    // Update request dispatched donors list
    const dispatched = new Set(request.dispatchedDonorIds || []);
    dispatched.add(candidate.donorId);
    dbService.updateRequest(request.id, {
      status: 'DISPATCHED',
      dispatchedDonorIds: Array.from(dispatched),
    });

    // Start auto-cascade timer if donor doesn't respond
    const timerKey = `${request.id}_${candidate.donorId}`;
    if (activeTimers.has(timerKey)) {
      clearTimeout(activeTimers.get(timerKey)!);
    }

    const timeoutSec = config.autoCascadeTimeoutSeconds || 30;
    const timeoutHandle = setTimeout(() => {
      this.handleIncomingResponse({
        requestId: request.id,
        phoneOrEmail: candidate.donor.phone,
        responseType: 'TIMEOUT',
        rawText: `SYSTEM_AUTO_TIMEOUT after ${timeoutSec}s`,
        channel: 'SIMULATION',
      });
      activeTimers.delete(timerKey);
    }, timeoutSec * 1000);

    activeTimers.set(timerKey, timeoutHandle);

    return notif;
  },

  /**
   * Initiate Sequential Emergency Dispatch Workflow
   * Dispatches to the #1 ranked candidate first
   */
  startEmergencyDispatch(request: EmergencyRequest): { dispatchedTo: DonorMatch | null; totalCandidates: number } {
    const matching = runAiDonorMatching(request);
    if (matching.rankedCandidates.length === 0) {
      dbService.addAuditLog('Notification Engine', 'DISPATCH_BLOCKED', `No eligible donors found for ${request.referenceId}`, 'WARN');
      return { dispatchedTo: null, totalCandidates: 0 };
    }

    // Find the first eligible candidate who hasn't been contacted yet
    const alreadyDispatched = new Set(request.dispatchedDonorIds || []);
    const candidate = matching.rankedCandidates.find(c => !alreadyDispatched.has(c.donorId));

    if (!candidate) {
      dbService.addAuditLog('Notification Engine', 'CASCADE_EXHAUSTED', `All ${matching.rankedCandidates.length} eligible candidates have already been contacted.`, 'WARN');
      return { dispatchedTo: null, totalCandidates: matching.rankedCandidates.length };
    }

    this.dispatchToDonor(request, candidate, 'BOTH');
    return { dispatchedTo: candidate, totalCandidates: matching.rankedCandidates.length };
  },

  /**
   * Webhook Endpoint / Incoming Response Recognition Engine
   * Handles YES, NO, TIMEOUT, and cascades sequentially
   */
  handleIncomingResponse(params: {
    requestId?: string;
    phoneOrEmail: string;
    responseType?: ResponseType;
    rawText: string;
    channel: 'SMS' | 'GMAIL' | 'SIMULATION';
  }): { success: boolean; response: DonorResponse; nextDonorDispatched?: DonorMatch } {
    const allDonors = dbService.getDonors();
    const cleanInputPhone = params.phoneOrEmail.replace(/\D/g, '');
    const cleanInputMail = params.phoneOrEmail.toLowerCase().trim();

    // Identify donor by phone or email
    const donor = allDonors.find(d => {
      const p = d.phone.replace(/\D/g, '');
      const m = d.email.toLowerCase().trim();
      return (cleanInputPhone && p.includes(cleanInputPhone)) || (cleanInputMail && m === cleanInputMail);
    });

    if (!donor) {
      throw new Error(`Donor identification failed for identifier: ${params.phoneOrEmail}`);
    }

    // Identify related request
    let request: EmergencyRequest | undefined;
    if (params.requestId) {
      request = dbService.getRequestById(params.requestId);
    } else {
      // Find the most recent dispatched request containing this donor
      const requests = dbService.getRequests();
      request = requests.find(r => r.dispatchedDonorIds?.includes(donor.id) && r.status === 'DISPATCHED');
    }

    if (!request) {
      // Fallback: pick any active request
      const requests = dbService.getRequests();
      request = requests.find(r => r.status === 'DISPATCHED' || r.status === 'PENDING') || requests[0];
    }

    // Parse Response Type (YES, NO, TIMEOUT)
    let determinedType: ResponseType = params.responseType || 'INVALID';
    const textUpper = params.rawText.trim().toUpperCase();

    if (params.responseType) {
      determinedType = params.responseType;
    } else if (textUpper.startsWith('YES') || textUpper.includes('WILLING') || textUpper.includes('I CAN')) {
      determinedType = 'YES';
    } else if (textUpper.startsWith('NO') || textUpper.includes('CANNOT') || textUpper.includes('UNAVAILABLE') || textUpper.includes('BUSY')) {
      determinedType = 'NO';
    } else if (textUpper.includes('TIMEOUT')) {
      determinedType = 'TIMEOUT';
    }

    // Clear active timer if running
    const timerKey = `${request.id}_${donor.id}`;
    if (activeTimers.has(timerKey)) {
      clearTimeout(activeTimers.get(timerKey)!);
      activeTimers.delete(timerKey);
    }

    let actionTaken = '';
    let cascadedToNext = false;
    let nextCandidate: DonorMatch | undefined;

    if (determinedType === 'YES') {
      actionTaken = `Donor ACCEPTED. Request marked DONOR_ACCEPTED. Transfusion coordination initiated with ${request.hospitalName}.`;
      dbService.updateRequest(request.id, {
        status: 'DONOR_ACCEPTED',
        unitsFulfilled: Math.min(request.unitsRequired, request.unitsFulfilled + 1),
        acceptedDonorId: donor.id,
        acceptedDonorName: donor.fullName,
        acceptedDonorEtaMinutes: 20,
      });
    } else if (determinedType === 'NO' || determinedType === 'TIMEOUT') {
      actionTaken = determinedType === 'NO' 
        ? `Donor DECLINED (marked UNAVAILABLE). Cascade engine triggered next prioritized candidate.`
        : `Donor TIMED OUT (no response). Cascade engine triggered next candidate.`;
      
      // Cascade to the next highest-ranking eligible candidate
      const matching = runAiDonorMatching(request);
      const alreadyDispatched = new Set(request.dispatchedDonorIds || []);
      // Add current donor to dispatched
      alreadyDispatched.add(donor.id);

      nextCandidate = matching.rankedCandidates.find(c => !alreadyDispatched.has(c.donorId));

      if (nextCandidate) {
        cascadedToNext = true;
        this.dispatchToDonor(request, nextCandidate, 'BOTH');
        actionTaken += ` Automatic dispatch sent to #${nextCandidate.rankingPosition} ${nextCandidate.donor.fullName}.`;
      } else {
        actionTaken += ` No further eligible matching donors available within radius.`;
      }
    } else {
      actionTaken = `Unrecognized response "${params.rawText}". Manual verification required.`;
    }

    const savedResponse = dbService.addResponse({
      requestId: request.id,
      donorId: donor.id,
      donorName: donor.fullName,
      donorPhone: donor.phone,
      responseType: determinedType,
      rawText: params.rawText,
      channel: params.channel,
      actionTaken,
      cascadedToNext,
    });

    return {
      success: true,
      response: savedResponse,
      nextDonorDispatched: nextCandidate,
    };
  },

  /**
   * Resend / Retry a failed notification
   */
  retryNotification(notifId: string): boolean {
    const notifs = dbService.getNotifications();
    const notif = notifs.find(n => n.id === notifId);
    if (!notif) return false;

    dbService.updateNotificationStatus(notifId, 'DELIVERED', new Date().toISOString());
    dbService.addAuditLog('Admin', 'RETRY_NOTIFICATION', `Retried notification ${notifId} to ${notif.donorName}`, 'INFO');
    return true;
  }
};
