import React, { useState, useEffect } from 'react';
import { HeaderNav, NavTab } from './components/HeaderNav';
import { PatientRequestForm } from './components/PatientRequestForm';
import { PatientRequestDetails } from './components/PatientRequestDetails';
import { AiMatchingView } from './components/AiMatchingView';
import { LiveResponseMonitor } from './components/LiveResponseMonitor';
import { HospitalDonationCompleted } from './components/HospitalDonationCompleted';
import { DonationRecordUpdated } from './components/DonationRecordUpdated';
import { dbService } from './services/dbService';
import { EmergencyRequest, SystemConfig, Donor } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard-1');
  const [config, setConfig] = useState<SystemConfig>(dbService.getConfig());
  const [donors, setDonors] = useState<Donor[]>([]);
  const [requests, setRequests] = useState<EmergencyRequest[]>([]);
  const [selectedRequestForMatching, setSelectedRequestForMatching] = useState<EmergencyRequest | null>(null);

  const loadData = () => {
    setConfig(dbService.getConfig());
    const dList = dbService.getDonors();
    const rList = dbService.getRequests();
    setDonors(dList);
    setRequests(rList);
    if (!selectedRequestForMatching && rList.length > 0) {
      setSelectedRequestForMatching(rList[0]);
    }
  };

  useEffect(() => {
    loadData();
    const unsubscribe = dbService.subscribe(loadData);
    return () => unsubscribe();
  }, []);

  const handleToggleMode = () => {
    const newMode = config.mode === 'TEST' ? 'REAL' : 'TEST';
    const updated = dbService.updateConfig({ mode: newMode });
    setConfig(updated);
  };

  const activeEmergencyCount = requests.filter(
    r => r.status === 'PENDING' || r.status === 'DISPATCHED'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-rose-600 selection:text-white">
      {/* Top Header Navigation with strictly 6 focused dashboards */}
      <HeaderNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        config={config}
        onToggleMode={handleToggleMode}
        activeEmergencyCount={activeEmergencyCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Dashboard 1: Patient Blood Request Form */}
        {activeTab === 'dashboard-1' && (
          <PatientRequestForm
            onSubmitSuccess={(createdReq) => {
              setSelectedRequestForMatching(createdReq);
              setActiveTab('dashboard-2');
            }}
            onMatchDirectly={(createdReq) => {
              setSelectedRequestForMatching(createdReq);
              setActiveTab('dashboard-3');
            }}
          />
        )}

        {/* Dashboard 2: Patient Request Details & Matching Workflow */}
        {activeTab === 'dashboard-2' && (
          <PatientRequestDetails
            currentRequest={selectedRequestForMatching}
            onForwardToMatching={(req) => {
              setSelectedRequestForMatching(req);
              setActiveTab('dashboard-3');
            }}
            onBackToForm={() => setActiveTab('dashboard-1')}
          />
        )}

        {/* Dashboard 3: AI-Assisted Donor Identification and Selection */}
        {activeTab === 'dashboard-3' && (
          <AiMatchingView
            selectedRequest={selectedRequestForMatching}
            onRequestChange={setSelectedRequestForMatching}
            onInitiateDispatchSuccess={() => setActiveTab('dashboard-4')}
          />
        )}

        {/* Dashboard 4: Live Donor GPS Location Tracking & Hospital Route */}
        {activeTab === 'dashboard-4' && (
          <LiveResponseMonitor
            onOpenRequests={() => setActiveTab('dashboard-1')}
            onProceedToDonationCompleted={() => setActiveTab('dashboard-5')}
          />
        )}

        {/* Dashboard 5: Blood Donation Completed At Hospital */}
        {activeTab === 'dashboard-5' && (
          <HospitalDonationCompleted
            currentRequest={selectedRequestForMatching}
            onDonationRecorded={() => setActiveTab('dashboard-6')}
            onBackToGps={() => setActiveTab('dashboard-4')}
          />
        )}

        {/* Dashboard 6: Donation Record Updated & Central Registry Confirmation */}
        {activeTab === 'dashboard-6' && (
          <DonationRecordUpdated
            onStartNewRequest={() => setActiveTab('dashboard-1')}
            onViewLiveGps={() => setActiveTab('dashboard-4')}
          />
        )}
      </main>

      {/* Clean Minimal Hospital Footer */}
      <footer className="bg-slate-900/60 border-t border-slate-800/80 py-4 px-4 sm:px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Remix AI Blood Donor &amp; Emergency Response System</span>
          <span className="font-mono text-emerald-400">● Hospital Blood Bank &amp; Transfusion Telemetry Active</span>
        </div>
      </footer>
    </div>
  );
}
