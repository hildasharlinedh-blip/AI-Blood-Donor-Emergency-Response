import { BloodGroup, BloodComponent, LocationCoordinates, UrgencyLevel } from '../types';

/**
 * Standard Clinical Blood Compatibility Matrix
 * Reference: AABB (Association for the Advancement of Blood & Biotherapies) Standards
 */

// RBC & Whole Blood: Donor -> Recipient compatibility
const RBC_COMPATIBILITY: Record<BloodGroup, BloodGroup[]> = {
  'O-': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'], // Universal RBC donor
  'O+': ['O+', 'A+', 'B+', 'AB+'],
  'A-': ['A-', 'A+', 'AB-', 'AB+'],
  'A+': ['A+', 'AB+'],
  'B-': ['B-', 'B+', 'AB-', 'AB+'],
  'B+': ['B+', 'AB+'],
  'AB-': ['AB-', 'AB+'],
  'AB+': ['AB+'], // Can only donate to AB+
};

// Plasma (FFP) Compatibility: AB is universal plasma donor; O can only donate plasma to O
const PLASMA_COMPATIBILITY: Record<BloodGroup, BloodGroup[]> = {
  'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-'], // Universal Plasma donor
  'AB-': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-'],
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'A-': ['A+', 'A-', 'O+', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'B-': ['B+', 'B-', 'O+', 'O-'],
  'O+': ['O+', 'O-'],
  'O-': ['O+', 'O-'],
};

// Platelets compatibility
const PLATELET_COMPATIBILITY: Record<BloodGroup, BloodGroup[]> = {
  'O-': ['O-', 'O+'],
  'O+': ['O+'],
  'A-': ['A-', 'A+', 'AB-', 'AB+'],
  'A+': ['A+', 'AB+'],
  'B-': ['B-', 'B+', 'AB-', 'AB+'],
  'B+': ['B+', 'AB+'],
  'AB-': ['AB-', 'AB+', 'A-', 'B-'],
  'AB+': ['AB+', 'A+', 'B+', 'O+', 'AB-', 'A-', 'B-', 'O-'], // Universal platelet recipient is O, AB plasma-free platelets preferred
};

/**
 * Check if donor blood is medically compatible with patient requirement
 */
export function isBloodCompatible(
  donorGroup: BloodGroup,
  patientGroup: BloodGroup,
  component: BloodComponent = 'Red Blood Cells (PRBC)'
): { compatible: boolean; isIdentical: boolean; compatibilityScore: number } {
  const isIdentical = donorGroup === patientGroup;

  if (component === 'Fresh Frozen Plasma (FFP)') {
    const validRecipients = PLASMA_COMPATIBILITY[donorGroup] || [];
    const compatible = validRecipients.includes(patientGroup);
    return {
      compatible,
      isIdentical,
      compatibilityScore: isIdentical ? 100 : compatible ? 85 : 0,
    };
  }

  if (component === 'Platelets') {
    const validRecipients = PLATELET_COMPATIBILITY[donorGroup] || RBC_COMPATIBILITY[donorGroup] || [];
    const compatible = isIdentical || validRecipients.includes(patientGroup);
    return {
      compatible,
      isIdentical,
      compatibilityScore: isIdentical ? 100 : compatible ? 88 : 0,
    };
  }

  // Red Blood Cells & Whole Blood
  const validRecipients = RBC_COMPATIBILITY[donorGroup] || [];
  const compatible = validRecipients.includes(patientGroup);

  return {
    compatible,
    isIdentical,
    // Exact match is given top score (100); Safe cross-match (e.g. O- to A+) is 88 to preserve scarce universal O- for true O- patients
    compatibilityScore: isIdentical ? 100 : (donorGroup === 'O-' ? 85 : compatible ? 90 : 0),
  };
}

/**
 * Calculate geographical distance in kilometers between two coordinates using Haversine formula
 */
export function calculateHaversineDistance(
  coord1: LocationCoordinates,
  coord2: LocationCoordinates
): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = ((coord2.latitude - coord1.latitude) * Math.PI) / 180;
  const dLon = ((coord2.longitude - coord1.longitude) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((coord1.latitude * Math.PI) / 180) *
      Math.cos((coord2.latitude * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return Math.round(distance * 10) / 10; // 1 decimal place
}

/**
 * Estimate emergency arrival time in minutes based on distance and urban traffic conditions
 */
export function estimateArrivalTime(distanceKm: number, urgency: UrgencyLevel): number {
  const isCrit = String(urgency).toUpperCase() === 'CRITICAL';
  const basePrepMinutes = isCrit ? 5 : 10;
  const travelMinutes = Math.round(distanceKm / 0.45);
  return Math.max(8, basePrepMinutes + travelMinutes);
}

/**
 * Calculate days elapsed since last donation
 */
export function getDaysSinceLastDonation(lastDonationDateStr: string): number {
  const lastDate = new Date(lastDonationDateStr);
  const today = new Date();
  const diffTime = Math.abs(today.getTime() - lastDate.getTime());
  return Math.floor(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Minimum mandatory interval verification (90 days standard whole blood)
 */
export function checkIntervalEligibility(daysSinceDonation: number, component: BloodComponent): {
  isEligible: boolean;
  requiredDays: number;
  daysRemaining: number;
} {
  const requiredDays = component === 'Platelets' ? 14 : 90;
  const isEligible = daysSinceDonation >= requiredDays;
  const daysRemaining = Math.max(0, requiredDays - daysSinceDonation);

  return {
    isEligible,
    requiredDays,
    daysRemaining,
  };
}

/**
 * Dynamically calculate the Next Eligible Date from the donor's last donation date
 * and configured mandatory interval (default 90 days).
 * Example: '2026-11-07' + 90 days = '05 February 2027'
 */
export function calculateNextEligibleDate(
  lastDonationDateStr: string,
  minIntervalDays: number = 90
): string {
  if (!lastDonationDateStr) return 'Eligible Immediately';

  // Parse YYYY-MM-DD reliably to prevent timezone offsets
  const parts = lastDonationDateStr.split('-');
  if (parts.length === 3) {
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // 0-indexed month
    const day = parseInt(parts[2], 10);
    const nextDate = new Date(Date.UTC(year, month, day));
    nextDate.setUTCDate(nextDate.getUTCDate() + minIntervalDays);

    const dayStr = String(nextDate.getUTCDate()).padStart(2, '0');
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const monthStr = monthNames[nextDate.getUTCMonth()];
    const yearStr = nextDate.getUTCFullYear();

    return `${dayStr} ${monthStr} ${yearStr}`;
  }

  const d = new Date(lastDonationDateStr);
  d.setDate(d.getDate() + minIntervalDays);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
}
