import * as XLSX from 'xlsx';
import { Donor, BloodGroup, ExcelImportSummary } from '../types';
import { dbService } from '../services/dbService';

export const VALID_BLOOD_GROUPS: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// City approximate coordinates lookup for geocoding Excel imports
const CITY_COORDS: Record<string, { lat: number; lng: number }> = {
  chennai: { lat: 13.0827, lng: 80.2707 },
  coimbatore: { lat: 11.0168, lng: 76.9558 },
  madurai: { lat: 9.9252, lng: 78.1198 },
  salem: { lat: 11.6643, lng: 78.1460 },
  trichy: { lat: 10.7905, lng: 78.7047 },
  tiruchirappalli: { lat: 10.7905, lng: 78.7047 },
  vellore: { lat: 12.9165, lng: 79.1325 },
  bangalore: { lat: 12.9716, lng: 77.5946 },
  bengaluru: { lat: 12.9716, lng: 77.5946 },
  hyderabad: { lat: 17.3850, lng: 78.4867 },
  mumbai: { lat: 19.0760, lng: 72.8777 },
  delhi: { lat: 28.6139, lng: 77.2090 },
};

/**
 * Generate and download a standard Excel template for Blood Donor registration
 */
export function downloadSampleExcelTemplate(): void {
  const sampleData = [
    {
      Name: 'Sanjay Kumar',
      Phone: '+91 98409 12345',
      Email: 'sanjay.k@example.com',
      BloodGroup: 'O-',
      Age: 28,
      Gender: 'Male',
      City: 'Chennai',
      Address: '24 Anna Nagar West',
      LastDonationDate: '2025-10-15',
      Availability: 'YES',
      Consent: 'YES',
    },
    {
      Name: 'Ananya Sharma',
      Phone: '+91 98844 56789',
      Email: 'ananya.s@example.com',
      BloodGroup: 'B+',
      Age: 24,
      Gender: 'Female',
      City: 'Chennai',
      Address: '15 Gandhi Road, Adyar',
      LastDonationDate: '2025-11-20',
      Availability: 'YES',
      Consent: 'YES',
    },
    {
      Name: 'Rahul Varma',
      Phone: '+91 97900 11223',
      Email: 'rahul.varma@example.com',
      BloodGroup: 'A+',
      Age: 32,
      Gender: 'Male',
      City: 'Coimbatore',
      Address: '42 DB Road, RS Puram',
      LastDonationDate: '2025-08-10',
      Availability: 'YES',
      Consent: 'YES',
    },
    {
      Name: 'Divya Nambiar',
      Phone: '+91 99621 33445',
      Email: 'divya.n@example.com',
      BloodGroup: 'AB-',
      Age: 30,
      Gender: 'Female',
      City: 'Bangalore',
      Address: '88 Koramangala 4th Block',
      LastDonationDate: '2025-09-05',
      Availability: 'NO',
      Consent: 'YES',
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleData);
  // Set column widths for elegance
  worksheet['!cols'] = [
    { wch: 20 }, // Name
    { wch: 18 }, // Phone
    { wch: 26 }, // Email
    { wch: 12 }, // BloodGroup
    { wch: 8 },  // Age
    { wch: 10 }, // Gender
    { wch: 15 }, // City
    { wch: 30 }, // Address
    { wch: 16 }, // LastDonationDate
    { wch: 14 }, // Availability
    { wch: 12 }, // Consent
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Blood_Donors_Template');
  XLSX.writeFile(workbook, 'blood_donors_template.xlsx');
}

/**
 * Parse and validate an uploaded Excel or CSV file
 */
export async function parseExcelOrCsvFile(file: File): Promise<ExcelImportSummary> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const buffer = e.target?.result;
        const workbook = XLSX.read(buffer, { type: 'binary', cellDates: true });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert sheet to JSON array
        const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        const existingDonors = dbService.getDonors();
        const existingPhones = new Set(existingDonors.map(d => d.phone.replace(/\D/g, '')));
        const existingEmails = new Set(existingDonors.map(d => d.email.toLowerCase().trim()));

        const parsedRecords: Partial<Donor>[] = [];
        const errors: { row: number; name: string; reason: string }[] = [];
        let duplicateCount = 0;
        let validCount = 0;

        rawRows.forEach((row, index) => {
          const rowNum = index + 2; // Accounting for 1-indexed Excel header
          
          // Flexible key lookup (case-insensitive & space-insensitive)
          const findVal = (keys: string[]): string => {
            for (const k of Object.keys(row)) {
              const normalized = k.toLowerCase().replace(/[^a-z0-9]/g, '');
              for (const searchKey of keys) {
                if (normalized === searchKey.toLowerCase().replace(/[^a-z0-9]/g, '')) {
                  const val = row[k];
                  if (val instanceof Date) {
                    return val.toISOString().split('T')[0];
                  }
                  return String(val).trim();
                }
              }
            }
            return '';
          };

          const name = findVal(['name', 'fullname', 'donorname']);
          const phone = findVal(['phone', 'phonenumber', 'mobile', 'contact']);
          const email = findVal(['email', 'emailaddress', 'mail']);
          const rawBlood = findVal(['bloodgroup', 'blood', 'bloodtype', 'group']).toUpperCase().replace(/\s/g, '');
          const ageVal = parseInt(findVal(['age']) || '28', 10);
          const genderVal = findVal(['gender', 'sex']) || 'Other';
          const cityVal = findVal(['city', 'district', 'town']) || 'Chennai';
          const addressVal = findVal(['address', 'location', 'street']) || cityVal;
          const lastDonationVal = findVal(['lastdonationdate', 'donationdate', 'lastdonated']) || '2025-10-01';
          const availVal = findVal(['availability', 'isavailable', 'available']).toUpperCase();
          const consentVal = findVal(['consent', 'consentnotifications', 'alertconsent']).toUpperCase();

          // Validation Checks
          if (!name) {
            errors.push({ row: rowNum, name: 'Empty Name', reason: 'Donor full name is required.' });
            return;
          }

          const cleanPhone = phone.replace(/\D/g, '');
          if (cleanPhone.length < 10) {
            errors.push({ row: rowNum, name, reason: `Invalid phone number "${phone}". Must be at least 10 digits.` });
            return;
          }

          if (!email || !email.includes('@')) {
            errors.push({ row: rowNum, name, reason: `Invalid email address "${email}".` });
            return;
          }

          if (!VALID_BLOOD_GROUPS.includes(rawBlood as BloodGroup)) {
            errors.push({ row: rowNum, name, reason: `Invalid blood group "${rawBlood}". Allowed: A+, A-, B+, B-, AB+, AB-, O+, O-.` });
            return;
          }

          // Check duplicate in database
          if (existingPhones.has(cleanPhone) || existingEmails.has(email.toLowerCase())) {
            duplicateCount++;
            errors.push({ row: rowNum, name, reason: `Duplicate donor: Phone or email already registered.` });
            return;
          }

          // Geo lookup
          const cityLower = cityVal.toLowerCase().trim();
          const cityGeo = CITY_COORDS[cityLower] || CITY_COORDS.chennai;
          // Add slight jitter so multiple donors in same city don't completely overlap on map
          const jitterLat = cityGeo.lat + (Math.random() - 0.5) * 0.04;
          const jitterLng = cityGeo.lng + (Math.random() - 0.5) * 0.04;

          // Normalize availability and consent
          const isAvailable = availVal === 'NO' || availVal === '0' || availVal === 'FALSE' ? false : true;
          const consentNotifications = consentVal === 'NO' || consentVal === '0' || consentVal === 'FALSE' ? false : true;

          const donorRecord: Partial<Donor> = {
            fullName: name,
            phone: phone.startsWith('+') ? phone : `+91 ${cleanPhone.slice(-10, -5)} ${cleanPhone.slice(-5)}`,
            email: email.toLowerCase(),
            bloodGroup: rawBlood as BloodGroup,
            age: isNaN(ageVal) || ageVal < 18 ? 25 : ageVal > 65 ? 60 : ageVal,
            gender: genderVal.toLowerCase().startsWith('m') ? 'Male' : genderVal.toLowerCase().startsWith('f') ? 'Female' : 'Other',
            weightKg: 65,
            hemoglobinGdl: 14.2,
            city: cityVal,
            address: addressVal,
            location: {
              latitude: parseFloat(jitterLat.toFixed(4)),
              longitude: parseFloat(jitterLng.toFixed(4)),
              city: cityVal,
              address: addressVal,
            },
            lastDonationDate: lastDonationVal.match(/^\d{4}-\d{2}-\d{2}$/) ? lastDonationVal : '2025-10-01',
            isAvailable,
            consentNotifications,
            totalDonations: 3,
            historicalAttendanceRate: 0.90,
            historicalResponseRate: 0.92,
            createdSource: 'excel_upload',
          };

          parsedRecords.push(donorRecord);
          validCount++;
        });

        resolve({
          fileName: file.name,
          totalRows: rawRows.length,
          validCount,
          duplicateCount,
          invalidCount: errors.length - duplicateCount,
          parsedRecords,
          errors,
        });
      } catch (err: any) {
        reject(new Error(`Failed to parse file: ${err.message || 'Unknown format error'}`));
      }
    };

    reader.onerror = () => reject(new Error('File reading failed.'));
    reader.readAsBinaryString(file);
  });
}

/**
 * Export Donors Directory to an Excel file
 */
export function exportDonorsToExcel(donors: Donor[]): void {
  const data = donors.map((d, index) => ({
    'S.No': index + 1,
    'Donor ID': d.id,
    'Full Name': d.fullName,
    'Blood Group': d.bloodGroup,
    'Age': d.age,
    'Gender': d.gender,
    'Phone': d.phone,
    'Email': d.email,
    'City': d.city,
    'Address': d.address,
    'Last Donation Date': d.lastDonationDate,
    'Available': d.isAvailable ? 'YES' : 'NO',
    'Emergency Consent': d.consentNotifications ? 'YES' : 'NO',
    'Total Donations': d.totalDonations,
    'Response Rate': `${Math.round(d.historicalResponseRate * 100)}%`,
    'Registered Date': d.createdAt ? d.createdAt.split('T')[0] : 'N/A',
    'Source': d.createdSource,
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Active_Donors');
  XLSX.writeFile(workbook, `Blood_Donors_Directory_${new Date().toISOString().split('T')[0]}.xlsx`);
}

/**
 * Export Emergency Request Audit and Response Logs to Excel
 */
export function exportEmergencyAuditToExcel(): void {
  const requests = dbService.getRequests();
  const notifications = dbService.getNotifications();
  const responses = dbService.getResponses();

  const requestsData = requests.map((r, i) => ({
    'S.No': i + 1,
    'Request ID': r.id,
    'Reference ID': r.referenceId,
    'Patient Name': r.patientName,
    'Age': r.patientAge,
    'Gender': r.patientGender,
    'Blood Group': r.bloodGroup,
    'Component': r.componentNeeded,
    'Units Required': r.unitsRequired,
    'Units Fulfilled': r.unitsFulfilled,
    'Hospital': r.hospitalName,
    'City': r.city,
    'Urgency Level': r.urgency,
    'Status': r.status,
    'Accepted Donor': r.acceptedDonorName || 'None',
    'Created At': r.createdAt,
  }));

  const notifData = notifications.map((n, i) => ({
    'S.No': i + 1,
    'Notif ID': n.id,
    'Request ID': n.requestId,
    'Donor Name': n.donorName,
    'Phone': n.donorPhone,
    'Email': n.donorEmail,
    'Channel': n.channel,
    'Status': n.status,
    'Sent At': n.sentAt,
    'Delivered At': n.deliveredAt || 'N/A',
  }));

  const respData = responses.map((res, i) => ({
    'S.No': i + 1,
    'Response ID': res.id,
    'Request ID': res.requestId,
    'Donor Name': res.donorName,
    'Phone': res.donorPhone,
    'Reply Received': res.responseType,
    'Raw Message': res.rawText,
    'Channel': res.channel,
    'Action Executed': res.actionTaken,
    'Received At': res.receivedAt,
  }));

  const workbook = XLSX.utils.book_new();
  
  const wsRequests = XLSX.utils.json_to_sheet(requestsData);
  XLSX.utils.book_append_sheet(workbook, wsRequests, 'Emergency_Requests');

  const wsNotifs = XLSX.utils.json_to_sheet(notifData);
  XLSX.utils.book_append_sheet(workbook, wsNotifs, 'Notification_Logs');

  const wsResponses = XLSX.utils.json_to_sheet(respData);
  XLSX.utils.book_append_sheet(workbook, wsResponses, 'Donor_Responses');

  XLSX.writeFile(workbook, `Emergency_Response_Audit_${new Date().toISOString().split('T')[0]}.xlsx`);
}
