export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export type BloodComponent = 
  | 'Whole Blood' 
  | 'Red Blood Cells (PRBC)' 
  | 'Platelets' 
  | 'Fresh Frozen Plasma (FFP)';

export type UrgencyLevel = 'NORMAL' | 'URGENT' | 'CRITICAL' | 'DANGER';

export type RarePhenotype = 
  | 'PP1Pk-neg'
  | 'I-neg'
  | 'In(a+b−)'
  | 'Di(b−)'
  | 'Ge-neg'
  | 'Yt(a−)'
  | 'Do(a−)'
  | 'Hy-neg'
  | 'Jo(a−)'
  | 'Kp(b−)'
  | 'Js(b−)'
  | 'LW(a−)';

export type RequestStatus = 
  | 'PENDING' 
  | 'AI_MATCHED' 
  | 'DISPATCHED' 
  | 'DONOR_ACCEPTED' 
  | 'EN_ROUTE' 
  | 'FULFILLED' 
  | 'CANCELLED';

export type NotificationChannel = 'SMS' | 'GMAIL' | 'BOTH';

export type NotificationStatus = 
  | 'QUEUED' 
  | 'SENT' 
  | 'DELIVERED' 
  | 'FAILED' 
  | 'RETRYING';

export type ResponseType = 'PENDING' | 'YES' | 'NO' | 'TIMEOUT' | 'INVALID';

export interface LocationCoordinates {
  latitude: number;
  longitude: number;
  address?: string;
  city?: string;
  district?: string;
}

export interface Donor {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  bloodGroup: BloodGroup;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  weightKg: number;
  hemoglobinGdl?: number;
  city: string;
  address: string;
  district?: string;
  location: LocationCoordinates;
  lastDonationDate: string; // YYYY-MM-DD
  isAvailable: boolean;
  consentNotifications: boolean;
  totalDonations: number;
  historicalAttendanceRate: number; // 0 to 1
  historicalResponseRate: number; // 0 to 1
  createdSource: 'seeded' | 'manual' | 'excel_upload';
  createdAt: string;
  rarePhenotype?: RarePhenotype;
  hospitalVerificationStatus?: 'VERIFIED' | 'PENDING' | 'EXPIRED';
  lastVerifiedHospital?: string;
}

export interface EmergencyRequest {
  id: string;
  referenceId: string;
  patientName: string;
  patientAge: number;
  patientGender: 'Male' | 'Female' | 'Other';
  bloodGroup: BloodGroup;
  componentNeeded: BloodComponent;
  unitsRequired: number;
  unitsFulfilled: number;
  hospitalName: string;
  hospitalAddress: string;
  city: string;
  location: LocationCoordinates;
  urgency: UrgencyLevel;
  requiredBefore: string;
  contactPerson: string;
  contactPhone: string;
  patientContactNumber?: string;
  diagnosis: string;
  notes?: string;
  status: RequestStatus;
  createdAt: string;
  dispatchedDonorIds: string[];
  acceptedDonorId?: string;
  acceptedDonorName?: string;
  acceptedDonorEtaMinutes?: number;
  donorLiveLocation?: {
    latitude: number;
    longitude: number;
    accuracyMeters?: number;
    sharedAt: string;
    etaMinutes: number;
    distanceKm: number;
  };
}

export interface DecisionTreeChecks {
  bloodCompatible: boolean;
  intervalEligible: boolean; // >= 90 days for PRBC, 14 for platelets
  ageEligible: boolean; // 18-65
  weightEligible: boolean; // >= 50kg
  hemoglobinEligible?: boolean; // >= 12.5 g/dL
  consentGranted: boolean;
  availabilityConfirmed: boolean;
  withinOperationalRadius: boolean; // e.g. <= 50km
}

export interface DonorMatch {
  donorId: string;
  donor: Donor;
  requestId: string;
  compatibilityScore: number; // 0 - 100
  distanceKm: number;
  estimatedEtaMinutes: number;
  proximityScore: number; // 0 - 100
  recencyScore: number; // 0 - 100
  reliabilityScore: number; // 0 - 100
  compositeScore: number; // 0 - 100 (Random forest weighted score)
  tier: 'TIER_1_OPTIMAL' | 'TIER_2_COMPATIBLE' | 'TIER_3_RESERVE';
  treeChecks: DecisionTreeChecks;
  isEligible: boolean;
  rankingPosition: number;
  matchExplanation: string;
}

export interface NotificationLog {
  id: string;
  requestId: string;
  donorId: string;
  donorName: string;
  donorPhone: string;
  donorEmail: string;
  channel: NotificationChannel;
  smsContent: string;
  emailSubject: string;
  emailHtml: string;
  status: NotificationStatus;
  sentAt: string;
  deliveredAt?: string;
  retryCount: number;
  errorReason?: string;
  provider: 'TWILIO_MSG91_SIMULATED' | 'GMAIL_API' | 'LIVE_SMS' | 'LIVE_GMAIL';
}

export interface DonorResponse {
  id: string;
  requestId: string;
  donorId: string;
  donorName: string;
  donorPhone: string;
  responseType: ResponseType;
  rawText: string;
  receivedAt: string;
  channel: 'SMS' | 'GMAIL' | 'SIMULATION';
  actionTaken: string;
  cascadedToNext: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  details: string;
  severity: 'INFO' | 'WARN' | 'CRITICAL' | 'SUCCESS';
}

export interface SystemConfig {
  mode: 'TEST' | 'REAL';
  twilioSid: string;
  twilioAuthToken: string;
  twilioPhoneNumber: string;
  msg91ApiKey: string;
  msg91SenderId: string;
  gmailAddress: string;
  gmailAppPassword: string;
  autoCascadeTimeoutSeconds: number;
  maxRadiusKm: number;
  minIntervalDays: number;
  weights: {
    compatibility: number; // default 0.35
    proximity: number;     // default 0.25
    recency: number;       // default 0.20
    reliability: number;   // default 0.20
  };
}

export interface ExcelImportSummary {
  fileName: string;
  totalRows: number;
  validCount: number;
  duplicateCount: number;
  invalidCount: number;
  parsedRecords: Partial<Donor>[];
  errors: { row: number; name: string; reason: string }[];
}
