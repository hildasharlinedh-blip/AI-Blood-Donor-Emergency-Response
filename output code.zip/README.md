# AI-Based Blood Donor Identification & Emergency Response System

An intelligent clinical blood matching and emergency response application featuring real-time AABB biological compatibility rules, Haversine geographic proximity routing, donor priority queue algorithms, and patient requisition tracking.

---

## 🚀 Quick Start Guide (Run on Local Machine)

Follow these simple steps to run this project on your computer using Command Prompt (Windows), Terminal (macOS), or Linux.

### Prerequisites
Make sure you have **Node.js** (version 18, 20, or higher) installed on your system:
- Download Node.js from: [https://nodejs.org/](https://nodejs.org/) (Choose the LTS version)
- Verify installation by running:
  ```bash
  node -v
  npm -v
  ```

---

### Step-by-Step Instructions

#### 1. Extract the ZIP File
1. Download the ZIP file from the AI Studio top bar (Click the **Download Code** / **Export** icon).
2. Right-click the downloaded `.zip` file and select **Extract All...** (or unzip it).
3. Open the extracted folder.

#### 2. Open Command Prompt in the Project Folder
- **On Windows:**
  1. Open the project folder in File Explorer.
  2. Click on the address bar at the top of the folder window.
  3. Type `cmd` and press **Enter**. (This directly opens Command Prompt inside the project directory).
- **On macOS / Linux:**
  1. Open Terminal.
  2. Type `cd ` (with a space) and drag-and-drop the extracted project folder into the Terminal window, then press **Enter**.

#### 3. Install Dependencies
Run the following command to download and install all required packages:
```bash
npm install
```
*(This may take 1–2 minutes to finish).*

#### 4. Start the Local Development Server
Run:
```bash
npm run dev
```

#### 5. Open in Your Browser
Once the server starts, you will see output like:
```text
  VITE v8.3.0  ready in 240 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: http://<your-ip>:3000/
```
Open your web browser (Chrome, Edge, Firefox, Brave, Safari) and go to:
👉 **`http://localhost:3000`**

---

## 🛠 Available Scripts

In the project directory, you can run:

| Command | Description |
| :--- | :--- |
| `npm run dev` | Runs the app in development mode at `http://localhost:3000` |
| `npm run build` | Compiles and builds production-ready files into the `dist/` folder |
| `npm run preview` | Previews the production build locally |
| `npm run lint` | Runs TypeScript type checking |

---

## 📋 Features Overview
- **Step 1: Patient Requisition Form** – Enter patient name, age, gender, required blood group, hospital details, units, date/time, and emergency level (Normal / Urgent / Critical).
- **Step 2: Database Storage** – Real-time storage of blood requests with UUID and timestamp.
- **Step 3: AI Matching Engine** – Filters donors using clinical AABB compatibility matrix, distance calculations, and availability.
- **Step 4: Prioritized Donor Ranking** – Multi-factor scoring (distance, eligibility interval, donation count).
- **Step 5: Smart Alert Dispatch** – SMS/Push alert notification simulation to the top-matched donor.
- **Step 6: Donor Acceptance** – Real-time acceptance confirmation and hospital notification.
- **Step 7: Transfusion Execution** – Hospital arrival, verification, and clinical transfusion logging.
- **Step 8: Post-Donation Update** – Automatic update of donor donation count and 90-day recovery cadence.
